class InningsBO
{
	public Innings createInnings (long inningsNumber)
	{
		Innings in=new Innings(inningsNumber);
		return in;
	}

}
