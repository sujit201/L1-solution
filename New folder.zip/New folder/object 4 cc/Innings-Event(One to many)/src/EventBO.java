class EventBO {
	
	public Event createEvent(String data, Innings[] InningList)
	{
		String x[]=data.split(",");
		Event e=null;
		for(Innings i:InningList){
			if(i.getInningsNumber()==Long.parseLong(x[4])){
				e=new Event(Long.parseLong(x[0]), x[1],Long.parseLong(x[2]),Long.parseLong(x[3]),i);
			
			}
		}
		return e;
		
	}
	
	

	public  Long findInningsNumber(Event[] eventList, long eventNumber) {
		long i = 0;
		for(Event e:eventList){
			if(e.getEventNumber()==eventNumber){
				i=e.getInnings().getInningsNumber();
			}
		}
		  return i;
	}
	    

}
