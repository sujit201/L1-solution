import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=Integer.parseInt(sc.nextLine());
		List<String> name=new ArrayList<String>();
		for (int i = 0; i < num; i++) {
			name.add(sc.nextLine());
		}
		while(true){
			System.out.println("Menu\n1.Insert Players\n2.Delete Players");
			int ch=Integer.parseInt(sc.nextLine());
			if(ch==1){
				String inam=sc.nextLine();
				name.add(inam);
				System.out.println("Player details after insertion");
				for (String lo : name) {
					System.out.println(lo);
				}
				System.out.println("Do you want to continue");
				String yn=sc.nextLine();
				if(yn.equals("No"))
					System.exit(0);
			}
			else if(ch==2){
				String dnam=sc.nextLine();
				name.remove(dnam);
				System.out.println("Player details after deletion");
				for (String lo : name) {
					System.out.println(lo);
				}
				System.out.println("Do you want to continue");
				String yn=sc.nextLine();
				if(yn.equals("No"))
					System.exit(0);
			}
		}
	}

}
