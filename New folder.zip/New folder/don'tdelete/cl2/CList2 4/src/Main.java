import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		List<Character> li=new ArrayList<Character>();
		for (int i = 0; i < s.length(); i++) {
			li.add(s.charAt(i));
		}
		for (int i = li.size()-1; i >=0 ; i--) {
			System.out.println(li.get(i));
		}
	}

}
