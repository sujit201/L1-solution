import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		List<Integer> vals=new ArrayList<Integer>();
		for (int i = 0; i < num; i++) {
			vals.add(sc.nextInt());
		}
		int sum=0;
		for (int i = 0; i < num; i++) {
			String s=Integer.toString(vals.get(i));
			for (int j = 0; j < s.length(); j++) {
				if(s.charAt(j)=='7'){
					break;
				}
				sum=sum+Integer.parseInt(Character.toString(s.charAt(j)));
			}
		}
		System.out.println(sum);
	}
}
