import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		List<Integer> vals=new ArrayList<Integer>();
		for (int i = 0; i < num; i++) {
			vals.add(sc.nextInt());
		}
		int sum=0;
		for (int i = 0; i < num; i++) {
			if((i%2==0 && vals.get(i)%2==0)||(i%2!=0 && vals.get(i)%2!=0))
					sum=sum+vals.get(i);
		}
		System.out.println(sum);
	}
}
