
public class UserMainCode {
public void display(String name) {
	System.out.println(name);
}
}
