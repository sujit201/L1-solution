
public class UserMainCode {
public void display(String name,String team) {
	System.out.println(name+"#"+team);
}
}
