import java.util.*;
import java.io.*;
public class Main {
public static void main(String args[]) throws Exception {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
	String p,t;
	System.out.println("Enter the player name");
	p=br.readLine();
	System.out.println("Enter the team name");
	t=br.readLine();
	UserMainCode u=new UserMainCode();
	u.display(p,t);
	
}
}
