
public class UserMainCode {
	public void display(String a,String b){
		System.out.println(a+"#"+b);
		
	}
}
