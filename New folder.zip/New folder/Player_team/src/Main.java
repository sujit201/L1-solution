import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br =new BufferedReader (new InputStreamReader(System.in));
		String p,t;
		System.out.println("Enter the player name");
		p=br.readLine();
		System.out.println("Enter the team name");
		t=br.readLine();
		UserMainCode u=new UserMainCode();
		//p=p.toLowerCase();
		//p=p.substring(0,1).toUpperCase()+p.substring(1);
		//t=t.toUpperCase();
		u.display(p,t);

	}

}
