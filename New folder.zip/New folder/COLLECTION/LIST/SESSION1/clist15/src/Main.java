import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of matches");
		int n=Integer.parseInt(sc.nextLine());
		System.out.println("Enter the runs scored by the team");
		List<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<n;i++){
			list.add(Integer.parseInt(sc.nextLine()));
		}
		int count=0,count1=0;
		for(int i=0;i<n;i++){
			count=0;
			for(int j=1;j<=list.get(i);j++){
				if(list.get(i)%j==0){
					count++;
				}
			}
			if(count==2){
				count1++;
			}
		}
		System.out.println("Number of prime scores : "+count1);
	}

}
