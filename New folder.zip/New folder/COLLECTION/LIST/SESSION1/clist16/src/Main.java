import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=Integer.parseInt(sc.nextLine());
		List<String> crick=new ArrayList<String>();
		for (int i = 0; i < num; i++) {
			crick.add(sc.nextLine());
		}
		int count=0;
		for (int i = 0; i < num; i++) {
			String one=crick.get(i);
			if((Character.toString(one.charAt(one.length()-1)).equals("0"))&&(Character.toString(one.charAt(one.length()-3)).equals("0"))){
				String spl[]=one.split("-");
				System.out.println(spl[0]);
				count++;
			}
		}
		if(count==0)
			System.out.println("No player has scored a duck");
	}
}
