import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Map<String, Player> map = new TreeMap<String, Player>();
		System.out.println("Enter the number of players");
		int n = Integer.parseInt(sc.nextLine());
		Player p=null;
		String val[] = new String[3];
		for (int i = 0; i < n; i++) {
			System.out.println("Enter the details of the player " + (i + 1));
			String cn=sc.nextLine();
			
				val[0] = sc.nextLine();
				val[1] = sc.nextLine();
				val[2] = sc.nextLine();
			
			p=new Player(val[0], val[1], val[2]);
			//System.out.println(p);
			map.put(cn, p);
			
		}
		Set<Map.Entry<String, Player>> vlaues = map.entrySet();
		System.out.println("Player Details");
		 for(Map.Entry<String, Player> entry : vlaues){
			 System.out.println(entry.getKey()+"--"+entry.getValue());
		 }

	}

}
