import java.util.Comparator;

public class TeamComparator implements Comparator<Team>{

	@Override
	public int compare(Team t, Team t1) {		
		return new Long(t.getNumberOfMatches()).compareTo(t1.getNumberOfMatches());
	}
}
