import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		// Map<Team, Team> map = new TreeMap<Team, Team>(new TeamComparator());
		List<Team> list = new ArrayList<>();
		System.out.println("Enter number of teams:");
		int n = sc.nextInt();
		sc.nextLine();
		Team team = null;

		for (int i = 0; i < n; i++) {
			System.out.println("Enter team " + (i + 1) + " detail");
			System.out.println("Enter Name");
			String name = sc.nextLine();
			System.out.println("Enter number of matches");
			Integer intv = Integer.parseInt(sc.nextLine());
			team = new Team(name, intv);
			// map.put(team, team);
			list.add(team);
		}

		/*
		 * Set<Map.Entry<Team, Team>> vlaues = map.entrySet(); for
		 * (Map.Entry<Team, Team> entry : vlaues) {
		 * System.out.println(entry.getKey()); }
		 */
		Collections.sort(list, new TeamComparator());
		System.out.println("Team list after sort by number of matches");
		for (Team t : list) {
			System.out.println(t);
		}
	}

}
