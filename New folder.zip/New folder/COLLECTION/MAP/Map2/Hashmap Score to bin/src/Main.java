import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.parseInt(sc.nextLine());
		Histogram h = new Histogram();
		for (int i = 0; i < n; i++) {
			int scr = Integer.parseInt(sc.nextLine());
			h.addScore(scr);
		}
		System.out.println("Histogram");
		h.displayHistogram();
	}

}
