import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Histogram {
	private HashMap<Integer, Integer> bins =new HashMap<>();

	public void addScore(int score) {

		if (score > 0 && score <= 10) {
			Integer key = 10;
			Integer val = bins.get(key);
			if (val == null) {
				bins.put(10, 1);
			} else {
				bins.put(10, val + 1);
			}
		} else if (score <= 20) {
			Integer key = 20;
			Integer val = bins.get(key);
			if (val == null) {
				bins.put(key, 1);
			} else {
				bins.put(key, val + 1);
			}
		} else if (score <= 30) {
			Integer key = 30;
			Integer val = bins.get(key);
			if (val == null) {
				bins.put(key, 1);
			} else {
				bins.put(key, val + 1);
			}
		} else if ( score <= 40) {
			Integer key = 40;
			Integer val = bins.get(key);
			if (val == null) {
				bins.put(key, 1);
			} else {
				bins.put(key, val + 1);
			}
		}

	}

	public void displayHistogram() {
		TreeMap<Integer, Integer> t = new TreeMap<>();
		t.putAll(getbins());
		for (Map.Entry<Integer, Integer> m : t.entrySet()) {
			System.out.print(m.getKey() + " : ");
			int i = m.getValue();
			for (int j = 0; j < i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
//
//	public Histogram(HashMap<Integer, Integer> bins) {
//		super();
//		this.bins = bins;
//	}

	public Histogram() {
		
	}

	public HashMap<Integer, Integer> getbins() {
		return bins;
	}

	public void setbins(HashMap<Integer, Integer> bins) {
		this.bins = bins;
	}

	@Override
	public String toString() {
		return "Histogram [bins=" + bins + "]";
	}
}
