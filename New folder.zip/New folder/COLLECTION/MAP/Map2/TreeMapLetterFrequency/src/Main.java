import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input string");
		String s=sc.nextLine();
		LetterSequence ls=new LetterSequence(s);
		ls.displayLetterFrequency(ls.computeFrequency());
	}

}
