import java.util.Map;
import java.util.TreeMap;

public class LetterSequence {
	private String sentence;
	public LetterSequence() {
		// TODO Auto-generated constructor stub
	}
	public LetterSequence(String sentence) {
		super();
		this.sentence = sentence;
	}
	public String getSentence() {
		return sentence;
	}
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	public TreeMap<Character,Integer> computeFrequency(){
		String s=getSentence();
		TreeMap<Character,Integer> map=new TreeMap<>();
		for (int i = 0; i < s.length(); i++) {
		    char c = s.charAt(i);
		    Integer val = map.get(c);
		    if(c!=' '){
		    if (val != null) {
		        map.put(c, val + 1);
		    }
		    else {
		       map.put(c, 1);
		   }
		    }
		}
		return map;
		
	}
	public void displayLetterFrequency(TreeMap<Character,Integer> frequencyMap){
		for(Map.Entry<Character,Integer> entry:frequencyMap.entrySet()){
			System.out.print(entry.getKey()+" : ");
			int i = entry.getValue();
			for (int j = 0; j < i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
