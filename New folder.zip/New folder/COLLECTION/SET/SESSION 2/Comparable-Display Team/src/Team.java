import java.util.ArrayList;

import java.util.Collections;

import java.util.Iterator;



public class Team implements Comparable<Team>{

	String name;

	ArrayList<Player> playerList=new ArrayList<>();

	

	public void addPlayer(String playername) 

	{

		

		playerList.add(new Player(playername));

	}

	

	public ArrayList<Player> getPlayerList()

	{

		Collections.sort(playerList);

		return playerList;

	}



	public String getName() {

		return name;

	}



	public void setName(String name) {

		this.name = name;

	}



	public void setPlayerList(ArrayList<Player> playerList) {

		this.playerList = playerList;

	}



	public Team(String name) {

		super();

		this.name = name;

		this.playerList = playerList;

	}

	public Team() {

		// TODO Auto-generated constructor stub

	}



	@Override

	public int compareTo(Team o) {

		if(this.name.compareTo(o.name)>0)

			return 1;

		else if(this.name.compareTo(o.name)==0)

			return 0;

		else 

			return -1;

	}



	@Override

	public String toString() {

		return name;

	}

	

	



	

}