import java.util.ArrayList;

import java.util.Collections;

import java.util.HashSet;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args)

	{

		Scanner sc=new Scanner(System.in);

		int a=sc.nextInt();

		sc.nextLine();

		ArrayList<Team> ar=new ArrayList<>();

		

		Team t=new Team();

		

		int flag=0;

		

		int j=0;

		for(int i=0;i<a;i++)

		{

		 flag=0;

			int c=0;

			String s=sc.nextLine();

		 String s1[]=s.split("\\|");

		 

		 Iterator<Team> itr=ar.iterator();

		 while(itr.hasNext())

		 {

		   

			 

			 if(itr.next().name.equalsIgnoreCase(s1[0]))

			 {

				 flag=1;

				 break;

				  

			 }

			 c++;

		 }

		 if(flag==0)

		 {

			 

		 ar.add(new Team(s1[0]));

		  

		 t=ar.get(j);

		 t.addPlayer(s1[1]);

		 j++;

		

		 }

		

		 else

		 {

			 t=ar.get(c);

			 t.addPlayer(s1[1]);

		 }

		 /* aj=s1[0];*/

		}

		Collections.sort(ar);

		Iterator<Team> it=ar.iterator();

		System.out.println("Teams and Players in ascending order");

		while(it.hasNext())

		{

			

			t=it.next();

			System.out.println(t);

			ArrayList<Player> aa=t.getPlayerList();

			Iterator<Player> x=aa.iterator();

			while(x.hasNext())

			{

				System.out.println("--"+x.next());

			}

		}



	}



}