import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Please provide the number of  players");
		int n = Integer.parseInt(sc.nextLine());

		TreeSet<Ranking> set = new TreeSet<Ranking>();
		for (int i = 0; i < n; i++) {

			System.out.println("Enter the name of the player " + (i + 1));
			String no = sc.nextLine();

			System.out.println("Enter the score of the player " + (i + 1));
			Long so = Long.parseLong(sc.nextLine());

			Ranking r = new Ranking(no, so);
			set.add(r);
		}

		int i = 1;

		Iterator<Ranking> it = set.descendingIterator();
		System.out.println("Player Details by Score(High to Low)");

		while (it.hasNext()) {
			Ranking r1 = it.next();
			System.out.println((i++) + " " + r1.getName() + " " + r1.getScore());
		}
	}
}
