
public class Ranking implements Comparable<Ranking> {

	private String name;
	private Long score;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getScore() {
		return score;
	}

	public void setScore(Long score) {
		this.score = score;
	}

	public Ranking(String name, Long score) {
		super();
		this.name = name;
		this.score = score;
	}

	public Ranking() {
		super();
	}

	@Override
	public int compareTo(Ranking r1) {
		return (getScore().compareTo(r1.getScore()));
	}

}
