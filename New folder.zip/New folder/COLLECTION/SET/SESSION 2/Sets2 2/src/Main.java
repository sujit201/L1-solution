import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

	public static void main(String[] args) throws ParseException {

		Scanner sc = new Scanner(System.in);

		Set<Match> set = new TreeSet<Match>();

		System.out.println("Enter the number of matches");
		int n = Integer.parseInt(sc.nextLine());

		for (int i = 0; i < n; i++) {

			System.out.println("Enter match date in (MM-dd-yyyy)");
			String dm1 = sc.nextLine();

			SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			Date dm2 = sdf.parse(dm1);

			System.out.println("Enter Team 1");
			String t1 = sc.nextLine();

			System.out.println("Enter Team 2");
			String t2 = sc.nextLine();

			Match m = new Match(dm2, t1, t2);

			set.add(m);

		}

		System.out.println("Match Details");

		Iterator<Match> it = ((TreeSet<Match>) set).descendingIterator();

		while (it.hasNext()) {

			Match m1 = it.next();

			SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			String dm2 = sdf.format(m1.getMatchDate());

			System.out.println("Team" + " " + "1 " + m1.getTeamOne() + "\n" + "Team" + " " + "2 " + m1.getTeamTwo()
					+ "\n" + "Match held on " + dm2);

		}

	}

}
