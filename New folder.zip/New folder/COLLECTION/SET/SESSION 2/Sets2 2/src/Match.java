import java.util.Date;

public class Match implements Comparable<Match> {
	
	private Date matchDate;
	private String teamOne;
	private String teamTwo;

	public Date getMatchDate() {
		return matchDate;
	}
	public void setMatchDate(Date matchDate) {
		this.matchDate = matchDate;
	}

	public String getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(String teamOne) {
		this.teamOne = teamOne;
	}
	public String getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(String teamTwo) {
		this.teamTwo = teamTwo;
	}
	
	public Match(Date matchDate, String teamOne, String teamTwo) {
		super();
		this.matchDate = matchDate;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
	}
	
	public Match() {
		super();
	}
	
	@Override
	public int compareTo(Match m) {
		
		return (getMatchDate().compareTo(m.getMatchDate()));
	}
	
	
}
