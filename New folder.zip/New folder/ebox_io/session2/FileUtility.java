import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileUtility {
    List<Player> readFileData(BufferedReader br) throws IOException {
    	List<Player> plist = new ArrayList<>();

		String s = "";
		while ((s = br.readLine()) != null) {
			String[] sArr = s.split(",");
			Player p = new Player(Integer.parseInt(sArr[0]), sArr[1], sArr[2], sArr[3], Integer.parseInt(sArr[4]));

			plist.add(p);
		}

		Collections.sort(plist);
		return plist;
	}

	void writeDataToFile(List<Player> playerList) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter("output.csv"));
			for (Player p : playerList) {
				writer.write(p.toString());
				writer.newLine();
				writer.flush();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(writer!=null)
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}
} 