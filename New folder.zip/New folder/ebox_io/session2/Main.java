import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		InputStreamReader isr = new InputStreamReader(new FileInputStream("outcome.txt"));
		BufferedReader br = new BufferedReader(isr);

		int startIndex = Integer.parseInt(sc.nextLine());
		int endIndex = Integer.parseInt(sc.nextLine());

		String str = "";

		br.skip(startIndex);
		for (int i = startIndex; i < endIndex; i++) {
			char c = (char) br.read();
			str += c;
		}

		System.out.println(str);
		br.close();
		sc.close();
	}
}
