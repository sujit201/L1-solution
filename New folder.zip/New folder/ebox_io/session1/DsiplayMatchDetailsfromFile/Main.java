import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    public static void displayMatch(Match match, int n) {
		System.out.println("Match "+n);
		System.out.println("TeamOne : "+match.getTeamOne());
		System.out.println("TeamTwo : "+match.getTeamTwo());
		System.out.println("Venue : "+match.getVenue());
		System.out.println("MatchDate : "+match.getMatchDate());
		
	}
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(new FileInputStream("matches.txt"));
		MatchFileStore mfs=new MatchFileStore();
		List<Match> matches=mfs.obtainMatchFromFile(isr);
		System.out.println("The Match Details are :");
		for (int i=0; i<matches.size(); i++) {
			displayMatch(matches.get(i), (i+1));
		}
	}
}