import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MatchFileStore {
    public List<Match> obtainMatchFromFile(InputStreamReader isr) throws IOException {
		
		BufferedReader br=new BufferedReader(isr);
		List<Match> matches=new ArrayList<Match>();
		String s="";
		while((s=br.readLine())!=null)
		{
			Match match=new Match();
			match.setTeamOne(s.substring(0, 5).trim());
			match.setTeamTwo(s.substring(5, (5+5)).trim());
			match.setVenue(s.substring(10, (10+20)).trim());
			match.setMatchDate(s.substring(30, (30+10)).trim());
			matches.add(match);
		}
		return matches;
	}
}