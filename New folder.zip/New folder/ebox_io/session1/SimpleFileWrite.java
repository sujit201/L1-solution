import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {	
	Scanner sc=new  Scanner(System.in);
	System.out.println("Enter the name of the player");
	String name=sc.nextLine();
	System.out.println("Enter the team name");
	String team=sc.nextLine();
	System.out.println("Enter the number of matches played");
	String matches=sc.nextLine();
	String csv=name+","+team+","+matches;
	
	OutputStream os=new FileOutputStream("player.csv");
	OutputStreamWriter writer=new OutputStreamWriter(os);
	writer.write(csv);
	writer.flush();
	}
}