class TeamBO  {
	 public Team createTeam(String data) {
		 
		 String sp[]=data.split(",");
		 Team t=new Team(sp[0], sp[1]);
		 return t;
    }
}
