class PlayerBO  {
    public Player createPlayer(String data, Team[] teamList) {
    	String sp[]=data.split(",");
    	Player p=null;
    	for(Team t:teamList){
    		if(t.getName().equals(sp[1]))
    		{
    			p=new Player(sp[0],t);	
    		}
    	}
    	return p;
    }
    
    public String findTeamName(Player[] playerList, String sname) {
		String tename=""; 
    	for (Player player : playerList) {
			 if(player.getName().equals(sname)){
				tename=player.getTeam().getName();
			}
		}
    	return tename;
    }
    
    public Boolean findWhetherPlayersAreInSameTeam (Player[] playerList, String sn1, String sn2) {
    	String t1name="";
    	String t2name="";
    	for (Player player : playerList) {
    		if(sn1.equals(player.getName())){
    			t1name=player.getTeam().getName();
    		}
    		if(sn2.equals(player.getName())){
    			t2name=player.getTeam().getName();
    		}
    		
		}
    	if(t1name.equals(t2name)){
    		return true;
    	}
    	else
    		return false;
	}
}
