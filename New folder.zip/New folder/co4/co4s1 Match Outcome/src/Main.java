import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of matches");
		int num=Integer.parseInt(sc.nextLine());
		String date[]=new String[num];
		String teamOne[]=new String[num];
		String teamTwo[]=new String[num];
		String venue[]=new String[num];
		String status[]=new String[num];
		String winnerTeam[]=new String[num];
		Outcome outcome[]=new Outcome[num];
		Match m = new Match();
		for(int i=0;i<num;i++){
			System.out.println("Enter match "+(i+1)+" details:");
			System.out.println("Enter match date");
			date[i]=sc.nextLine();
			System.out.println("Enter team one");
			teamOne[i]=sc.nextLine();
			System.out.println("Enter team two");
			teamTwo[i]=sc.nextLine();
			System.out.println("Enter venue");
			venue[i]=sc.nextLine();
			System.out.println("Enter status");
			status[i]=sc.nextLine();
			System.out.println("Enter winner Team");
			winnerTeam[i]=sc.nextLine();
		}
		Match mm[]=new Match[num];
		for(int i=0;i<num;i++){
			outcome[i]=new Outcome(status[i],winnerTeam[i]);
			mm[i]=new Match(date[i], teamOne[i], teamTwo[i], venue[i], outcome[i]);
			
		}
		int ch;
		MatchBO mbo=new MatchBO();
		while(true){
			System.out.println("Menu");
			System.out.println("1.View match details\n2.Filter match details with outcome status\n3.Filter match details with outcome winner team\n4.Exit");
			System.out.println("Enter your choice");
			 ch=Integer.parseInt(sc.nextLine());
			switch(ch){
			case 1:
				mbo.printAllMatchDetails(mm);
				break;
			case 2:
				System.out.println("Enter outcome status");
				String stat=sc.nextLine();
				mbo.printMatchDetailsWithOutcomeStatus(mm, stat);
				break;
			case 3:
				System.out.println("Enter outcome winner team");
				String wint=sc.nextLine();
				mbo.printMatchDetailsWithOutcomeWinnerTeam(mm, wint);
				break;
			case 4:
				System.exit(0);
				break;
			}
			}
	}

}
