
public class MatchBO {
	public void printAllMatchDetails(Match[] MatchList) {
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %s","Date","Team1","Team2","Venue","Status","Winner"));
		
		for(Match m:MatchList){
			System.out.println(m.toString());
		}
	}
	public void printMatchDetailsWithOutcomeStatus(Match[] MatchList, String outcomeStatus){
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %s","Date","Team1","Team2","Venue","Status","Winner"));		
		boolean f=false;
		for(Match m:MatchList){
			Outcome o=m.getOutcome();
			if(o.getStatus().equals(outcomeStatus)){
				f=true;
					System.out.println(m.toString());
			}
		}
		if(!f)
		System.out.println("Status not found");
	}
	public void printMatchDetailsWithOutcomeWinnerTeam(Match[] MatchList, String outcomeWinnerTeam){
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %s","Date","Team1","Team2","Venue","Status","Winner"));		
		boolean f=false;
		for(Match m:MatchList){
			Outcome o=m.getOutcome();
			if(o.getWinnerTeam().equals(outcomeWinnerTeam)){
					f=true;
				System.out.println(m.toString());
			}
			
				
		}
		if(!f)
		System.out.println("Winner Team not found");
	}
}
