
public class DeliveryBO {
	public Delivery createDelivery(String data, Innings [] inningsList){
		String dsplit[]=data.split(",");
		Delivery ds=null;
		for(Innings i: inningsList){
			ds=new Delivery(Long.parseLong(dsplit[0]), dsplit[1] , dsplit[2], Long.parseLong(dsplit[3]), Long.parseLong(dsplit[4]),i);
		}
		return ds;
	}
	public String findInningsNumber(Delivery [] deliveryList, long deliveryNumber){
		long val=0;
		for(Delivery dd: deliveryList){
			if(dd.getDeliveryNumber()==(deliveryNumber)){
				val=dd.getInningsNumber();
			}
		}
		return "Innings : "+val;
	}
}
