import java.io.StreamCorruptedException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of innings");
		int num=Integer.parseInt(sc.nextLine());
		String idetails[]=new String[num];
		for(int i=0;i<num;i++){
			System.out.println("Enter innings "+(i+1)+" details");
			idetails[i]=sc.nextLine();
		}
		System.out.println("Enter the number of deliveries");
		int num1=Integer.parseInt(sc.nextLine());
		String ddetails[]=new String[num1];
		for(int i=0;i<num1;i++){
			System.out.println("Enter innings "+(i+1)+" details");
			ddetails[i]=sc.nextLine();
		}
		System.out.println("Enter the delivery number for which you need to find the innings number");
		int dnum=Integer.parseInt(sc.nextLine());
		InningsBO ibo=new InningsBO();
		Innings iarr[]=new Innings[num];
		for(int i=0;i<num;i++){
			iarr[i]=ibo.CreateInnings(idetails[i]);
		}
		DeliveryBO dbo=new DeliveryBO();
		Delivery darr[]=new Delivery[num1];
		for(int i=0;i<num1;i++){
			darr[i]=dbo.createDelivery(ddetails[i], iarr);
		}
		String s=dbo.findInningsNumber(darr, dnum);
		System.out.println(s);
	}

}
