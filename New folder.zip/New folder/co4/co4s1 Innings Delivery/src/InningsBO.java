
public class InningsBO {
	public Innings CreateInnings(String data){
		String isplit[]=data.split(",");
		Innings iobj=new Innings(Long.parseLong(isplit[0]), isplit[1]);
		return iobj;
	}
}
