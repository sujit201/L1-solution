
public class PlayerBO {
	public void viewDetails(Player[] playerList){
		System.out.println(String.format("%-15s %-15s %-15s","Player", "Country", "Skill" ));
		for(Player p:playerList){
			System.out.println(p.toString());
		}
	}
	public void printPlayerDetailsWithSkill(Player[] playerList, String skill){
		System.out.println(String.format("%-15s %-15s %-15s","Player", "Country", "Skill" ));
		for(Player pp:playerList){
			if(pp.getSkill().getSkillName().equals(skill)){
				System.out.println(pp.toString());
			}
		}
	} 
}
