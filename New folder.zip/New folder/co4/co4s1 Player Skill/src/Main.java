import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of Players");
		int num = Integer.parseInt(sc.nextLine());
		String name[]=new String[num];
		String country[]=new String[num];
		String skillName[]=new String[num];
		Skill skill[]=new Skill[num];
		Skill s=new Skill();
		for(int i=0;i<num;i++){
			System.out.println("Enter player "+(i+1)+" details:");
			System.out.println("Enter player name");
			name[i]=sc.nextLine();
			System.out.println("Enter country name");
			country[i]=sc.nextLine();
			System.out.println("Enter skill");
			skillName[i]=sc.nextLine();
		}
		Player pp[]=new Player[num];
		PlayerBO pbo=new PlayerBO();
		for(int i=0;i<num;i++){
			skill[i]=new Skill(skillName[i]);
			pp[i]=new Player(name[i], country[i], skill[i]);
		}
		int ch;
		while(true){
			System.out.println("Menu:\n1.View details\n2.Filter players with skill\n3.Exit");
			ch=Integer.parseInt(sc.nextLine());
			switch(ch){
			case 1:
				pbo.viewDetails(pp);
				break;
			case 2:
				System.out.println("Enter skill");
				String sn=sc.nextLine();
				pbo.printPlayerDetailsWithSkill(pp, sn);
				break;
			case 3:
				System.exit(0);
			}
		}
	}

}
