import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int ip=sc.nextInt();
		int t=2;
		int f=0;
		while(true){
			if(t==ip){
				f=1;
				System.out.print("Yes");
				break;
			}
			else{
			t=t+3;
			if(t>ip){
				break;
			}
			}
			
		}
		if(f==0){
			System.out.print("No");
		}
	}

}
