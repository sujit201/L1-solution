import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int d=sc.nextInt();
		int mny=sc.nextInt();
		int count=0;
		int t=0;
		
		if(a<=mny){
			t=mny-a;
		}
		if(b<=t){
			t=t-b;
			count++;
		}
		if(c<=t){
			t=t-c;
			count++;
		}
		if(d<=t){
			t=t-d;
			count++;
		}
		System.out.print(count);
		
	}

}
