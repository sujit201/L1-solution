import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int g1=sc.nextInt();
		int g2=sc.nextInt();
		int g3=sc.nextInt();
		int mny=sc.nextInt();
		boolean b=sc.nextBoolean();
		
		int t=0,count=0;
		if(b==true){
			System.out.print("3");
		}
		else{
			t=mny;
			if(g1<=t){

				  t=t-g1;

				  count++;

				 }

				 if(g2<=t){

				  t=t-g2;

				  count++;

				 }

				 if(g3<=t){

				  t=t-g3;

				  count++;

				 }

				 System.out.print(count);
		}
		
	}

}
