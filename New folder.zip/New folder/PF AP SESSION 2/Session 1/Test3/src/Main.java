import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(((a>=100 && b>=100) || (b>=100 && c>=100) || (c>=100 && a>=100))||(a>=50 && b>=50 && c>=50)){
			System.out.print("Selected");
		}
		else if((a>=100 || b>=100 || c>=100)||((a>=50 && b>=50) || (b>=50 && c>=50) || (c>=50 && a>=50))){
			System.out.print("Waitlisted");
		}
		else{
			System.out.print("Rejected");
		}
	}

}
