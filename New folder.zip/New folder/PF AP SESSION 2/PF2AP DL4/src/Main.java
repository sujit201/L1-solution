import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		int e=sc.nextInt();
		int t=0,r=0,oc=0,ec=0;;
		for(int i=s;i<=e;i++){
			t=i;
			ec=0;
			oc=0;
			while(t>0){
				r=t%10;
				t=t/10;
				if(r!=0 && r%2==0){
					ec++;
				}
				else if(r!=0 &&r%2!=0){
					oc++;
				}
			}
			if(ec==2 && oc==2){
				System.out.print(i+" ");
			}
		}

	}

}
