import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int l = sc.nextInt();
		int u = sc.nextInt();

		int t1, t2, c = 0, r = 0, count = 0, pc = 0;
		for (int i = l; i <= u; i++) {
			t1 = i;
			t2 = i;
			c = 0;
			while (t1 > 0) {
				t1 = t1 / 10;
				c++;
			}
			if (c >= 2) {
				pc = 0;
				while (t2 > 0) {
					r = t2 % 10;
					t2 = t2 / 10;
					count = 0;
					for (int j = 1; j <= r; j++) {
						if (r % j == 0) {
							count++;
						}
					}
					if (count == 2) {
						pc++;
					}
				}
				if (pc == 2) {
					System.out.print(i + " ");
				}
			}

		}

	}

}
