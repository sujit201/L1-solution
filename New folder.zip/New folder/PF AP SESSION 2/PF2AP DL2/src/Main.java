import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		int e=sc.nextInt();
		int r=0,sum=0,t=0,t1;
		for(int i=s;i<=e;i++){
			t=i;
			t1=i;
			sum=0;
			while(t1>0){
				r=t1%10;
				sum=sum*10+r;
				t1=t1/10;
			}
			if(sum==t){
				System.out.print(t+" ");
			}
		}

	}

}
