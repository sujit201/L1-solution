public class UserMainCode {



public static boolean validateTeam(String s)

{

 

 int counte=0,counto=0;

 for(int i=0;i<s.length();i++)

 {

  if(i%2==0)

  {

   

  if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u' || s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U')

  {

   counte++;

  }

  }

  else if(i%2!=0)

  {

   if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u' || s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U')

   {

    counto++;

   }

  }

  

 }

 

 if(counte<counto)

  return true;

 else

  return false;

 

 

 

 

 

 }

}

