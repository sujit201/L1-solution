import java.util.*;

public class Revenue implements Comparable<Revenue> {

	String revenueCategory;

	Integer amount;

	public Revenue() {

	}

	public Revenue(String revenueCategory, Integer amount) {

		this.revenueCategory = revenueCategory;

		this.amount = amount;

	}

	public String getRevenueCategory() {

		return revenueCategory;

	}

	public void setRevenueCategory(String revenueCategory) {

		this.revenueCategory = revenueCategory;

	}

	public Integer getAmount() {

		return amount;

	}

	public void setAmount(int amount) {

		this.amount = amount;

	}

	@Override

	public String toString() {

		return (String.format("%-15s%-15s", revenueCategory, amount));

	}

	@Override

	public int compareTo(Revenue o2) {

		return (getAmount().compareTo(o2.getAmount()));

	}

}