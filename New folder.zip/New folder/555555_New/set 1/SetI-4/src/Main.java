import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		TreeSet<Revenue> set = new TreeSet<Revenue>();

		String x = "", ch = "";

		Integer a = 0;

		do {

			System.out.println("Enter revenue category");

			x = s.nextLine();

			System.out.println("Enter revenue amount");

			a = Integer.parseInt(s.nextLine());

			set.add(new Revenue(x, a));

			System.out.println("Do you want to continue(yes/no):");

			ch = s.nextLine();

		} while (ch.equalsIgnoreCase("Yes"));

		int sum = 0;

		Iterator<Revenue> it = set.descendingIterator();

		System.out.println("Top spending categories");

		System.out.println(String.format("%-15s%-15s", "Category", "Amount"));

		while (it.hasNext()) {

			Revenue r1 = it.next();

			sum = sum + r1.getAmount();

			System.out.println(String.format("%-15s%-15s",

					r1.getRevenueCategory(), r1.getAmount()));

		}

		System.out.println("Total amount earned: " + sum);

	}

}