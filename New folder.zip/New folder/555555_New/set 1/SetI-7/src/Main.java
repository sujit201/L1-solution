import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		Set<String> set1 = new HashSet<String>();
		Set<String> set2 = new HashSet<String>();

		System.out.println("Enter the number of top run scorers in season 4");
		int n = Integer.parseInt(s.nextLine());

		System.out.println("Enter the name of players");

		for (int i = 0; i < n; i++) {
			set1.add(s.nextLine());
		}

		System.out.println("Enter the number of top run scorers in season 5");
		int m = Integer.parseInt(s.nextLine());

		System.out.println("Enter the name of players");

		for (int i = 0; i < m; i++) {
			set2.add(s.nextLine());
		}

		System.out.println("Player Set 1");

		Iterator iterator1;
		iterator1 = set1.iterator();

		while (iterator1.hasNext()) {
			System.out.println(iterator1.next());

		}

		System.out.println("Player Set 2");
		Iterator iterator2;
		iterator2 = set2.iterator();

		while (iterator2.hasNext()) {
			System.out.println(iterator2.next());

		}

		set1.addAll(set2);

		System.out.println("Union");
		Iterator iterator3;
		iterator3 = set1.iterator();

		while (iterator3.hasNext()) {
			System.out.println(iterator3.next());

		}

	}

}
