
public class UserMainCode {
public void display(String first,String second) {
	System.out.println(first+" "+second);
}
}
