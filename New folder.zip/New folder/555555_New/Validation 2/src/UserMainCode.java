public class UserMainCode {

 

 

 

 public static boolean validateTeam(String s)

 {

  int flag=0;

  String ss[]=s.split(" ");

  for(int i=0;i<ss[0].length();i++)

  {

  if(ss[0].charAt(i)>=65 && ss[0].charAt(i)<=90 || ss[0].charAt(i)>=97 && ss[0].charAt(i)<=122)

  {

   flag=0;

  }

  else

  {

   flag=1;

   break;

  }

  }

  if(flag==0)

  {

   try

   {

    Integer.parseInt(ss[1]);

    flag=0;

   }

   catch(Exception e)

   {

    flag=1;

    

   }

  }

  

  if(flag==0)

   return true;

  else

   return false;

 }

}

