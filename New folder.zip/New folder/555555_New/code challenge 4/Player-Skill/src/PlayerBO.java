 class PlayerBO {
    void viewDetails(Player[] playerList)
    	{
 		System.out.println("Player Details");
 		System.out.println(String.format("%-15s %-15s %s","Name","Country","Skill"));
 		for(Player p:playerList){
 			System.out.println(p);
 		}
   	 }
    void printPlayerDetailsWithSkill(Player[] playerList,Skill[] skillList,String skill)
	{
		System.out.println("Skill Details");
		System.out.println(String.format("%-15s %-15s %s","Name","Country","Skill"));
		for(Player p:playerList){
			if(p.getSkills().getSkill().equals(skill))
 			System.out.println(p);
 		}
		
		
	}
}
