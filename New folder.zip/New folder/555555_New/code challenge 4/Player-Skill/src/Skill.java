 class Skill 
{
private String skill;
Skill(){}
Skill(String skill)
{
this.skill=skill;
}
 public String getSkill() {
        return skill;
    }
    public void setSkill(String skill) {
        this.skill = skill;
    }
public String toString()
    {
        
        return String.format("%s",skill);
    }

}
