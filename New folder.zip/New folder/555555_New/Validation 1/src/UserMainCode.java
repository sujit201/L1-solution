public class UserMainCode {

  

	public boolean validatePlayer(String a,String b)

 {

 

 StringBuilder sb=new StringBuilder(a);

  

 StringBuilder sb1=new StringBuilder(b);

  

 int i,flag=0;

  

 int t=a.length()-1;

  

 int t1=b.length()-1;

  

 for(i=0;i<a.length();i++)

 {

 

 if(sb.charAt(0)!='*' && sb.charAt(t)!='*')

 {

 

 if(i%2==0)

 {

 

 if(sb.charAt(i)!='*')

 {



}

 

 else

 {

flag=1;

 

 break;

 }

}

 

 else if(i%2!=0)

 {

 

 if(sb.charAt(i)=='*')

 {



}

 

 else

 {

flag=1;

 

 break;

 }

}

}

 

 else

 {

flag=1;

 

 break;

 }

}

 

 if(flag==0)

 {

 

 for(i=0;i<b.length();i++)

 {

 

 if(sb1.charAt(0)!='#' && sb1.charAt(t1)!='#')

 {

 

 if(i%2==0)

 {

 

 if(sb1.charAt(i)!='#')

 {



}

 

 else

 {

flag=1;

 

 break;

 }

}

 

 else if(i%2!=0)

 {

 

 if(sb1.charAt(i)=='#')

 {



}

 

 else

 {

flag=1;

 

 break;

 }

}

}

 

 else

 {

flag=1;

 

 break;

 }

}

}

 

 /*for(i=0;i<a.length();i++)

  {

 if(sb.indexOf(a,0)!=-1 && sb.indexOf(a,t)!=-1)

 {

 if(i%2==0)

 {

 if(sb.indexOf(a,i)!=-1)

 {

 

 }

 else

 {

 flag=1;

 System.out.println("1");

 break;

 }

 }

 if(i%2!=0)

 {

 if(sb.indexOf(a,i)==-1)

 {

 

 }

 else

 {

 flag=1;

 System.out.println("2");

 break;

 }

 }

 }

 else

 {

 flag=1;

 System.out.println("3");

 break;

 }

 }

 

 for(i=0;i<b.length();i++)

 {

 if(sb1.indexOf(b,0)!=-1 && sb1.indexOf(b,t1)!=-1)

 {

 if(i%2==0)

 {

 if(sb1.indexOf(b,i)!=-1)

 {

 

 }

 else

 {

 flag=1;

 System.out.println("4");

 break;

 }

 }

 else if(i%2!=0)

 {

 if(sb1.indexOf(b,i)==-1)

 {

 

 }

 else

 {

 flag=1;

 System.out.println("5");

 break;

 }

 }

 }

 else

 {

 flag=1;

 System.out.println("6");

 break;

 }

 }*/

 

 if(flag==1)

 {

 

 return false;

 }

 

 else

 {

 

 return true;

 }

}

}

