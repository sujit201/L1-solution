import java.util.*;

  public class Main {

 





	public static void main(String[] args) {

  

 Scanner s=new Scanner(System.in);

 String a;

 

 boolean t=true;

 a=s.nextLine();

 

 String s1[]=a.split(" ");

  

 UserMainCode u=new UserMainCode();

 t=u.validatePlayer(s1[0],s1[1]);

 

 if(t==true)

 {

 

 System.out.println("Valid");

 }

 

 else

 {

 

 System.out.println("Invalid");

 }

}







}













