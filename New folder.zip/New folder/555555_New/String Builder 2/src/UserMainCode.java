public class UserMainCode 

{

	public static void display(String s1, String s2)

	{

		String ss1[] = s1.split(" ");

		String S1 = ss1[1];

		String ss2[] = s2.split(" ");

		String S2 = ss2[1];

		

		if(S1.equals(S2))

		{

			System.out.println("Yes");

		}

		else

		{

			System.out.println("No");

		}

	}



}

