import java.util.*;

  public class Main {

 





	public static void main(String[] args) {

  

 Scanner s=new Scanner(System.in);

 String a,b;

 

 boolean t=true;

 a=s.nextLine();

b=s.nextLine();

 

 UserMainCode u=new UserMainCode();

 t=u. validatePlayer(a,b);

 

 if(t==true)

 {

 

 System.out.println("Valid");

 }

 

 else

 {

 

 System.out.println("Invalid");

 }







}







}

