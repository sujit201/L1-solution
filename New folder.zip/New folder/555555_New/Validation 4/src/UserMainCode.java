public class UserMainCode {

  

	public boolean validatePlayer(String a,String b)

 {

 

 StringBuffer sb=new StringBuffer(a);

  

 StringBuffer sb1=new StringBuffer(b);

  

 int i,flag=0;

  

 for(i=0;i<sb.length();i++)

 {

 

 if((char)(sb.charAt(i)+1)==(char)(sb1.charAt(i)))

 {



}

 

 else

 {

flag=1;

 

 break;

 }

}

 

 if(flag==0)

 {

 

 return true;

 }

 

 else

 {

 

 return false;

 }

}

}