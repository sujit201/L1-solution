import java.util.StringTokenizer;





public class UserMainCode {

	

	public static void display(String s1)

	{

		StringTokenizer st = new StringTokenizer(s1," ");

		while(st.hasMoreTokens())

		{

			System.out.println(st.nextToken());

		}

	}



}