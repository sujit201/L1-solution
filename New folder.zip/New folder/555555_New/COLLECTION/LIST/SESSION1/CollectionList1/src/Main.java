import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		int n = s.nextInt();

		int a[] = new int[n];

		int i, sum = 0;

		ArrayList<Integer> list1 = new ArrayList<Integer>();

		for (i = 0; i < n; i++) {

			a[i] = s.nextInt();

		}

		for (i = 0; i < n; i++) {

			list1.add(a[i]);

		}

		for (i = 0; i < list1.size(); i++) {

			sum += list1.get(i);

		}

		float avg = (float) sum / n;
		System.out.println(sum);
		System.out.println(avg);

	}

}
