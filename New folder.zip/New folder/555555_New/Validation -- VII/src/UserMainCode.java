public class UserMainCode {



	public static boolean validatePlayer(String s)

	{

		int l=s.length();

		int i;

		for(i=0;i<l;i++)

		{

			if(i%2!=0 || i==1)

			{

				if(s.charAt(i)=='a')

				{

					return false;

				}

			}

		}

		

return true;		

	}

}