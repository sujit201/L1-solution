public class UserMainCode

{

	public static void validatePlayer(String a, String b, String c)

		{

			

			String d=" ";

			d=d.concat(b);

			int l=d.length();

			int count=0;

			String g="";

			

			for(int i=0;i<l;i++)

			{

				if(d.charAt(i)==' ')

				{

					count++;

					g=g.concat(Character.toString(b.charAt(i)));

					

				}

			}

			

			if(count==1)

			{

				g=b.substring(0,3);

			}

			

			String str=a.concat("#");

			str=str.concat(g);

		

		if(str.equalsIgnoreCase(c))

		{

			System.out.println("Valid");

		}

		else

		{

			System.out.println("Invalid");

		}

		

	}

}

