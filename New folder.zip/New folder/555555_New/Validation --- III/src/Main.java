import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		String a=sc.nextLine();

		String b=sc.nextLine();

		String c=sc.nextLine();

		

		UserMainCode.validatePlayer(a,b,c);

		

	}



}

