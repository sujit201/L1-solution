public class UserMainCode

{

	public static void display(String s1)

	{

		String ss[] = s1.split(",");

		System.out.println("Player Name : "+ss[0]);

	}

}