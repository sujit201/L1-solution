import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		String s=sc.nextLine();

		

		if(s.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))

		{

			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

			sdf.setLenient(false);

			try

			{

				Date d1=sdf.parse(s);

				System.out.println("Valid");

			}

			catch(ParseException e)

			{

				System.out.println("Invalid");

			}

	}

		

		else

		{

			System.out.println("Invalid");

		}



}

}

