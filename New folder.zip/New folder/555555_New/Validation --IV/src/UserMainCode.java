public class UserMainCode {

	public static void validateCity(String s)

	{

		char ch;

		int count=0;

		int l=s.length();

		for(int i=0;i<l;i++)

		{

			ch=s.charAt(i);

			if((i==0) || (i==1) || (i==(l-1)) || (i==(l-2)))

			{

				if(Character.isLetter(ch)==true)

						count++;

			}

			else

			{

				if(ch=='*')

				count++;

			}

			

		}

		

		

		if(count==l)

		System.out.println("Valid");

		else

			System.out.println("Invalid");

	}



}