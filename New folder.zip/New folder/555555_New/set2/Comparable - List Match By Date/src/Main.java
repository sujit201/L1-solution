import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
public class Main {

	public static void main(String[] args)throws ParseException {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of matches");
		int n=Integer.parseInt(s.nextLine());
		int i=0;
		Date date;
		Set<Match> set=new TreeSet<Match>();
		String d="",t1="", t2="";
		for(i=0; i<n; i++){
			System.out.println("Enter match date in (MM-dd-yyyy)");
			d=s.nextLine();
			SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");
			date=sdf.parse(d);
		    System.out.println("Enter Team 1");
		    t1=s.nextLine();
		    System.out.println("Enter Team 2");
		    t2=s.nextLine();
		    set.add(new Match(date, t1, t2));
		//System.out.println("");
	}
		SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");

		Iterator<Match> it = ((TreeSet<Match>) set).descendingIterator();
		System.out.println("Match Details");
		while(it.hasNext()){
			Match m1=(Match) it.next();
			System.out.println("Team 1 "+m1.getTeamOne());
			System.out.println("Team 2 "+m1.getTeamTwo());
			System.out.println("Match held on "+sdf.format(m1.getMatchDate()));
		}
}
}
