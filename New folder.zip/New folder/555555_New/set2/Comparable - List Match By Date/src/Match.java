import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
public class Match implements Comparable<Match>{

	Date matchDate ; 
	String teamOne;
	String teamTwo;
	public Match() {
		//super();
	}
	public Match(Date matchDate, String teamOne, String teamTwo) {
		//super();
		this.matchDate = matchDate;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
	}
	public Date getMatchDate() {
		return matchDate;
	}
	public void setMatchDate(Date matchDate)throws ParseException {
		this.matchDate=matchDate;
		
	}
	public String getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(String teamOne) {
		this.teamOne = teamOne;
	}
	public String getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(String teamTwo) {
		this.teamTwo = teamTwo;
	}
	@Override
	public int compareTo(Match o) {
		// TODO Auto-generated method stub
		return getMatchDate().compareTo(o.getMatchDate());
	}
	
	
}
