import java.util.*;
public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of players:");
		int n = Integer.parseInt(sc.nextLine());
		
		String name = " ";
		String skill = " ";
		Long cn = (long) 0;
		
		Set<Player> set1 = new TreeSet<Player>();
		
		for(int i = 0 ;i<n ;i++)
		{
			System.out.println("Enter player "+(i+1)+" detail");
			System.out.println("Enter Name");
			name = sc.nextLine();
			
			System.out.println("Enter Skill");
			skill = sc.nextLine();
			
			System.out.println("Enter Cap Number");
			cn = Long.parseLong(sc.nextLine());
			
			Player p = new Player(name,skill,cn);
			set1.add(p);			
		
		}
		
		//int i = 1;

		Iterator<Player> it = ((TreeSet<Player>) set1).descendingIterator();
		System.out.println("Player list after sorting by cap number in descending order");

		while (it.hasNext()) {

			Player p1 = it.next();
			System.out.println(p1.getPlayerName()+"-"+p1.getCapNumber());

		}
			
	}

}
