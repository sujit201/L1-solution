import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Please provide the number of  players");
		int n=Integer.parseInt(s.nextLine());
		int i;
		String x="";
		Long a=(long) 0;
		Set<Ranking> set=new TreeSet<Ranking>();
		for(i=0; i<n; i++){
			System.out.println("Enter the name of the player "+(i+1));
			x=s.nextLine();
			System.out.println("Enter the score of the player "+(i+1));
			a=Long.parseLong(s.nextLine());
			set.add(new Ranking(x, a));
			
			}
		int k=1;
		Iterator<Ranking> it = ((TreeSet<Ranking>) set).descendingIterator();
		System.out.println("Player Details by Score(High to Low)");
		while(it.hasNext()){
			Ranking r1=it.next();
			System.out.println(k+" "+r1.getName()+" "+r1.getScore());
			k++;
		}
	}

}
