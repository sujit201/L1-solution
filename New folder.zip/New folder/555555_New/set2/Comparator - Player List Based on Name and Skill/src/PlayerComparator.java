import java.util.Comparator;

public class PlayerComparator implements Comparator<Player>{

	@Override
	public int compare(Player s1, Player s2) {
		// TODO Auto-generated method stub
		if(s1.getSkill().equals(s2.getSkill())){
			return s1.getName().compareTo(s2.getName());
		}
		return s1.getSkill().compareTo(s2.getSkill());
	}
	

}
