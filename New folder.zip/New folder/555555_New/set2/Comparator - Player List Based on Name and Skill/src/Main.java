import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<Player> list = new ArrayList<Player>();
		System.out.println("Please provide the number of players to be registered");
		int n = Integer.parseInt(sc.nextLine());
		int ch;
		String name;
		String val=" ";
		Player p=null;
		for(int i=0;i<n;i++){
			System.out.println("Please enter player name");
			name=sc.nextLine();
			System.out.println("Please select the skill of the player");
			System.out.println("1.All Rounder");
			System.out.println("2.Batsman");
			System.out.println("3.Bowler");
			ch=Integer.parseInt(sc.nextLine());
			if (ch==1)
			{
				val="All Rounder";
				p =new Player(name,val);
			}
			else if (ch==2)
			{
				val="Batsman";
				p =new Player(name,val);
			}
			else if (ch==3)
			{
				val="Bowler";
				p =new Player(name,val);
			}
			
			list.add(p);
		}
		
		Collections.sort(list,new PlayerComparator());
		System.out.println("Player Details");
		for (Player p1 : list) {
			System.out.println(p1);
		}
		
	}

}
