class MatchBO {
    public Match createMatch(String data, Venue[] venueList) {
    	String s[];
    	s=data.split(",");
    	Match m=null;
    	for(Venue v:venueList){
    		if(v.getName().equals(s[3]))
    		m=new Match(s[0], s[1], s[2], v);
    	}
		return m;		
             //fill your code
    }
    public void findVenue(String date, Match[] matchList) {
		for(Match m:matchList){
			if(m.getDate().equals(date))
			System.out.println("Match was held at "+m.getVenue().getName());
		}
              //fill your code
	}
	
	
    
    public void findAllMatchesInGivenVenue(String sname, Match[] matchList) {
    	System.out.println("Matches in venue "+sname+" are");
    	System.out.println(String.format("%-15s%-15s%s","Date","TeamOne","TeamTwo"));
    	for(Match m:matchList){
    		if(m.getVenue().getName().equals(sname)){
    			System.out.println(m);
    		}
    	}
	       //fill your code
		
	}
	
	
	
				
}
