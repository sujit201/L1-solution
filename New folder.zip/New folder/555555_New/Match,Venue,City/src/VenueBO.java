class VenueBO  {
    public Venue createVenue(String data, City[] cityList) {
    	String s[];
    	s=data.split(",");
    	Venue v=null;
    	for(City c:cityList){
    		v=new Venue(s[0], c);
    	}
		return v;
       //fill your code
    }
}
