import java.util.*;

public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		String s=sc.nextLine();

		

		boolean b=UserMainCode.validateOver(s);

		

		if(b==true)

			System.out.println("Valid");

		else

			System.out.println("Invalid");

	}



}