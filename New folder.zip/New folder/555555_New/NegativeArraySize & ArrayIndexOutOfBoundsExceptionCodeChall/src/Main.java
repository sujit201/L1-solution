import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number of players");
		int n = 0;
		int pos = 0;

		try {
			n = Integer.parseInt(s.nextLine());
		

		String name[] = new String[n];

		System.out.println("Enter the name of the players");

		for (int i = 0; i < n; i++) {
			name[i] = s.nextLine();
		}

		System.out.println("Enter the position of the player");

		
			pos = Integer.parseInt(s.nextLine());
		

		System.out.println("Player at position "+pos+" is : " + name[pos-1]);
		
		}
		catch(NegativeArraySizeException e1)
		{
			System.out.println(e1.getClass().getName());
			System.exit(0);
		}
		catch(ArrayIndexOutOfBoundsException e2)
		{
			System.out.println(e2.getClass().getName());
			
		}

	}

}
