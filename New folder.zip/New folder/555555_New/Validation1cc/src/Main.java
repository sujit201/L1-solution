import java.util.Scanner;





public class Main {



  public static void main(String[] args) {

		// TODO Auto-generated method stub



		Scanner s=new Scanner(System.in);

		String str=s.nextLine();

		if(str.matches("^[0-9]{4}[A-Z][a-zA-Z ]{4,20}[0-9]"))

			System.out.println("Valid");

		else

			System.out.println("Invalid");

	}



}

