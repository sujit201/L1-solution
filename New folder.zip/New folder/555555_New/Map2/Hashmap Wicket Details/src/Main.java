import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Map<String, String> map = new HashMap<String, String>();
		String choice;
		int k=0;
		Wicket w = null;
		do{
			System.out.println("Enter the player name");
			String name = sc.nextLine();
			System.out.println("Enter wickets - seperated by \"|\" symbol");
			String wickets = sc.nextLine();
			//String s[] = wickets.split("\\|");
			//Bowler b = new Bowler(name);
			//for (int i = 0; i < s.length; i++) {

				//w = new Wicket(s[i], b);
				//System.out.println(s[i]);
				map.put(name, wickets);
			//}
			System.out.println("Do you want to add another player (yes/no)");
			choice = sc.nextLine();
		}while (choice.equals("yes"));
		
		
		Set<Map.Entry<String, String>> values = map.entrySet();
		//System.out.println(map.entrySet());
		do {

			System.out.println("Enter the player name to search");
			String psrch = sc.nextLine();

			for (Map.Entry<String, String> entry : values) {
				if (psrch.equals(entry.getKey())) {
					k = 1;
					System.out.println("Player Name : " + entry.getKey());
					
					System.out.println("Wickets :");
					String[] s=entry.getValue().split("\\|");
					for (int i = 0; i < s.length; i++)
					System.out.println(s[i]);//break;
				}
			}
			if (k == 0) {
				System.out.println("No player found with the name " + psrch);
			}
			System.out.println("Do you want to search another player (yes/no)");
			choice = sc.nextLine();
		} while (choice.equals("yes"));

	}

}
