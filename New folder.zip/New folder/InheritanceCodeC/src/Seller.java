import java.text.DecimalFormat;

public class Seller extends User {
	private String description;
	private Double rating;

	public Seller(String name, String username, String password, String email, String phonenumber, String description,
			Double rating) {
		super(name, username, password, email, phonenumber);
		this.description = description;
		this.rating = rating;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public void displayDetails() {
		super.displayDetails();

		DecimalFormat df = new DecimalFormat("##.00"); 
		System.out.println("Description : " + description);
		System.out.println("Rating : " + df.format(rating));

	}
}
