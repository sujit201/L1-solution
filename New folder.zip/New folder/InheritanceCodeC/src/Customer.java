
public class Customer extends User {

	private String deliveryAddress;
	private int bonusPoints;
	private String creditDetails;

	public Customer(String name, String username, String password, String email, String phonenumber,
			String deliveryAddress, int bonusPoints, String creditDetails) {
		super(name, username, password, email, phonenumber);
		this.deliveryAddress = deliveryAddress;
		this.bonusPoints = bonusPoints;
		this.creditDetails = creditDetails;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public int getBonusPoints() {
		return bonusPoints;
	}

	public void setBonusPoints(int bonusPoints) {
		this.bonusPoints = bonusPoints;
	}

	public String getCreditDetails() {
		return creditDetails;
	}

	public void setCreditDetails(String creditDetails) {
		this.creditDetails = creditDetails;
	}

	public void displayDetails() {
		super.displayDetails();

		System.out.println("Delivery address : " + deliveryAddress);
		System.out.println("Bonus points : " + bonusPoints);
		System.out.println("Credit details : " + creditDetails);

	}
}
