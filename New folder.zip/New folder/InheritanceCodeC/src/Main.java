import java.util.*;

class Main {

	public static void main(String args[]) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the name of the user :");
		String name = s.nextLine();

		System.out.println("Enter the username :");
		String uName = s.nextLine();

		System.out.println("Enter the password :");
		String pass = s.nextLine();

		System.out.println("Enter the email :");
		String email = s.nextLine();

		System.out.println("Enter the phonenumber :");
		String pNo = s.nextLine();

		System.out.println("Enter the type of user");
		System.out.println("1.Customer");
		System.out.println("2.Seller");

		int choice = Integer.parseInt(s.nextLine());

		switch (choice) {
		case 1:
			System.out.println("Enter the delivery address :");
			String add = s.nextLine();

			System.out.println("Enter the bonus points :");
			int bPoint = Integer.parseInt(s.nextLine());

			System.out.println("Enter the credit details :");
			String cDetails = s.nextLine();

			System.out.println("Customer Details :");
			User c = new Customer(name, uName, pass, email, pNo, add, bPoint, cDetails);
			c.displayDetails();

			break;
		case 2:
			System.out.println("Enter the description :");
			String desc = s.nextLine();

			System.out.println("Enter the rating :");
			double r = Double.parseDouble(s.nextLine());

			System.out.println("Seller Details :");
			User seller = new Seller(name, uName, pass, email, pNo, desc, r);
			seller.displayDetails();

			break;
		}

	}

}
