
public class Rectangle extends Shape {
	
	private int length;
	private int breadth;
	
	public Rectangle(int length, int breadth) {
		super.shapeName="Rectangle";
		this.length = length;
		this.breadth = breadth;
	}
	
	
	public Rectangle() {
		
	}
	
	double area = 0;
	
	public double calculateArea()
	{
		area = length*breadth;
		return area;
	}
	
	

}
