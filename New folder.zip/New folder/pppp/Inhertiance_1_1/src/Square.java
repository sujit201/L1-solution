
public class Square extends Shape {
	
	private int side;
	
	

	public Square() {
		
	}

	public Square(int side) {
		super.shapeName = "Square";
		this.side = side;
	}
	
	double area = 0;
	
	public double calculateArea()
	{
		area = side*side;
		return area;
	}

}
