
public class Circle extends Shape {
	
	private int radius;

	public Circle(int radius) {
		super.shapeName="Circle";
		this.radius = radius;
	}

	public Circle() {
		
	}
	
	double area = 0.0;
	
	public double calculateArea()
	{
		area = radius*radius*(3.14159);
		return area;
	}
	
	

}
