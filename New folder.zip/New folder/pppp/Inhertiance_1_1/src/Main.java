import java.util.*;
import java.text.*;

public class Main {

	public static void main(String[] args) {

		int choice = 0;
		int l = 0, b = 0, r = 0, si = 0;

		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("##.00");

//		while (true) {

			System.out.println("1. Rectangle");
			System.out.println("2. Square");
			System.out.println("3. Circle");
			System.out.println("Area Calculator --- Choose your shape");

			choice = Integer.parseInt(sc.nextLine());

			switch (choice) {

			case 1:
				System.out.println("Enter length and breadth:");
				l = Integer.parseInt(sc.nextLine());
				b = Integer.parseInt(sc.nextLine());

				Shape s1 = new Rectangle(l, b);

				System.out.println("Area of " + s1.getShapeName() + " is:" + df.format(s1.calculateArea()));
				// System.out.println("Area of Rectangle
				// is:"+s.calculateArea());
				break;

			case 2:
				System.out.println("Enter side:");
				si = Integer.parseInt(sc.nextLine());

				Shape s2 = new Square(si);
				System.out.println("Area of " + s2.getShapeName() + " is:" + df.format(s2.calculateArea()));

				break;

			case 3:
				System.out.println("Enter Radius:");
				r = Integer.parseInt(sc.nextLine());

				Shape s3 = new Circle(r);
				System.out.println("Area of " + s3.getShapeName() + " is:" + df.format(s3.calculateArea()));
				
				

			}

		}

	}


