
public class Bowler extends Player {

	private Long noOfWickets;

	public Bowler(String name, String teamName, long noOfMatches,long noOfWickets) {
		super(name, teamName, noOfMatches);
		this.noOfWickets = noOfWickets;
		
	}
	
	void displayDetails()
	{
		System.out.println("Bowler : "+super.getName());
		super.displayDetails();
		System.out.println("Number of wickets taken : "+noOfWickets);
		
	}
	
	

}
