import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter player name");
		String name = s.nextLine();

		System.out.println("Enter team name");
		String team = s.nextLine();

		System.out.println("Enter number of matches");
		int noOfMatches = Integer.parseInt(s.nextLine());

		System.out.println("Menu");
		System.out.println("1.Bowler details");
		System.out.println("2.Batsman details");
		System.out.println("Enter choice");

		int choice = Integer.parseInt(s.nextLine());

		switch (choice) {
		case 1:
			System.out.println("Enter number of wickets taken");
			long wickets = Long.parseLong(s.nextLine());

			Player bowler = new Bowler(name, team, noOfMatches, wickets);

			bowler.displayDetails();

			break;
		case 2:
			System.out.println("Enter number of runs scored");
			long runs = Long.parseLong(s.nextLine());

			Player batsman = new Batsman(name, team, noOfMatches, runs);

			batsman.displayDetails();
			break;

		}

	}

}
