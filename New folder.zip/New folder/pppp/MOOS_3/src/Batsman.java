
public class Batsman extends Player {

	private long noOfRuns;

	public Batsman(String name, String teamName, long noOfMatches, long noOfRuns) {
		super(name, teamName, noOfMatches);

		this.noOfRuns = noOfRuns;
	}
	
	void displayDetails()
	{
		System.out.println("Batsman : "+super.getName());
		super.displayDetails();
		System.out.println("Number of runs scored : "+noOfRuns);
		
	}

}
