
public class Vehicle {

	protected String make;
	protected String vehicleNumber;

	protected String fuelType;

	protected int fuelCapacity;
	protected int cc;

	public Vehicle() {
		super();
	}

	public Vehicle(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc) {
		super();
		this.make = make;
		this.vehicleNumber = vehicleNumber;
		this.fuelType = fuelType;
		this.fuelCapacity = fuelCapacity;
		this.cc = cc;
	}

	public void displayMake() {
		System.out.println("***" + make + "***");

	}

	public void displayBasicInfo() {

		System.out.println("---Basic Information---");
		System.out.println("Vehicle Number:" + vehicleNumber);
		System.out.println("Fuel Capacity:" + fuelCapacity);
		if(fuelType.equals("Petrol"))
		{
			System.out.println("Fuel Type:Petrol");
		}
		else
		{
			System.out.println("Fuel Type:Diesel");
		}
		
		System.out.println("CC:" + cc);

	}

	public void displayDetailInfo() {
		System.out.println("---Detail Information---");

	}

}
