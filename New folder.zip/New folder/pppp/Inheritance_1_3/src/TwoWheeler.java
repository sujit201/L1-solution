
public class TwoWheeler extends Vehicle {

	private Boolean kickStartAvailable;
	
	

	public TwoWheeler(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc) {
		super(make, vehicleNumber, fuelType, fuelCapacity, cc);
	}

	public TwoWheeler(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc,
			Boolean kickStartAvailable) {
		super(make, vehicleNumber, fuelType, fuelCapacity, cc);
		this.kickStartAvailable = kickStartAvailable;
	}

	public void displayDetailInfo() {
		super.displayDetailInfo();
		
		if(kickStartAvailable == true)
		{
			System.out.println("Kick Start Available:YES");
		}
		else
		{
			System.out.println("Kick Start Available:NO");
		}
				
		
		
		

	}

}
