import java.util.*;

public class Main {

	public static void main(String[] args) {

		String m = "", m1 = "", ch = "", ch1 = "", as = "", vn = "", vn1 = "", a = "";
		int fc = 0, fc1 = 0, c = 0, c1 = 0, door = 0;
		boolean ks;

		int l = 0, l1 = 0;

		Scanner s = new Scanner(System.in);

		System.out.println("1.Four Wheeler");

		System.out.println("2.Two Wheeler");

		System.out.println("Enter Vehicle Type:");

		int type = Integer.parseInt(s.nextLine());

		switch (type) {
		case 1:

			System.out.println("Vehicle Make:");
			m = s.nextLine();

			System.out.println("Vehicle Number:");
			vn = s.nextLine();

			System.out.println("Fuel Type:");
			System.out.println("1.Petrol");
			System.out.println("2.Diesel");

			l = Integer.parseInt(s.nextLine());

			if (l == 1) {
				ch = "Petrol";
			}

			else {
				ch = "Diesel";
			}

			System.out.println("Fuel Capacity:");

			fc = Integer.parseInt(s.nextLine());

			System.out.println("Engine CC:");
			c = Integer.parseInt(s.nextLine());

			System.out.println("Audio System:");
			as = s.nextLine();

			System.out.println("Number of Doors:");
			door = Integer.parseInt(s.nextLine());

			Vehicle v = new FourWheeler(m, vn, ch, fc, c, as, door);
			v.displayMake();
			v.displayBasicInfo();
//			System.out.println("---Detail Information---");
			v.displayDetailInfo();
			break;

		case 2:

			System.out.println("Vehicle Make:");
			m1 = s.nextLine();

			System.out.println("Vehicle Number:");
			vn1 = s.nextLine();

			System.out.println("Fuel Type:");
			System.out.println("1.Petrol");
			System.out.println("2.Diesel");

			l1 = Integer.parseInt(s.nextLine());

			if (l1 == 1) {
				ch1 = "Petrol";
			}

			else {
				ch1 = "Diesel";
			}

			System.out.println("Fuel Capacity:");

			fc1 = Integer.parseInt(s.nextLine());

			System.out.println("Engine CC:");
			c1 = Integer.parseInt(s.nextLine());

			System.out.println("Kick Start Available(yes/no):");
			a = s.nextLine();

			if (a.equals("yes")) {
				ks = true;
			} else

			{
				ks = false;
			}

			Vehicle v1 = new TwoWheeler(m1, vn1, ch1, fc1, c1, ks);

			v1.displayMake();
			v1.displayBasicInfo();
//			System.out.println("---Detail Information---");
			v1.displayDetailInfo();
			break;

		}

	}

}
