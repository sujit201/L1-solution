
public class Delivery {

	void displayDeliveryDetails(String bowler, String batsman) {

		String arr1[] = new String[2];
		String arr2[] = new String[2];

		arr1 = bowler.split(" ");
		arr2 = batsman.split(" ");



		System.out.println("Bowler : " + arr1[1]);
		System.out.println("Batsman : " + arr2[1]);

	}

	void displayDeliveryDetails(Long runs) {

		if (runs == 6) {
			System.out.println("Number of runs scored in the delivery : "+runs+"\n"+"It is a Sixer.");
		}

		else if (runs == 4) {
			System.out.println("Number of runs scored in the delivery : "+runs+"\n"+"It is a Boundary.");

		} else {
			System.out.println("Number of runs scored in the delivery : " + runs);
		}

	}

}
