import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Menu");

		System.out.println("1.Player details of the delivery");

		System.out.println("2.Run details of the delivery");

		int choice = Integer.parseInt(s.nextLine());
		String bName = "", btName = "";
		long runs = 0;

		switch (choice) {

		case 1:
			System.out.println("Enter the bowler name");
			bName = s.nextLine();

			System.out.println("Enter the batsman name");
			btName = s.nextLine();

			Delivery delivery1 = new Delivery();
			delivery1.displayDeliveryDetails(bName, btName);
			break;
		case 2:
			System.out.println("Enter the number of runs");
			runs = Long.parseLong(s.nextLine());

			Delivery delivery2 = new Delivery();
			delivery2.displayDeliveryDetails(runs);

		}

	}

}
