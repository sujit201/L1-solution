import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

	public static void main(String[] args) throws ParseException {

		String d = "", str = "",wt="";
		int noOfRuns=0;
		Scanner s = new Scanner(System.in);

		System.out.println("Menu");

		System.out.println("1.Match Date");

		System.out.println("2.Match Venue");

		System.out.println("3.Match Outcome");

		int choice = Integer.parseInt(s.nextLine());

		switch (choice) {

		case 1:
			System.out.println("Enter the date of the match");

			d = s.nextLine();

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

			Date matchDate = sdf.parse(d);

			Match m1 = new Match();

			m1.displayMatchDetails(matchDate);
			break;

		case 2:

			System.out.println("Enter venue of the match");

			str = s.nextLine();

			Match m2 = new Match();

			m2.displayMatchDetails(str);
			break;
		case 3:
			
			System.out.println("Enter the winner team of the match");

			 wt = s.nextLine();

			System.out.println("Enter the number of runs");

			noOfRuns = Integer.parseInt(s.nextLine());
			
			Match m3 = new Match();

			m3.displayMatchDetails(wt,noOfRuns);
			break;

			

		}

	}

}
