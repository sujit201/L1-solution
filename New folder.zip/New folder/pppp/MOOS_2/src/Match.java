import java.text.SimpleDateFormat;
import java.util.Date;

public class Match {
	void displayMatchDetails(Date matchDate) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyy");

		String matchDate1 = sdf.format(matchDate);

		System.out.println("Match Date : " + matchDate1);
	}

	void displayMatchDetails(String venue) {
		String arr[] = new String[2];

		arr = venue.split(",");
		System.out.println("Match Venue :");
		System.out.println("Stadium : " + arr[0]);
		System.out.println("City : " + arr[1]);

	}

	void displayMatchDetails(String winnerTeam, long runs) {
		System.out.println("Match Outcome :");
		System.out.println(winnerTeam + " won by " +runs+ " runs");

	}

}
