import java.util.*;

public class Main {

	public static void main(String[] args) {

		String name1 = "", name2 = "", name3 = "";
		int area1 = 0, area2 = 0, area3 = 0;
		boolean tv1, tv2, tv3, wifi1, wifi2, wifi3;
		String ip1, ip2, ip3, ip4, ip5, ip6;

		Scanner s = new Scanner(System.in);
		System.out.println("Hotel Tariff Calculator");

		System.out.println("1. Deluxe Room");
		System.out.println("2. Deluxe AC Room");
		System.out.println("3. Suite AC Room");
		System.out.println("Select Room Type:");

		int l = Integer.parseInt(s.nextLine());

		switch (l) {
		case 1:
			System.out.println("Hotel Name:");
			name1 = s.nextLine();

			System.out.println("Room Square Feet Area:");
			area1 = Integer.parseInt(s.nextLine());

			System.out.println("Room has TV (yes/no):");
			ip1 = s.nextLine();

			if (ip1.equals("yes")) {
				tv1 = true;
			}

			else

			{
				tv1 = false;
			}

			System.out.println("Room has Wifi (yes/no):");

			ip2 = s.nextLine();

			if (ip2.equals("yes")) {
				wifi1 = true;
			}

			else {
				wifi1 = false;
			}

			HotelRoom hm = new DeluxeRoom(name1, area1, tv1, wifi1);
		
			System.out.println("Room Tariff per day is:" +hm.calculateTariff());

			break;

		case 2:
			System.out.println("Hotel Name:");
			name2 = s.nextLine();

			System.out.println("Room Square Feet Area:");
			area2 = Integer.parseInt(s.nextLine());

			System.out.println("Room has TV (yes/no):");
			ip3 = s.nextLine();

			if (ip3.equals("yes")) {
				tv2 = true;
			}

			else

			{
				tv2 = false;
			}

			System.out.println("Room has Wifi (yes/no):");
			ip4 = s.nextLine();

			if (ip4.equals("yes")) {
				wifi2 = true;
			}

			else {
				wifi2 = false;
			}

			DeluxeRoom dm = new DeluxeACRoom(name2, area2, tv2, wifi2);
			
			System.out.println("Room Tariff per day is:" + dm.calculateTariff());
			

			break;

		case 3:
			System.out.println("Hotel Name:");
			name3 = s.nextLine();

			System.out.println("Room Square Feet Area:");
			area3 = Integer.parseInt(s.nextLine());

			System.out.println("Room has TV (yes/no):");
			ip5 = s.nextLine();

			if (ip5.equals("yes")) {
				tv3 = true;
			}

			else

			{
				tv3 = false;
			}

			System.out.println("Room has Wifi (yes/no):");
			ip6 = s.nextLine();

			if (ip6.equals("yes")) {
				wifi3 = true;
			}

			else {
				wifi3 = false;
			}

			HotelRoom sm = new SuiteACRoom(name3, area3, tv3, wifi3);
			
			System.out.println("Room Tariff per day is:" + sm.calculateTariff());
			break;

		}
	}
}
