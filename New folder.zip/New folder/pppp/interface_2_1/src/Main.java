
import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);

		System.out.println("Enter player name");
		String name=scan.nextLine();

		System.out.println("Enter team name");
		String teamName=scan.nextLine();

		System.out.println("Enter number of matches played");
		int noOfMatches =Integer.parseInt(scan.nextLine());

		System.out.println("Enter total runs scored");
		long totalRunsScored=Long.parseLong(scan.nextLine());

		System.out.println("Enter number of wickets taken");
		int noOfWicketsTaken=Integer.parseInt(scan.nextLine());
		Player p=new Player
				(name,teamName,noOfMatches,totalRunsScored,noOfWicketsTaken);
		p.displayPlayerStatistics();

	}

}
