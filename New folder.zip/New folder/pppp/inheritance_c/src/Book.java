import java.text.DecimalFormat;

public class Book
{
	protected  String name;
	protected  String author;
	protected double price;
	protected  String publication;
	public Book(String name, String author, double price, String publication) {
		super();
		this.name = name;
		this.author = author;
		this.price = price;
		this.publication = publication;
	}

	 DecimalFormat df =new DecimalFormat("#.00");

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPublication() {
		return publication;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	void displayDetails()
	{
		System.out.println("Book Details");
		System.out.println("Name of the book:"+name);
		System.out.println("Author:"+author);
		System.out.println("Price:"+df.format(price));
		System.out.println("Publication:"+publication);

	}
}


