import java.io.IOException;
import java.util.Scanner;

class Main 
{ 

	public static void main(String args[]) throws IOException
	{ 
		Scanner scan=new Scanner(System.in);
		//Book b3=new Book();
		System.out.println("Enter the book name");
		String name=scan.nextLine();
		//b3.setName(name);
		System.out.println("Enter the author name");
		String author=scan.nextLine();
		//b3.setAuthor(author);
		System.out.println("Enter the price");
		double price=Double.parseDouble(scan.nextLine());
		//b3.setPrice(price);
		System.out.println("Enter the publication name");
		String publication=scan.nextLine();
		//b3.setPublication(publication);
		//Book b=new Book(name,author,price,publication);


		System.out.println("Enter the type of book");
		System.out.println("1.PrintedBook");
		System.out.println("2.EBook");
		int ch=Integer.parseInt(scan.nextLine());
		switch(ch)
		{
		case 1:

			System.out.println("Enter the number of pages of the book");
			int numOfPages=Integer.parseInt(scan.nextLine());
			System.out.println("Enter the binding type of the book");
			String bindingType=scan.nextLine();
			System.out.println("Enter the paper type of the book");
			String paperType=scan.nextLine();
			PrintedBook pb1=new PrintedBook(name,author,price,publication,numOfPages,bindingType,paperType);
			System.out.println("Printed Book Details");
			pb1.displayDetails();
			break;
		case 2:
			System.out.println("Enter the disk type of the book");
			String diskType=scan.nextLine();
			System.out.println("Enter the size of the disk");
			double size=Double.parseDouble(scan.nextLine());
			Ebook eb=new Ebook (name,author,price,publication,diskType,size);
			System.out.println("EBook Details");
			eb.displayDetails();
			break;

		}

	}


}

