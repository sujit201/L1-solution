import java.text.DecimalFormat;

public class Ebook extends Book{
	private String 	diskType;
	private double size;
	//fill the code    



	public Ebook() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Ebook(String name, String author, double price, String publication) {
		super(name, author, price, publication);
		// TODO Auto-generated constructor stub
	}


	public Ebook(String name, String author, double price, String publication, String diskType, double size) {
		super(name, author, price, publication);
		this.diskType = diskType;
		this.size = size;
	}


	public String getDiskType() {
		return diskType;
	}


	public void setDiskType(String diskType) {
		this.diskType = diskType;
	}


	public double getSize() {
		return size;
	}


	public void setSize(double size) {
		this.size = size;
	}
	DecimalFormat df =new DecimalFormat("#.00");
	
	void displayDetails()
	{
	
		System.out.println("Name of the book :"+name);
		System.out.println("Author:"+author);
		System.out.println("Price:"+df.format(price));
		System.out.println("Publication:"+publication);
		System.out.println("Disk type:"+diskType);
		System.out.println("Size:"+df.format(size));


	}	



}


