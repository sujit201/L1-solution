import java.text.DecimalFormat;

public class PrintedBook extends Book
{
	private int numOfPages;
	private String bindingType;
	private String paperType;

	public PrintedBook() {
		// TODO Auto-generated constructor stub
	}

	DecimalFormat df =new DecimalFormat("#.00");

	public PrintedBook(String name, String author, double price, String publication, int numOfPages, String bindingType,
			String paperType) {
		super(name, author, price, publication);
		this.numOfPages = numOfPages;
		this.bindingType = bindingType;
		this.paperType = paperType;
	}



	public int getNumOfPages() {
		return numOfPages;
	}


	public void setNumOfPages(int numOfPages) {
		this.numOfPages = numOfPages;
	}


	public String getBindingType() {
		return bindingType;
	}


	public void setBindingType(String bindingType) {
		this.bindingType = bindingType;
	}


	public String getPaperType() {
		return paperType;
	}


	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}

	Book b=new Book();
	void displayDetails()
	{
	
		System.out.println("Name of the book :"+name);
		System.out.println("Author:"+author);
		System.out.println("Price:"+df.format(price));
		System.out.println("Publication:"+publication);
		System.out.println("Number of Pages:"+numOfPages);
		System.out.println("Binding type:"+bindingType);
		System.out.println("Paper type:"+paperType);
	}
}


