  
public class TestMatch extends Match {
	
	public TestMatch() {
		super();
	}

	public TestMatch(int currentScore, float currentOver, int target) {
		super(currentScore, currentOver, target);

	}

	

	public float calculateRunrate() {
		float runs = super.getTarget() - super.getCurrentScore();
		float balls = (int) (90 - super.getCurrentOver());

		float reqRunRate = runs / balls;
		return reqRunRate;

	}

	public int calculateBalls() {
		float balls = (int) (90 - super.getCurrentOver());
		int ballss = (int) (balls * 6);
		return ballss;

	}
	
	public void display(double reqRunRate, int balls) {
		System.out.println("Requirements:");
		System.out.println("Need " + (super.getTarget() - super.getCurrentScore()) + (balls > 1 ? " Runs" : " Run") + " in " + balls
				+ (balls > 1 ? " balls" : " ball"));
		System.out.format("Required Run Rate - %.2f\n", reqRunRate);
	}

}


