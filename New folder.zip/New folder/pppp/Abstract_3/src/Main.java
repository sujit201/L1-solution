import java.util.*;

public class Main {

	public static void main(String[] args) {
		int cs = 0, co = 0, ts = 0;
		int cs1 = 0, co1 = 0, ts1 = 0;
		int cs2 = 0, co2 = 0, ts2 = 0;
		Scanner s = new Scanner(System.in);

		System.out.println("Enter the Cricket Format");
		System.out.println("1.ODI");
		System.out.println("2.T20");
		System.out.println("3.Test");

		int choice = Integer.parseInt(s.nextLine());

		switch (choice) {

		case 1:
			System.out.println("Enter the Current Score");
			cs = Integer.parseInt(s.nextLine());
			

			System.out.println("Enter the Current Over");
			co = Integer.parseInt(s.nextLine());

			System.out.println("Enter the Target Score");
			ts = Integer.parseInt(s.nextLine());

			Match m1 = new ODIMatch(cs, co, ts);

			m1.display(m1.calculateRunrate(),m1.calculateBalls());
			break;
			
		case 2:
			System.out.println("Enter the Current Score");
			cs1 = Integer.parseInt(s.nextLine());
	
			System.out.println("Enter the Current Over");
			co1 = Integer.parseInt(s.nextLine());
	
			System.out.println("Enter the Target Score");
			ts1 = Integer.parseInt(s.nextLine());
	
			Match m2 = new T20Match(cs1, co1, ts1);
			
			m2.display(m2.calculateRunrate(),m2.calculateBalls());
	
			
			break;
		case 3:
			System.out.println("Enter the Current Score");
			cs2 = Integer.parseInt(s.nextLine());
	
			System.out.println("Enter the Current Over");
			co2 = Integer.parseInt(s.nextLine());
	
			System.out.println("Enter the Target Score");
			ts2 = Integer.parseInt(s.nextLine());
	
			Match m3 = new TestMatch(cs2, co2, ts2);
			
			m3.display(m3.calculateRunrate(),m3.calculateBalls());
			
	
			
			break;
		case 4:
			System.out.println("Invalid Format type");
			break;
			
		
			
		}

	}

}
