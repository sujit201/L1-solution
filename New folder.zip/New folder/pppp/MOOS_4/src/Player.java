
public class Player {

	protected String name;
	protected String country;

	public Player(String name, String country) {
		super();
		this.name = name;
		this.country = country;
	}

	void displayDetails() {
		System.out.println("Player Details:");
		System.out.println("Player name : " + name);
		System.out.println("Country : " + country);

	}

}
