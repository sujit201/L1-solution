import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter player name ");
		String name = s.nextLine();

		System.out.println("Enter player country");
		String country = s.nextLine();

		System.out.println("Enter the Cap number");
		String capNo = s.nextLine();

		System.out.println("Enter the number of test appearnace");
		long testApp = Integer.parseInt(s.nextLine());

		System.out.println("Enter the number of ODI appearnace");
		long odiApp = Integer.parseInt(s.nextLine());

		Player internationalplayer = new InternationalPlayer(name, country, capNo, testApp, odiApp);
		internationalplayer.displayDetails();

	}

}
