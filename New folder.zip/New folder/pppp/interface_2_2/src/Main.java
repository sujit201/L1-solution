import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Menu");
		System.out.println("1.Crciket Player Details");
		System.out.println("2.Hockey Player Details");
		
		System.out.println("Enter choice");

		int choice = Integer.parseInt(s.nextLine());

		switch (choice) {

		case 1:

			System.out.println("Enter player name");
			String name1 = s.nextLine();

			System.out.println("Enter team name");
			String team1 = s.nextLine();

			System.out.println("Enter number of matches played");
			String matches1 = s.nextLine();

			System.out.println("Enter total runs scored");
			int runs = Integer.parseInt(s.nextLine());

			System.out.println("Enter total number of wickets taken");
			int wicket = Integer.parseInt(s.nextLine());

			Player player = new CricketPlayer(name1, team1, matches1, runs, wicket);

			((CricketPlayer) player).displayPlayerStatistics();
			
			break;
			
		case 2:
			
			System.out.println("Enter player name");
			String name2 = s.nextLine();

			System.out.println("Enter team name");
			String team2 = s.nextLine();

			System.out.println("Enter number of matches played");
			String matches2 = s.nextLine();

			System.out.println("Enter the position"); 
			String pos = s.nextLine();
			
			
			System.out.println("Enter total number of goals taken"); 
			int goal =  Integer.parseInt(s.nextLine());

			Player player2 = new HockeyPlayer(name2, team2, matches2, pos, goal);

			((HockeyPlayer) player2).displayPlayerStatistics();
			break;
		
		
		case 3:
			System.out.println("Invalid Input");
			
			

		}

	}

}
