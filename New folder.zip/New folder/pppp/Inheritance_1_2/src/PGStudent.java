class PGStudent extends Student {
	private String specialization;
	private int noOfPapersPublished;

	public PGStudent(String name, String id, int age, double grade, String address) {
		super(name, id, age, grade, address);
	}

	public PGStudent(String name, String id, int age, double grade, String address, String specialization,
			int noOfPapersPublished) {
		super(name, id, age, grade, address);
		this.specialization = specialization;
		this.noOfPapersPublished = noOfPapersPublished;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public int getNoOfPapersPublished() {
		return noOfPapersPublished;
	}

	public void setNoOfPapersPublished(int noOfPapersPublished) {
		this.noOfPapersPublished = noOfPapersPublished;
	}
	
	
	public void display() {
//		System.out.println("PG Student Details");
		super.display();
		
		System.out.println("Specialization : "+specialization);
		System.out.println("No. of papers published : "+noOfPapersPublished);
		
		

	}
	
	public boolean isPassed() {
		
		if((grade > 70) && (noOfPapersPublished > 2))
		{
			return true;
		}
		else
		{
		
		return false;
		}
		
	}

}
