
public interface IPlayerStatistics {

	public void displayPlayerStatistics();

}
