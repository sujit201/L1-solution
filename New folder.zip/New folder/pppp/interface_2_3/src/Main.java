import java.util.*;

public class Main {

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);

		String a;

		int n = 0;

		boolean f = true;

		while (f) {
			System.out.println("Menu");
			System.out.println("1.Bowler");
			System.out.println("2.Batsman");
			System.out.println("3.WicketKeeper");
			System.out.println("4.AllRounder");
			System.out.println("Enter your choice");

			n = Integer.parseInt(sc.nextLine());

			switch (n) {
			case 1:
				System.out.println("Enter the Bowler details");
				System.out.println("Enter player name");
				String name = sc.nextLine();

				System.out.println("Enter team name");
				String teamName = sc.nextLine();

				System.out.println("Enter number of matches played");
				int noOfMatches = Integer.parseInt(sc.nextLine());

				System.out.println("Enter number of wickets taken");
				int noOfWickets = Integer.parseInt(sc.nextLine());

				IPlayerStatistics p = new Bowler(name, teamName, noOfMatches, noOfWickets);
				p.displayPlayerStatistics();
				System.out.println("Do you want to continue?");
				a = sc.nextLine();
				if (a.equals("YES")) {
					f = true;
				} else {
					f = false;
				}
				break;

			case 2:
				System.out.println("Enter the Batsman details");
				System.out.println("Enter player name");
				String name1 = sc.nextLine();

				System.out.println("Enter team name");
				String teamName1 = sc.nextLine();

				System.out.println("Enter number of matches played");
				int noOfMatches1 = Integer.parseInt(sc.nextLine());

				System.out.println("Enter the runs scored");
				long runs = Long.parseLong(sc.nextLine());

				IPlayerStatistics p1 = new Batsman(name1, teamName1, noOfMatches1, runs);
				p1.displayPlayerStatistics();
				System.out.println("Do you want to continue?");
				a = sc.nextLine();
				if (a.equals("YES")) {
					f = true;
				} else {
					f = false;
				}
				break;

			case 3:
				System.out.println("Enter the WicketKeeper details");
				System.out.println("Enter player name");
				String name2 = sc.nextLine();

				System.out.println("Enter team name");
				String teamName2 = sc.nextLine();

				System.out.println("Enter number of matches played");
				int noOfMatches2 = Integer.parseInt(sc.nextLine());

				System.out.println("Enter number of catches taken");
				int noOfCatches = Integer.parseInt(sc.nextLine());

				System.out.println("Enter number of stumpings");
				int noOfStumpings = Integer.parseInt(sc.nextLine());

				System.out.println("Enter number of dismissals");
				int noOfDismissals = Integer.parseInt(sc.nextLine());

				System.out.println("Enter the runs scored");
				long runs1 = Long.parseLong(sc.nextLine());

				IPlayerStatistics p2 = new WicketKeeper(name2, teamName2, noOfMatches2, noOfCatches, noOfStumpings,
						runs1, noOfDismissals);
				p2.displayPlayerStatistics();
				System.out.println("Do you want to continue?");
				a = sc.nextLine();
				if (a.equals("YES")) {
					f = true;
				} else {
					f = false;
				}
				break;

			case 4:
				System.out.println("Enter the AllRounder details");
				System.out.println("Enter player name");
				String name3 = sc.nextLine();

				System.out.println("Enter team name");
				String teamName3 = sc.nextLine();

				System.out.println("Enter number of matches played");
				int noOfMatches3 = Integer.parseInt(sc.nextLine());

				System.out.println("Enter the runs scored");
				long runs2 = Long.parseLong(sc.nextLine());

				System.out.println("Enter number of wickets taken ");
				int noOfWickets1 = Integer.parseInt(sc.nextLine());

				IPlayerStatistics p3 = new AllRounder(name3, teamName3, noOfMatches3, runs2, noOfWickets1);
				p3.displayPlayerStatistics();
				System.out.println("Do you want to continue?");
				a = sc.nextLine();
				if (a.equals("YES")) {
					f = true;
				} else {
					f = false;
				}
				break;

			default:

				System.out.println("Please Enter a Valid Input");
				break;
			}

		}

	}
}
