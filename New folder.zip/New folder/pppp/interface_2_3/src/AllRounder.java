
public class AllRounder extends CricketPlayer implements IPlayerStatistics {

	private long runs;
	private int noOfWickets;

	public AllRounder(String name, String teamName, int noOfMatches, long runs, int noOfWickets) {
		super(name, teamName, noOfMatches);
		this.runs = runs;
		this.noOfWickets = noOfWickets;
	}

	@Override
	public void displayPlayerStatistics() {

		System.out.println("Player name : " + super.getName());
		System.out.println("Team name : " + super.getTeamName());
		System.out.println("No of matches : " + super.getNoOfMatches());
		System.out.println("Runs scored : " + runs);
		System.out.println("No of wickets taken : " + noOfWickets);

	}

}
