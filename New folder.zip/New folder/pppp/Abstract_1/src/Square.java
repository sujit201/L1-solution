
public class Square extends Shape
{

	private Integer side;

	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	public Square(String name,Integer side) {
		super();
		this.side = side;
	}
	float area=0;
	@Override
	public float calculateArea() {
		area=side*side;
		return area;
	}



}

