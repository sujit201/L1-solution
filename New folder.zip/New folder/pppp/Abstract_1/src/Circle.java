
public class Circle extends Shape
{

	private Integer radius;

	public Integer getRadius() 
	{
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

	public Circle(String name,Integer radius) 
	{
		super();
		this.radius = radius;
	}

	@Override
	public float calculateArea()
	{
		float area=(float) (radius*radius*(3.14));
		return area;
	}




}
