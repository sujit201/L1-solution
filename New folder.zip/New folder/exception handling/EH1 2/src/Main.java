import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	  try{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of overs");
		int overs=sc.nextInt();
		int runs[]=new int[overs];
		System.out.println("Enter the number of runs for each over");
		for(int i=0;i<overs;i++){
			runs[i]=sc.nextInt();
		}
		System.out.println("Enter the over number");
		int over=sc.nextInt();
		System.out.println(runs[over-1]);
	  }
	  catch(Exception e){
		  System.out.println(e.getClass().getName());
	  }
	}

}
