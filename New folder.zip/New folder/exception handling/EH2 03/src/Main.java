import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the total runs scored");
		double d1 = Double.parseDouble(s.nextLine());

		System.out.println("Enter the total overs faced");
		double d2 = Double.parseDouble(s.nextLine());
		try {

			if (d2 > 20 || d2 <= 0)

			{

				throw new OverRangeException();

			}

			else {
				DecimalFormat df = new DecimalFormat("##.00");
				double rr = d1 / d2;
				System.out.println("Current Run Rate :" + df.format(rr));
			}

		}

		catch (OverRangeException e)

		{

			System.out.println(e);

		}

	}

}
