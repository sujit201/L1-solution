
public class OverRangeException extends Exception 

{
	public OverRangeException() {
	}
	public OverRangeException(String message) {
		super(message);
	}
	@Override
	public String toString() {
		return "OverRangeException: Over is not in the specified range";
	}
}
