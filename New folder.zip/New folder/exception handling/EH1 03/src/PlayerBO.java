import java.util.Iterator;

public class PlayerBO {
	public void displayPlayerDetails(Player pp){
		System.out.println(pp.getName()+", "+pp.getCountry()+", "+pp.getSkill());
	}
}
