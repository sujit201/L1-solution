import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of players");
		int num=Integer.parseInt(sc.nextLine());
		System.out.println("Do you know the details of the captain? Type Yes / No");
		String yn=sc.nextLine();
		String cap = null,cou = null,skill = null;
		if(yn.equals("Yes")){
		System.out.println("Enter name of the captain");
		 cap=sc.nextLine();
		System.out.println("Enter country of the captain");
		 cou=sc.nextLine();
		System.out.println("Enter skillset of the captain");
		 skill=sc.nextLine();
		}
		
		String pn[]=new String[num];
		String pc[]=new String[num];
		String ps[]=new String[num];
		for(int i=0;i<num;i++){
			System.out.println("Enter name of player "+(i+1));
			pn[i]=sc.nextLine();
			System.out.println("Enter country of player "+(i+1));
			pc[i]=sc.nextLine();
			System.out.println("Enter skillset of player "+(i+1));
			ps[i]=sc.nextLine();
		}
		if(yn.equals("Yes")){
			Player p=new Player(cap,cou,skill);
			PlayerBO pb=new PlayerBO();
			pb.displayPlayerDetails(p);
		}
		else{
			try{
			  throw new NullPointerException();
			}
			catch (NullPointerException e) {

				  System.out.println("Exception Occured : " + e.getClass().getName());

				  System.out.println("Captain details not available");

				 }
		}
		System.out.println("Player Details");
		PlayerBO pbo=new PlayerBO();
		for(int i=0;i<num;i++){
			Player p1=new Player(pn[i], pc[i], ps[i]);
			pbo.displayPlayerDetails(p1);
		}
		
	}

}
