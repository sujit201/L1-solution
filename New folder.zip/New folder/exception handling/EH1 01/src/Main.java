import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
	  try{
		System.out.println("Enter the total runs scored");
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		int runs=Integer.parseInt(bf.readLine());
		System.out.println("Enter the total overs faced");
		int over=Integer.parseInt(bf.readLine());
		float op=runs/over;
		op=(float)runs/(float)over;
		System.out.printf("Current Run Rate : %.2f",op);
	  }
	  catch(Exception e){
		  System.out.println(e.getClass().getName());
	  }
	}

}
