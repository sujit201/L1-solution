import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the expected winner team of IPL Season 4");
		String t1 = sc.nextLine();
		
		try{
			if(t1.equals("Chennai Super Kings") ||t1.equals("Deccan Chargers")||t1.equals("Delhi Daredevils")||t1.equals("Kings XI Punjab")||t1.equals("Kolkata Knight Riders")||
					t1.equals("Mumbai Indians")||t1.equals("Rajasthan Royals")||t1.equals("Royal Challengers Bangalore"))
					{
				  
						System.out.println("Enter the expected runner Team of IPL Season 4");
						String t2 = sc.nextLine();
					
						if(t2.equals("Chennai Super Kings") ||t2.equals("Deccan Chargers")||t2.equals("Delhi Daredevils")||
								t2.equals("Kings XI Punjab")||t2.equals("Kolkata Knight Riders")||t2.equals("Mumbai Indians")||t2.equals("Rajasthan Royals")||t2.equals("Royal Challengers Bangalore"))
						{
							System.out.println("Expected IPL Season 4 winner: "+t1);
						    System.out.println("Expected IPL Season 4 runner: "+t2);
						}
						
						else
						{
							throw new TeamNameNotFound();
						}
				
					}
			else
			{
				throw new TeamNameNotFound();
			}
			
		}catch(TeamNameNotFound e){}
		
	}

}
