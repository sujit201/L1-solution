
public class TeamNameNotFound extends Exception {
	
	public TeamNameNotFound(){
		
		System.out.println("TeamNameNotFoundException: Entered team is not a part of IPL Season 4");
	}

}
