import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		try {
			Class cc = Class.forName("Player"); //Load the class dynamically
			Player p = (Player) cc.newInstance();// Create the Object of player; newInstance Method will invoke the default constructor of player 

			
		} catch (InstantiationException e) {
			System.out.println("Trying to invoke a no-argument constructor (that is not available) using newInstance method\nException Occured : java.lang.InstantiationException");
		
			System.out.println("Enter name of the player");
			String name = s.nextLine();
			//p.setName(name);

			System.out.println("Enter country of the player");
			String country = s.nextLine();
			//p.setCountry(country);

			System.out.println("Enter skillset of the player");
			String skill = s.nextLine();
			//p.setSkill(skill);
			Player p=new Player(name, country, skill);
			System.out.println(p);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
