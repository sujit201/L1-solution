
public class DuplicateIdException extends Exception{
public DuplicateIdException() {
	System.out.println("DuplicateIdException: Player Id must be unique");
}
}
