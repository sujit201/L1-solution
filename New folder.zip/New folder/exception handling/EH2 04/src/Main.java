import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the team name");
		String tn=sc.nextLine();
		System.out.println("Enter the number of players suggested");
		int n=Integer.parseInt(sc.nextLine());
		int[] id=new int[n];
		String[] name=new String[n];
		for(int i=0;i<n;i++){
			id[i]=0;
		}
		for(int i=0;i<n;i++){
			System.out.println("Enter player " +(i+1)+ " details");
			id[i]=Integer.parseInt(sc.nextLine());
			name[i]=sc.nextLine();
		}
		try{
			for(int i=0;i<n;i++){
				for(int j=i+1;j<n;j++){
					if(id[i]==id[j]){
						throw new DuplicateIdException();
					}
				}
			}
			for(int i=0;i<n;i++){
				System.out.println(id[i]+" "+name[i]);
			}
			
		}
		catch(DuplicateIdException e){
			
		}

	}

}
