import java.util.*;
public class Main {

	public static void main(String[] args) {
		
		

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number of players");
		int n = Integer.parseInt(s.nextLine());
		
		String na[] = new String[n];
		String co[] = new String[n];
		String sk[] = new String[n];
		
		
		for(int i = 0 ; i < n ; i++)
		{
			System.out.println("Enter the player name");
			na[i] = s.nextLine();
			
			System.out.println("Enter the country name");
			co[i] = s.nextLine();
			
			System.out.println("Enter the skill");
			sk[i] = s.nextLine();
		}
		
		
		
			Player p[]=new Player[n];
			
					
			
					for(int i=0;i<n;i++){
			
						
			
						p[i]=new Player(na[i],co[i],sk[i]);
			
						
			
					}
			
					PlayerBO pb =new PlayerBO();
			
					pb.displayAllPlayerDetails(p);
					
					
					
					System.out.println("Enter the country name for which players details to be known");

					

					
					 
					

					 String cou =s.nextLine();

					 pb.displaySpecificPlayerDetails(p, cou);
					 
					 

					 
			
				}
		
		
		
		
		
		
		


	}


