public class PlayerBO {



	void displayAllPlayerDetails(Player[] playerList){

 System.out.println("Player Details");

// int i=1;

 for(Player p:playerList)

 {



  System.out.println(p.toString());

//  i++;

 }

 }

 public

 void displaySpecificPlayerDetails(Player[] playerList, String countryName){


 System.out.println("Player Details");  

 for(Player p:playerList)

 {

  if(p.getCountry().equals(countryName)){


  System.out.println(p.toString());



  }

  

 }

 }

}

