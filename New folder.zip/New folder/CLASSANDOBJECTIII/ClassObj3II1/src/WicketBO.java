import java.util.Scanner;



public class WicketBO {



 public void displayAllWicketDetails(Wicket[] wicketList){

 System.out.println("Wicket Details");

 int i=1;

 for(Wicket w:wicketList)

 {

  System.out.println("Wicket "+i);

  System.out.println(w.toString());

  i++;

 }

 }

 public

 void displaySpecificWicketDetails(Wicket[] wicketList, String wicketType){

 int i=1;

 for(Wicket w:wicketList)

 {

  if(w.getWicketType().equals(wicketType)){

  System.out.println("Wicket "+i);

  System.out.println(w.toString());



  }

  i++;

 }

 }

}

