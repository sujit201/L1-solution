import java.util.Scanner;



public class Main {



 public static void main(String[] args) {

 // TODO Auto-generated method stub

 Scanner sc=new Scanner(System.in);

 System.out.println("Enter the number of wickets");

 int wic=Integer.parseInt(sc.nextLine());

 String details[] = new String[wic];

 String splitop[]=new String[5];

 long o;

 long b;

 String wt;

 String pn;

 String bn;

 Wicket ww[]=new Wicket[wic];

 for(int i=0;i<wic;i++){

  System.out.println("Enter the details of wicket "+(i+1));

  details[i]=sc.nextLine();

  splitop=details[i].split(",");

  o=Long.parseLong(splitop[0]);

  b=Long.parseLong(splitop[1]);

  wt=splitop[2];

  pn=splitop[3];

  bn=splitop[4];

  ww[i]=new Wicket(o,b,wt,pn,bn);

 }

 WicketBO wbo=new WicketBO();

 wbo.displayAllWicketDetails(ww);



 System.out.println("Enter the wicket type to be searched");

 String wtip=sc.nextLine();

 wbo.displaySpecificWicketDetails(ww, wtip);



 }



}