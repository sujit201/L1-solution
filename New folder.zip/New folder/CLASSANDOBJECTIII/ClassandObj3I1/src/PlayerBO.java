
public class PlayerBO {

	void displayPlayerDetails(Player player) {
		
		
		System.out.println("Player Details");
		System.out.println(player);

	}

	

}
