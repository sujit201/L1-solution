import java.util.*;
public class Main {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the player name"); 
		String n = s.nextLine(); 
		
		
		System.out.println("Enter the country name"); 
		String c = s.nextLine();
		
		System.out.println("Enter the skill"); 
		String sk = s.nextLine();
		
		 
		Player player = new Player(n,c,sk);
		PlayerBO playerbo = new PlayerBO(); 
		
		playerbo.displayPlayerDetails(player);
		
		



	}

}
