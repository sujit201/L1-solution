import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of matches");

		int n=Integer.parseInt(sc.nextLine());

		String[] date=new String[n];

		String[] status=new String[n];

		String[] winnerTeam=new String[n];

		String[] playerOfMatch=new String[n];

		for(int i=0;i<n;i++){

			System.out.println("Enter match "+(i+1)+" details");

			System.out.println("Enter the date");

			date[i]=sc.nextLine();

			System.out.println("Enter the status");

			status[i]=sc.nextLine();

			System.out.println("Enter the winner team");

			winnerTeam[i]=sc.nextLine();

			System.out.println("Enter the player of match");

			playerOfMatch[i]=sc.nextLine();

			

		}

		Outcome[] o=new Outcome[n];

		for(int i=0;i<n;i++){

			o[i]=new Outcome(date[i], status[i], winnerTeam[i], playerOfMatch[i]);

		}

		OutcomeBO ob=new OutcomeBO();

		ob.displayAllOutcomeDetails(o);

		System.out.println("Enter the date to be searhed");

		String ds=sc.nextLine();

		ob.displaySpecificOutcomeDetails(o,ds);

	}



}

