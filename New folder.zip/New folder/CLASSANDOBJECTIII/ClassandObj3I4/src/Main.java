import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the number of players");
		int t = Integer.parseInt(s.nextLine());

		String n[] = new String[t];
		String c[] = new String[t];
		String sk[] = new String[t];

		for (int i = 0; i < t; i++) {

			System.out.println("Enter the player name");
			n[i] = s.nextLine();

			System.out.println("Enter the country name");
			c[i] = s.nextLine();

			System.out.println("Enter the skill");
			sk[i] = s.nextLine();

		}

		Player playerList[] = new Player[t];

		PlayerBO playerbo = new PlayerBO();

		for (int i = 0; i < t; i++) {
			playerList[i] = new Player(n[i], c[i], sk[i]);

		}
		playerbo.displayAllPlayerDetails(playerList);

	}
}
