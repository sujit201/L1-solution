public class PlayerBO {
	
	void displayAllPlayerDetails(Player[] playerList)
	{
//		int i=1;
		System.out.println("Player Details");
		for (Player player : playerList) {
//			System.out.println("Delivery"+"--"+i);
			System.out.println(player);
//			i++;
			
		}
	}

}
