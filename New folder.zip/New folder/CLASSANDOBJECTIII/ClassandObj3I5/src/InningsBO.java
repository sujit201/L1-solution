public class InningsBO {

public void displayAllInningsDetails(Innings[] inningsList){

	System.out.println("Innings Details");

	for(Innings ig:inningsList){

		System.out.println(ig);

	}

}

}