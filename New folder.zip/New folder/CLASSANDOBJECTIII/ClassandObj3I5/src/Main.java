import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

	

		Scanner sc=new Scanner(System.in);

		String[] bt=new String[2];

		Long[] scr=new Long[2];

		

			System.out.println("Enter the values for FirstInnings");

			System.out.println("Enter the BattingTeam");

			bt[0]=sc.nextLine();

			System.out.println("Enter the runs scored");

			scr[0]=Long.parseLong(sc.nextLine());

			

			System.out.println("Enter the values for SecondInnings");

			System.out.println("Enter the BattingTeam");

			bt[1]=sc.nextLine();

			System.out.println("Enter the runs scored");

			scr[1]=Long.parseLong(sc.nextLine());

			

		

		Innings ig[]=new Innings[2];

		

		for(int i=0;i<2;i++){

			

			ig[i]=new Innings(bt[i],scr[i]);

			

		}

		InningsBO ib=new InningsBO();

		ib.displayAllInningsDetails(ig);

	}



}