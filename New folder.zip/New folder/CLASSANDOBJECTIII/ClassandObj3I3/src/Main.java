import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the number of deliveries");
		int n = Integer.parseInt(s.nextLine());
		
		long ov[] = new long[n];
		long ba[] = new long[n];
		String bat[] = new String[n];
		String bow[] = new String[n];
		String stri[] = new String[n];

		for (int i = 0; i < n; i++) {
			System.out.println("Enter the over");
			ov[i] = Long.parseLong(s.nextLine());

			System.out.println("Enter the ball");
			ba[i] = Long.parseLong(s.nextLine());

			System.out.println("Enter the batsman");
			bat[i] = s.nextLine();

			System.out.println("Enter the bowler");
			bow[i] = s.nextLine();

			System.out.println("Enter the nonStriker");
			stri[i] = s.nextLine();

		}

		Delivery deliveryList[] =new Delivery[n];
		
		DeliveryBO deliverybo=new DeliveryBO();



		for (int i = 0; i < n; i++) {
			deliveryList[i] = new Delivery(ov[i], ba[i], bat[i], bow[i], stri[i]);	
			

		}
		deliverybo.displayAllDeliveryDetails(deliveryList);

	}
}
