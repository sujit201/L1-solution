public class DeliveryBO {
	
	void displayAllDeliveryDetails(Delivery[] deliveryList)
	{
		int i=1;
		System.out.println("Delivery Details");
		for (Delivery delivery : deliveryList) {
			System.out.println("Delivery"+"--"+i);
			System.out.println(delivery);
			i++;
			
		}
	}

}
