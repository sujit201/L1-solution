import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of matches");

		int n=Integer.parseInt(sc.nextLine());

		String[] date=new String[n];

		String[] teamOne=new String[n];

		String[] teamTwo=new String[n];

		String[] venue=new String[n];

		for(int i=0;i<n;i++){

			System.out.println("Enter match "+(i+1)+" details");

			System.out.println("Enter the match date");

			date[i]=sc.nextLine();

			System.out.println("Enter the team one");

			teamOne[i]=sc.nextLine();

			System.out.println("Enter the team two");

			teamTwo[i]=sc.nextLine();

			System.out.println("Enter the Venue");

			venue[i]=sc.nextLine();

		}

		Match[] m=new Match[n];

		for(int i=0;i<n;i++){

			m[i]=new Match(date[i],teamOne[i],teamTwo[i],venue[i]);

		}

		MatchBO mb=new MatchBO();

		mb.displayAllMatchDetails(m);

		System.out.println("Enter the date to be searched");

		String ds=sc.nextLine();

		mb.displaySpecificMatchDetails(m, ds);

	

		



	}



}