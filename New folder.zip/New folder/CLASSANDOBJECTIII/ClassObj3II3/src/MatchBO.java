public class MatchBO {

public void displayAllMatchDetails(Match[] matchList){

	System.out.println("Match Details");

	System.out.printf("%-35s %-30s %-15s %s","Team 1","Team 2","Date","Venue");

	System.out.println();

	for(Match m:matchList){

		System.out.println(m);

	}

}

public void displaySpecificMatchDetails(Match[] matchList,String date){

	System.out.println("Match Details");

	System.out.printf("%-35s %-30s %-15s %s","Team 1","Team 2","Date","Venue");

	System.out.println();

	for(Match m:matchList){

		if(m.getDate().equals(date)){

			System.out.println(m);

		}

	}

}

}