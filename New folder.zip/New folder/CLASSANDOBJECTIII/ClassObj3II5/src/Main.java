import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the number of deliveries");
		int n = Integer.parseInt(s.nextLine());

		int o[] = new int[n];
		int b[] = new int[n];
		int r[] = new int[n];
		String bats[] = new String[n];
		String bows[] = new String[n];
		String nons[] = new String[n];

		for (int i = 0; i < n; i++) {
			System.out.println("Enter the over");
			o[i] = Integer.parseInt(s.nextLine());

			System.out.println("Enter the ball");
			b[i] = Integer.parseInt(s.nextLine());

			System.out.println("Enter the runs");
			r[i] = Integer.parseInt(s.nextLine());

			System.out.println("Enter the batsman name");
			bats[i] = s.nextLine();

			System.out.println("Enter the bowler name");
			bows[i] = s.nextLine();

			System.out.println("Enter the nonStriker name");
			nons[i] = s.nextLine();

		}
		
		
	
		
		System.out.println("");
		
		
		
		
		
		
		
		
		
		
		Delivery d[] = new Delivery[n];
		
		for(int i=0;i<n;i++)
		{
			d[i] = new Delivery(o[i],b[i],r[i],bats[i],bows[i],nons[i]);
			
			
			
		}

	}

}
