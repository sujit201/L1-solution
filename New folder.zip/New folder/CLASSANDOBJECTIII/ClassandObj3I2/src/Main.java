import java.util.*;
public class Main {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the venue name"); 
		String n = s.nextLine();
		
		System.out.println("Enter the city name"); 
		String c = s.nextLine();
		
		Venue v = new Venue(n,c);
		
		VenueBO venuebo = new VenueBO();
		
		venuebo.displayVenueDetails(v);
		
		

	}

}
