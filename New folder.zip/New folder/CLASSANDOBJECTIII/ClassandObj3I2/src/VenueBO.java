
public class VenueBO {

	
	void displayVenueDetails(Venue venue)
	{
		System.out.println("Venue Details");
		System.out.println(venue);
	}
}
