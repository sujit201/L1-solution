import java.util.Calendar;
import java.util.Date;

public class UserMainCode {

	public static void displayDay(Date startDate,Date endDate)throws Exception
	{

		    Calendar startCal = Calendar.getInstance();
		    startCal.setTime(startDate);        

		    Calendar endCal = Calendar.getInstance();
		    endCal.setTime(endDate);

		     int count = 0; 

		    //Return 0 if start and end are the same
		    if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
		    	count = 0;
		    }

		    if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
		        startCal.setTime(endDate);
		        endCal.setTime(startDate);
		    }

		    do {
		       //excluding start date
		        startCal.add(Calendar.DAY_OF_MONTH, 1);
		        if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
		            ++count;
		        }
		    } while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); //excluding end date

		    System.out.println(count);
		}


	}
	
