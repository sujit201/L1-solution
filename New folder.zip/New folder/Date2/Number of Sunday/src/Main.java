import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		
		String startDate1 = sc.nextLine();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = sdf.parse(startDate1);
		
		String endDate1 =sc.nextLine();
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		Date endDate = sdf1.parse(endDate1);
		
		UserMainCode.displayDay(startDate, endDate);
		
	}

}
