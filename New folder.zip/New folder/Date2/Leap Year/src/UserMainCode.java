
public class UserMainCode {

	public static void displayYear(int y) throws Exception {

		boolean leap = false;

		if (y % 4 == 0) {
			if (y % 100 == 0) {
				// year is divisible by 400, hence the year is a leap year
				if (y % 400 == 0)
					leap = true;
				else
					leap = false;
			} else
				leap = true;
		} else
			leap = false;

		if (leap)
			System.out.println(y + " is leap year");
		else
			System.out.println(y + " is not leap year");
	}

}
