import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode {
	
	public static void displayDay(String date)throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date1 = sdf.parse(date);
		
		Calendar c = Calendar.getInstance();
		c.setTime(date1);
		c.add(Calendar.DAY_OF_MONTH,-10);
		Date bdate = c.getTime();
		
		SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
		String bdate2 = sdf3.format(bdate);
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("EEEE");
		String bdate1 = sdf1.format(bdate);
		
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date1);
		c1.add(Calendar.DAY_OF_MONTH,10);
		Date adate = c1.getTime();
		
		SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy-MM-dd");
		String adate2 = sdf4.format(adate);
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("EEEE");
		String adate1 = sdf1.format(adate);
		
		System.out.println(bdate2);
		System.out.println(bdate1);
		System.out.println(adate2);
		System.out.println(adate1);
		
	}

}
