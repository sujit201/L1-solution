import java.util.*;
import java.text.*;

public class Main {

	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		
		String date = sc.nextLine();
		
		String date1 = sc.nextLine();
		
		UserMainCode.displayAge(date,date1);	
		
	}

}
