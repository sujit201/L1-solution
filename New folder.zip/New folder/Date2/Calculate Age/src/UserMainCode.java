import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.text.*;
import java.util.*;

public class UserMainCode {
	
	public static void displayAge(String date,String date1) throws Exception
	{
	        LocalDate localDate = null;
	        DateTimeFormatter formatter = null;
	        LocalDate localDate1 = null;
	        DateTimeFormatter formatter1 = null;
	        
	        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        localDate = LocalDate.parse(date, formatter);
	        
	        formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        localDate1 = LocalDate.parse(date1, formatter1);
	        
	        Period p = Period.between(localDate, localDate1);
	        
	        System.out.println("I am  "+ p.getYears()+" years, "+p.getMonths()+" months and "+p.getDays()+" days old.");
	        
	}

}
