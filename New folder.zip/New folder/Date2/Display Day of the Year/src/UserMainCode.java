
import java.time.LocalDate;

public class UserMainCode {
	
	public static void displayDate (int y,int d)throws Exception
	
	{
		LocalDate a = LocalDate.ofYearDay(y,d);
		
		System.out.println(d+"th day of "+y+" : "+a);
	}

}
