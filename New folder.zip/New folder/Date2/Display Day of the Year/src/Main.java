import java.util.*;

public class Main {

	public static void main(String[] args) throws Exception {
		
        Scanner sc = new Scanner(System.in);
		
		int y = sc.nextInt();
		
		int d = sc.nextInt();
		
		UserMainCode.displayDate(y,d);

	}

}
