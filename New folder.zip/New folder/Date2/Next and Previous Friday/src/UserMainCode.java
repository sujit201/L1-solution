import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class UserMainCode {

	public static void DisplayDate(int y, int m, int d) throws Exception

	{
		LocalDate dt = LocalDate.of(y, m, d);
		System.out.println("Next Friday: " + dt.with(TemporalAdjusters.next(DayOfWeek.FRIDAY)));
		System.out.println("Previous Friday: " + dt.with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)));
	}

}
