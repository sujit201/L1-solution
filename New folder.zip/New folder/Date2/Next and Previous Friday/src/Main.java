import java.util.*;
public class Main {

	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter year in Integer");
		int y = sc.nextInt();
		System.out.println("Enter Month in Integer");
		int m = sc.nextInt();
		System.out.println("Enter date in Integer");
		int d = sc.nextInt();
		UserMainCode.DisplayDate(y, m, d);

	}

}
