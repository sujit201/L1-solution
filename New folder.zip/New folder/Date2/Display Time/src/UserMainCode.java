
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode {
	
	public static void displayTime(String time)throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date time1 = sdf.parse(time);
		
		Calendar c = Calendar.getInstance();
		c.setTime(time1);
		
		c.add(Calendar.HOUR,2);
        Date time2 = c.getTime();
        
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
		String time3 = sdf1.format(time2);
		
		System.out.println(time3);
	}

}
