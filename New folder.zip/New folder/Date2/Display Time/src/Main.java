import java.util.*;
public class Main {

	public static void main(String[] args) throws Exception {
		

		Scanner sc = new Scanner(System.in);
		
		String time = sc.nextLine();
		
		UserMainCode.displayTime(time);

	}

}
