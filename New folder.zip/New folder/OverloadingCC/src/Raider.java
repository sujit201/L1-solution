
public class Raider extends KabaddiPlayer implements IPlayerStatistics{
	private long noOfRaids;
	private long raidPoints;
	public Raider(String name, String teamName, long noOfMatches, long noOfRaids, long raidPoints) {
		super(name, teamName, noOfMatches);
		this.noOfRaids = noOfRaids;
		this.raidPoints = raidPoints;
	}
	public void displayPlayerStatistics​()
	{
		System.out.println("Player Details\nPlayer name : "+this.name+"\nTeam name : "+this.teamName+"\nNo of matches played : "+this.noOfMatches
				+"\nNo of raids : "+this.noOfRaids+"\nRaid points : "+this.raidPoints);
	}
}
