import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String con = "Yes";
		do
		{
			System.out.println("Menu");
			System.out.println("1.Raider");
			System.out.println("2.Defender");
			System.out.println("3.AllRounder");
			System.out.println("Enter your choice");
			int n = Integer.parseInt(br.readLine());
		
			switch(n)
			{
			case 1:
				System.out.println("Enter the Raider details");
				System.out.println("Enter player name");
				String name = br.readLine();
				System.out.println("Enter team name");
				String teamName = br.readLine();
				System.out.println("Enter number of matches played");
				int noOfMatches = Integer.parseInt(br.readLine());
				System.out.println("Enter number of raids");
				int raids = Integer.parseInt(br.readLine());
				System.out.println("Enter raid points");
				int points = Integer.parseInt(br.readLine());
				Raider r = new Raider(name, teamName, noOfMatches,raids,points);
				r.displayPlayerStatistics​();
				break;
			case 2:
				System.out.println("Enter the Defender details");
				System.out.println("Enter player name");
				String name1 = br.readLine();
				System.out.println("Enter team name");
				String teamName1 = br.readLine();
				System.out.println("Enter number of matches played");
				int noOfMatches1 = Integer.parseInt(br.readLine());
				System.out.println("Enter number of raids");
				int raids1 = Integer.parseInt(br.readLine());
				System.out.println("Enter defence points");
				int points1 = Integer.parseInt(br.readLine());
				Defender d = new Defender(name1, teamName1, noOfMatches1,raids1,points1);
				d.displayPlayerStatistics​();
				break;
			case 3:
				System.out.println("Enter player name");
				String name2 = br.readLine();
				System.out.println("Enter team name");
				String teamName2 = br.readLine();
				System.out.println("Enter number of matches played");
				int noOfMatches2 = Integer.parseInt(br.readLine());
				System.out.println("Enter number of raids");
				int raids2 = Integer.parseInt(br.readLine());
				System.out.println("Enter raid points");
				int points2 = Integer.parseInt(br.readLine());
				System.out.println("Enter defence points");
				int dpoints = Integer.parseInt(br.readLine());
				System.out.println("Enter total points");
				int tpoints = Integer.parseInt(br.readLine());
				AllRounder ar = new AllRounder(name2, teamName2, noOfMatches2,raids2,points2,dpoints,tpoints);
				ar.displayPlayerStatistics​();
				break;
			}
			System.out.println("Do you want to continue");
			con = br.readLine();
		}while(con.equals("Yes"));
	}

}
