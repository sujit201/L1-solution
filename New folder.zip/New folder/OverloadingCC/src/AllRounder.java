
public class AllRounder extends KabaddiPlayer implements IPlayerStatistics{
	private long noOfRaids;
	private long raidPoints;
	private long defencePoints;
	private long noOfTotalPoints;
	public AllRounder(String name, String teamName, long noOfMatches, long noOfRaids, long raidPoints,
			long defencePoints, long noOfTotalPoints) {
		super(name, teamName, noOfMatches);
		this.noOfRaids = noOfRaids;
		this.raidPoints = raidPoints;
		this.defencePoints = defencePoints;
		this.noOfTotalPoints = noOfTotalPoints;
	}
	public long getNoOfRaids() {
		return noOfRaids;
	}
	public void setNoOfRaids(long noOfRaids) {
		this.noOfRaids = noOfRaids;
	}
	public long getRaidPoints() {
		return raidPoints;
	}
	public void setRaidPoints(long raidPoints) {
		this.raidPoints = raidPoints;
	}
	public long getDefencePoints() {
		return defencePoints;
	}
	public void setDefencePoints(long defencePoints) {
		this.defencePoints = defencePoints;
	}
	public long getNoOfTotalPoints() {
		return noOfTotalPoints;
	}
	public void setNoOfTotalPoints(long noOfTotalPoints) {
		this.noOfTotalPoints = noOfTotalPoints;
	}
	
	public void displayPlayerStatistics​()
	{
		System.out.println("Player Details\nPlayer name : "+this.name+"\nTeam name : "+this.teamName+"\nNo of matches played: "+this.noOfMatches
				+"\nNo of raids : "+this.noOfRaids+"\nRaid points : "+this.raidPoints+"\nDefence points : "+this.defencePoints+"\nTotal points : "+this.noOfTotalPoints);
	}
}
