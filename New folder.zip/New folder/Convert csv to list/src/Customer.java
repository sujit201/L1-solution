import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



public class Customer implements Comparable<Customer>{

	private Integer id;
    private String name;
    private Character genger;
    private String email;
    private Date createdOn;
    private String city;
    private String state;
    private String country;
    private Integer ZipCode;
    

    public Character getGenger() {
		return genger;
	}


	public void setGenger(Character genger) {
		this.genger = genger;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public Integer getZipCode() {
		return ZipCode;
	}


	public void setZipCode(Integer zipCode) {
		ZipCode = zipCode;
	}


	public Customer(){}

    
    //Generate getters and setters.

    //fill code here.
    
   
	

//	public static List<Customer> getCustomerList() {
//		return customerList;
//	}

	


	public Customer(Integer id, String name, Character genger, String email, Date createdOn, String city, String state,
			String country, Integer zipCode) {
		super();
		this.id = id;
		this.name = name;
		this.genger = genger;
		this.email = email;
		this.createdOn = createdOn;
		this.city = city;
		this.state = state;
		this.country = country;
		ZipCode = zipCode;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public static List<String> getCus() {
		return cus;
	}


	public static void setCus(List<String> cus) {
		Customer.cus = cus;
	}

	
	public static void setCustomerList(List<String> customerList,int n) throws ParseException {
		Customer c1[]=new Customer[n];
		List<Customer> customerLis = new ArrayList<Customer>();
		int i=0;
		for(String s:customerList ){
			String[] sp=s.split(",");
			SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date d=sd.parse(sp[5]);
			c1[i]=new Customer(Integer.parseInt(sp[0]),sp[1],sp[2].charAt(0),sp[3],d,sp[7],sp[8],sp[9],Integer.parseInt(sp[10]));
			customerLis.add(c1[i]);
			i++;
			//System.out.printf("%-5s %-15s %-5s %-20s %-20s %-15s %-15s %-15s %s\n",sp[0],sp[1],sp[2],sp[3],sp[5],sp[7],sp[8],sp[9],sp[10]);
		}
		Collections.sort(customerLis);
		for(Customer c:customerLis){
		System.out.println(c);
		}
	}

	
	public static List<String> cus = new ArrayList<>();
  
    public static Map<String, Integer> convertCsvToMap(List<String> csvDetails)
    {	
    	Map<String, Integer> map1=new HashMap<>();//dummy
    	Map<String, Integer> map=new TreeMap<>();
    	String[] sp;
    	int count=0;
    	for(String s:csvDetails){
    		sp=s.split(",");
    		cus.add(sp[8]); 		
    	}
    	for(int i=0;i<cus.size();i++){
    		count=0;
    		for(int j=0;j<cus.size();j++){
    			if(cus.get(i).equals(cus.get(j))){
        			count++;
        		}
    		}
    		map.put(cus.get(i), count);
    	}
		return map;
        //fill code here.
    }
 
//    public static List<Customer> getCustomerListFromMap(Map<String, Integer> customerMap)
//    {
//		return customerList;
//        //fill code here.
//    }


	@Override
	public String toString() {
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return String.format("%-5s %-15s %-5s %-20s %-20s %-15s %-15s %-15s %s",id,name,genger, email,  sd.format(createdOn), city, state,country, ZipCode);
	}

    
	@Override
	public int compareTo(Customer o) {
		// TODO Auto-generated method stub
		if(o.getState().compareTo(this.getState())>0){
			return -1;
		}
		else if(o.getState().compareTo(this.getState())<0){
			return 1;
		}
		else if(o.getState().equals(this.getState())){
			if(o.getName().compareTo(this.getName())>0){
				return -1;
			}
			else if(o.getName().compareTo(this.getName())<0){
				return 1;
			}
			return 0;
		}
		return 0;
	}
    
}
