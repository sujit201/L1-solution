import java.io.*;
import java.util.*;

public class Main {
    
    public static void main(String[] args) throws Exception {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the number of customer:");
        int n = new Integer(br.readLine());
        Scanner sc=new Scanner(System.in);
        List<String> csvList = new ArrayList<>();
        List<Customer> c=new ArrayList<Customer>();
        String list;
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter the customer "+(i+1)+" details:");
            list =br.readLine();
            //fill code here.
            csvList.add(list);
            

        }
        Map<String, Integer> map=Customer.convertCsvToMap(csvList);
        //fill code here.
        
        Set<Map.Entry<String, Integer>> values=map.entrySet();
        System.out.println(String.format("%-15s %s","State","No of customer(s)"));
        
        	for(Map.Entry<String,Integer> m:values){
        		//System.out.print(m.getKey());
        		System.out.printf("%-15s %s\n",m.getKey(),m.getValue());
        		//System.out.println(m.getValue());
        	}
        //System.out.println("State - No of customers");

        //fill code here.
        	
        System.out.format("%-5s %-15s %-5s %-20s %-20s %-15s %-15s %-15s %s\n", "Id", "Name", "Gender", "Email",  "Created on", "City", "State", "Country", "Zipcode");
        
        Customer.setCustomerList(csvList,n);
        
	//fill code here.

    }
    
}
