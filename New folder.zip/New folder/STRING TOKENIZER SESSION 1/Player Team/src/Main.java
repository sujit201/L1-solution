import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the player name");
		String name = s.nextLine();

		System.out.println("Enter the team name");
		String team = s.nextLine();

		 UserMainCode.display(name, team);

	}

	

}
