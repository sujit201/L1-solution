
public class UserMainCode {

	public static void display(String name, String team) {

		StringBuffer sbf1 = new StringBuffer(name + "#");

		sbf1.append(team);
		System.out.println(sbf1);
	}

}
