
public class UserMainCode {

	public static void display(String stadium) {

		String newStadium = stadium.replace("Stadium", "Ground");

		System.out.println(newStadium);
	}

}
