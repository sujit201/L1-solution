import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Enter the venue name");

		String stadium = s.nextLine();

		System.out.println("Modified Venue");

		UserMainCode.display(stadium);

	}

}
