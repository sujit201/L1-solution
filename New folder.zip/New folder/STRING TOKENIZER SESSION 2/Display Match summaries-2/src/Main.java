import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		String str = s.nextLine();
		String arr[] = new String[str.length()];

		for(int i=0;i<arr.length;i++)
		{
			arr = str.split("!");
		}

		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]);
		}

	}

}
