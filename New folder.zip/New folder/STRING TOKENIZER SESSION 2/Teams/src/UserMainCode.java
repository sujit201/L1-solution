
public class UserMainCode {
	
	public static void display(String name,String c)
	{
		String strNew = name.replaceAll(c, "");
		
		System.out.println(strNew);
	}

}
