import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		String name = s.nextLine();
		String c = s.nextLine();

		UserMainCode.display(name, c);

	}

}
