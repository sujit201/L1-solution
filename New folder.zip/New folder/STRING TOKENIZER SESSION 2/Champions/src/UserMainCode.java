
public class UserMainCode {

	public static void display(String name) {
		String arr1[] = new String[name.length()];

		for (int i = 0; i < arr1.length; i++) {
			arr1 = name.split("!|\\#");

		}

		for (int i = 0; i < arr1.length; i++) {
			System.out.printf(arr1[i]);

		}
	}
}
