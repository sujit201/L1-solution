import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class DeliveryBO
{
  
     public Delivery createDelivery(String data,Innings[] inningsList) {
    	     String str = data;
    	     String arr[] = str.split(",");
    	     Innings innings = new Innings(Long.parseLong(arr[4]),null);
    	     Delivery delivery = 
    	    new Delivery(Long.parseLong(arr[0]),arr[1],arr[2],Long.parseLong(arr[3]),innings);
    	     return delivery;
 
      }


 public Long findInningsNumber(Delivery [] deliveryList, long deliveryNumber)

  {
	 long l = -1;
	  for(int i=0;i<deliveryList.length;i++)
	  {
		  if(deliveryList[i].getDeliveryNumber().equals(deliveryNumber))
		  {
			 l = deliveryList[i].getInnings().getInningsNumber();
		  }
	  }
	  return l;
  }
}
