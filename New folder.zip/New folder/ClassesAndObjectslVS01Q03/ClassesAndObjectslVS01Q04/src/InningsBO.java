import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class InningsBO {
	 
   public  Innings createInnings(String data) {
	
    String str = data;
    String arr[] = str.split(",");
    Innings innings = new Innings(Long.parseLong(arr[0]),arr[1]);
    return innings;
    }

}
