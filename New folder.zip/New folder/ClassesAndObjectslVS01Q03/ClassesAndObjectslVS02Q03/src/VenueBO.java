class VenueBO  {
    public Venue createVenue(String data, City[] cityList) 
    {
    	String str = data;
    	String arr[] = str.split(",");
    	int x=0;
    	for(int i=0;i<cityList.length;i++)
    	{
    		if(cityList[i].equals(arr[1]))
    		{
    			x=i;
    		}
    	}
    	City city = cityList[x];
    	Venue venue = new Venue(arr[0],city);
    	return venue;
    }
    
}
