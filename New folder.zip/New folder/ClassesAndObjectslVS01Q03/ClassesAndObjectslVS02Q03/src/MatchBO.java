class MatchBO {
    public Match createMatch(String data, Venue[] venueList) {		
             String str = data;
             String arr[] = str.split(",");
             int x=0;
             for(int i=0;i<venueList.length;i++)
             {
            	 if(venueList[i].getName().equals(arr[3]))
            	 {
            		x=i; 
            	 }
             }
             Match match = new Match(arr[0],arr[1],arr[2],venueList[x]);
             return match;
    }
    public void findVenue(String date, Match[] matchList) {
    	for(int i=0;i<matchList.length;i++)
    	{
    		if(matchList[i].getDate().equals(date))
    		{
    			System.out.println(matchList[i].getVenue().toString());
    		}
    	}
    }
	
	
    
    public void findAllMatchesInGivenVenue(String sname, Match[] matchList) {
    	 System.out.println("Matches in venue "+sname+" are\n"+String.format("%-15s%-15s%s","Date","TeamOne","TeamTwo"));   
    	for(int i=0;i<matchList.length;i++)
	       {
	    	   if(matchList[i].getVenue().getName().equals(sname))
	    	   {
	    		   System.out.println(matchList[i].toString());
	    	   }
	       }
		
	}
	
	
	
				
}
