class CityBO  {
     public City createCity(String data) {
         
              City city = new City(data);
              return city;
    }
}
