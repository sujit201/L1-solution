import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class TeamBO
{

  
 public Team createTeam(String data, Player[] playerList)
 {
	 String str = data;
	 String arr[] = str.split(",");
	 Player player = new Player(arr[1],null,null);
	 Team team = new Team(arr[0],player);
	 return team;
 }
 
}