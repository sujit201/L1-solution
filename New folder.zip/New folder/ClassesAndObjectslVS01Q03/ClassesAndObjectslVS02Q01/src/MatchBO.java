import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class MatchBO
{
   
 public Match createMatch(String data, Team[] teamList)
  {
	 String str = data;
	 String arr[] = str.split(",");
	 int x=0;
	 for(int i=0;i<teamList.length;i++)
	 {
		 if(teamList[i].name.equals(arr[1])&&teamList[i].name.equals(arr[2]))
		 {x=i;}
	 }
	 Team team = teamList[x];
	 Match match = new Match(arr[0],arr[1],arr[2],arr[3],team);
	 return match;
	 
  }

  public Match findTeam(String matchDate, Match[] matchList)
  {
	  Match m = null;
      for (int i = 0; i < matchList.length; i++) {
          if (matchList[i].date.equals(matchDate)) {
              m = matchList[i];
          }
      }
      return m;
  

  }

  public void findAllMatchesInGivenTeam(String teamName, Match[] matchList)
  {
	  for(int i=0;i<matchList.length;i++)
	  {
		  if(matchList[i].teamone.equals(teamName)||matchList[i].teamtwo.equals(teamName))
		  {
			  System.out.println(matchList[i].toString());
		  }
	  }
  }


  
}
