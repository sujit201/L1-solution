import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class PlayerBO
{

  public Player createPlayer(String data)
   {
	  String str = data;
	  String arr[] = str.split(",");
	  Player player = new Player(arr[0],arr[1],arr[2]);
	  return player;
   }

}
