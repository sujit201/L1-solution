  import java.util.*;
class MatchBO {
    
	public void printAllMatchDetails(List<Match> MatchList)
	{
        System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
        System.out.println(MatchList);
	}
	
	

	public void printMatchDetailsWithOutcomeStatus(List<Match> MatchList, String outcomeStatus) 
	{
		System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
		for(int i=0;i<MatchList.size();i++)
		{
			if()
		}
		
	}
	
	public void printMatchDetailsWithOutcomeWinnerTeam(List<Match> MatchList, String outcomeWinnerTeam)
	{
        System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n","Date","Team1","Team2","Venue","Status","Winner");
				
	//fill your code;		
		
	}
	

}


