class UmpireType
{
  String type;

  UmpireType(){}
  UmpireType(String type)
  {
    this.type=type;
  }
   
  void setType(String type)
  {
   this.type=type;
  }
  String getType()
  {
   return type;
  }
  

}
