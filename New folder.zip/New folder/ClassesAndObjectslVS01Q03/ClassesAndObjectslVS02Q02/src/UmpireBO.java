import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class UmpireBO
{

 public Umpire createUmpire (String data, UmpireType[] umpireTypeList)
 {
	 String str = data;
	 String arr[] = str.split(",");
	 int x=0;
	 for(int i=0;i<umpireTypeList.length;i++)
	 {
		 if(umpireTypeList[i].type.equals(arr[1]))
		 {
			 x=i;
		 }
		 
	 }
	 UmpireType utl =  umpireTypeList[x];
	 Umpire umpire = new Umpire(arr[0],utl);
	 return umpire;
 }

}
