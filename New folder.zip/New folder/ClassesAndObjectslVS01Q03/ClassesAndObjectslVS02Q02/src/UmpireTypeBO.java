import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class UmpireTypeBO
{

 public UmpireType createUmpireType (String data)
 {
	 UmpireType ut = new UmpireType(data);
	 return ut;
 }
}
