import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class MatchBO
{
 
 public Match createMatch(String data, Umpire[] umpireList)
  {
	 String str = data;
	 String arr[] = str.split(",");
	 int x=0;
	 for(int i=0;i<umpireList.length;i++)
	 {
		 if(umpireList[i].name.equals(arr[3]))
		 {
			 x=i;
		 }
	 }
	 Umpire u = umpireList[x];
	 Match match = new Match(arr[0],arr[1],arr[2],u);
	return match;
  }

  public Match findUmpire(String matchDate, Match[] matchList)
  {
	  Match m = null;
	  int x=0;
	  for(int i=0;i<matchList.length;i++)
	  {
		  if(matchList[i].date.equals(matchDate))
		  {
			  x=i;
		  }
	  }
	  m=matchList[x];
	  return m;
  }
 
  public void findAllMatchesOfGivenUmpire(String umpireName, Match[] matchList)
  {
	  for(int i=0;i<matchList.length;i++)
	  {
		  if(matchList[i].umpire.name.equals(umpireName))
		  {
			  System.out.println(matchList[i].toString());
		  }
	  }
  }
}
