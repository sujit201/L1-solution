  public class TeamBO {
    public  Team createTeam(String data)
	{
    	String str = data;
    	String arr[] = str.split(",");
    	Team team = new Team(arr[0], arr[1]);
    	return team;
	}
	
	
	

}


