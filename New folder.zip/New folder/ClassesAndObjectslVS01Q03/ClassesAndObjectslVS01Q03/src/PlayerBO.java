  public class PlayerBO {
    public Player createPlayer(String data, Team[] teamList)
	{
    	String str = data;
    	String arr[] = str.split(",");
    	Team team = new Team(arr[0],arr[1] );
    	Player player = new Player(arr[0], team);
		return player;
    	
		
	}
	
	public String findTeamName(Player[] playerList, String playername)
	{
		int j=0;
		for(int i=0;i<playerList.length;i++)
		{
			if(playerList[i].getName().equals(playername))
				j=i;
		}
		return playerList[j].team.getHome();
		
	}
	
	public Boolean findWhetherPlayersAreInSameTeam (Player[] playerList, String playername1, String playername2)
	{
		String t2 = null;
		String t1 = null;
		for(int i=0;i<playerList.length;i++)
		{
			if((playerList[i].getName().equals(playername1)))
			{
				t1 = playerList[i].getTeam().home.toString();
				//System.out.println(t1);
			}
			if(playerList[i].getName().equals(playername2))
			{
				t2 = playerList[i].getTeam().home.toString();
				//System.out.println(t2);
			}
		}
		
		if(t1.equals(t2))return true;
		else return false;
	}

}