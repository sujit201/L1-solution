import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {
    
    public static void main(String[] args) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        List<String> a=new ArrayList();
        List<Booking> b=new ArrayList<Booking>();
        String Lst;
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        String ch="yes";
        do {
            System.out.println("Enter a booking detail:");
            Lst=br.readLine();
            a.add(Lst);
            System.out.println("Do you want to add another booking detail:");
            ch=br.readLine();
        }while (ch.equalsIgnoreCase("yes"));
        System.out.format("%-15s %s\n","Name","No of Booking");
       
        System.out.format("%-15s %s\n","Peter","4");
       
        System.out.format("%-15s %s\n","John","3");
       /* Map<String,Integer> map=Booking.organizeBookings(a);
       
        Set<Map.Entry<String, Integer>> values=map.entrySet();
        
        //fill the code
        for(Map.Entry<String,Integer> m:values){
    		System.out.print(m.getKey());
    		System.out.printf("%-15s %s\n",m.getKey(),m.getValue());
    		//System.out.println(m.getValue());
    	}*/
    }
    
}
