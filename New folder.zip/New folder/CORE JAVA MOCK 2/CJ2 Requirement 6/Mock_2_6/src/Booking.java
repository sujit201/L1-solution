import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
public class Booking {
	private Long bookingId;
    private Date dateTimeService;
    private String paymentMode;
    private Long customerId;
    private Long carId;
    private Double amount;
    private String serviceEngineer;
    
	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Date getDateTimeService() {
		return dateTimeService;
	}

	public void setDateTimeService(Date dateTimeService) {
		this.dateTimeService = dateTimeService;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getServiceEngineer() {
		return serviceEngineer;
	}

	public void setServiceEngineer(String serviceEngineer) {
		this.serviceEngineer = serviceEngineer;
	}
	/*public static List<String> findBestServiceEngineer(Map<String,List<Booking>> bookingMap) {
        //fill the code
    }*/

	//fill the code
    public static List<String> cus = new ArrayList<>();
	public static Map<String,Integer> organizeBookings(List<String> bookingList) {
		Map<String, Integer> map1=new HashMap<>();//dummy
    	Map<String, Integer> map=new TreeMap<>();
    	String[] sp;
    	int count=0;
    	for(String s:bookingList){
    		sp=s.split(",");
    		cus.add(sp[8]); 		
    	}
    	for(int i=0;i<cus.size();i++){
    		count=0;
    		for(int j=0;j<cus.size();j++){
    			if(cus.get(i).equals(cus.get(j))){
        			count++;
        		}
    		}
    		map.put(cus.get(i), count);
    	}
		return map;
		//fill the code
    }

    
    
}
