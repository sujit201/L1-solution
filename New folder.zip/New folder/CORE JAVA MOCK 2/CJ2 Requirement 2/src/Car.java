import java.io.BufferedReader;
import java.util.*;
public class Car {
    //fill the code
    private String licenceNumber,model;
    private Double currentMileage;
    private Integer engineSize;
    public String getLicenceNumber() {
return licenceNumber;
}

public void setLicenceNumber(String licenceNumber) {
this.licenceNumber = licenceNumber;
}

public String getModel() {
return model;
}

public void setModel(String model) {
this.model = model;
}

public Double getCurrentMileage() {
return currentMileage;
}

public void setCurrentMileage(Double currentMileage) {
this.currentMileage = currentMileage;
}

public Integer getEngineSize() {
return engineSize;
}

public void setEngineSize(Integer engineSize) {
this.engineSize = engineSize;
}

public Car(String licenceNumber, String model, Double currentMileage,
Integer engineSize) {
super();
this.licenceNumber = licenceNumber;
this.model = model;
this.currentMileage = currentMileage;
this.engineSize = engineSize;
}

public Car() {
super();
}

//Dont change the specification of this method
    public static Car addCar(BufferedReader br) {
       
       String licenceNumber, model;Double currentMileage;Integer engineSize;
       Car c = null;
       try {
           System.out.println("Licence Number: ");
           licenceNumber = br.readLine();
           System.out.println("Model: ");
           model = br.readLine();
           System.out.println("Current Mileage: ");
           currentMileage = Double.parseDouble(br.readLine());
           System.out.println("Engine Size: ");
           engineSize = Integer.parseInt(br.readLine());
           c = new Car(licenceNumber,model,currentMileage,engineSize);
           return c;
           
       }
       catch(Exception e) {
           System.out.println("Could not create Car");
       }
       return c;
       
   }
    
    public static Car findCar(String licNo, ArrayList<Car> carList) {
       //fill the code
     
     for(Car c:carList)
     {
     if(c.getLicenceNumber().equals(licNo))
     {
     return c;
     }
     }
     
     return null;
     }
    
    
     @Override
public String toString() {
return "Licence Number:" + licenceNumber + "\nModel:" + model;
}

public static ArrayList<Car> findCarList(String model, ArrayList<Car> carList) {
      ArrayList<Car> cL=new ArrayList<>();
      int f=0;
      for(Car c:carList)
      {
      if(c.getModel().equals(model))
      {
      cL.add(c);
      f=1;
      }
      }
      if(f==1)
      return cL;
      else
      return null;
      
       //fill the code
     }
}
