public class WalletPayment extends PaymentMode {
private String walletNumber;
    //fill the code

public WalletPayment(String type, String walletNumber) {
super(type);
this.walletNumber = walletNumber;
}
public WalletPayment(String type) {
super(type);
}
public String getWalletNumber() {
return walletNumber;
}
public void setWalletNumber(String walletNumber) {
this.walletNumber = walletNumber;
}
Double makePayment(Booking booking)
{
Double c=booking.getAmount();
c=c-c*(0.05);
return c;
}
    
}

