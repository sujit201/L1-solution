public class Car {
    //fill the code
private String licenceNumber;

public String getLicenceNumber() {
return licenceNumber;
}

public void setLicenceNumber(String licenceNumber) {
this.licenceNumber = licenceNumber;
}

public Car(String licenceNumber) {
super();
this.licenceNumber = licenceNumber;
}

public Car() {
super();
}
    
}
