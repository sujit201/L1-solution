public class Customer {
    //fill the code
private Long customerId;

public Long getCustomerId() {
return customerId;
}

public void setCustomerId(Long customerId) {
this.customerId = customerId;
}

public Customer(Long customerId) {
super();
this.customerId = customerId;
}

public Customer() {
super();
}
}
