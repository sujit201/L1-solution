import java.util.*;

public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String s;
	long r;
	System.out.println("Enter the extratype details");
	s=sc.nextLine();
	String a[]=s.split("#");
	ExtraType e=new ExtraType();
	e.setName(a[0]);
	r=Long.parseLong(a[1]);
	e.setRuns(r);
	System.out.println("ExtraType Details");
	System.out.println("Extra Type:"+e.getName());
	System.out.println("Runs:"+e.getRuns());
}
}
