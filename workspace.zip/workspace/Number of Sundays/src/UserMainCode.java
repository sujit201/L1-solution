import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;



public class UserMainCode {

	public static void displayDay(String dt1, String dt2) throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		SimpleDateFormat sdfDD=new SimpleDateFormat("EEE");

		String buffer;

		boolean flag=true;

		int sunday=0;

		Date startDate=sdf.parse(dt1);

		Date endDate=sdf.parse(dt2);

		Calendar calStart=Calendar.getInstance();

		calStart.setTime(startDate);

		Calendar calEnd=Calendar.getInstance();

		calEnd.setTime(endDate);

		Date d=calStart.getTime();

		while(flag)

		{

			buffer=sdfDD.format(d);

			if(buffer.equals("Sun"))

			{

				sunday++;

			}

			calStart.add(Calendar.DATE, 1);

			d=calStart.getTime();

			if(d.equals(calEnd.getTime()))

			{

				break;

			}

		}

		System.out.println(sunday);

	}



}