import java.util.*;





import java.text.*;

public class Main {



	public static void main(String[] args)throws ParseException {

		Scanner sc=new Scanner(System.in);

		Match rishav =new Match();



		System.out.println("Menu");

		System.out.println("1.Match Date");

		System.out.println("2.Match Venue");

		System.out.println("3.Match Outcome");

		int ch=sc.nextInt();

		switch(ch)

		{

		case 1:

			sc.nextLine();

			System.out.println("Enter the date of the match");

			String str=sc.nextLine();

			

			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");

			Date matchDate=sdf.parse(str);

			rishav.displayMatchDetails(matchDate);

			break;

			

		case 2:

			sc.nextLine();

			System.out.println("Enter venue of the match");

			String venue=sc.nextLine();

			rishav.displayMatchDetails(venue);

			break;

		case 3:

			sc.nextLine();

			System.out.println("Enter the winner team of the match");

			String winnerTeam=sc.nextLine();

			System.out.println("Enter the number of runs");

			long runs=sc.nextLong();

			rishav.displayMatchDetails(winnerTeam,runs);

		}

	}



}





