import java.text.SimpleDateFormat;
import java.util.*;
public class Main {
public static void main(String args[]) throws Exception {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter contact 1 detail:");
	String s1=sc.nextLine();
	System.out.println("Enter contact 2 detail:");
	String s2=sc.nextLine();
	String a[]=s1.split(",");
	String b[]=s2.split(",");
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	Date d1=sdf.parse(a[6]);
	Date d2=sdf.parse(b[6]);
	Contact c1=new Contact(a[0],a[1],a[2],a[3],a[4],a[5],d1);
	Contact c2=new Contact(b[0],b[1],b[2],b[3],b[4],b[5],d2);
	System.out.println("\nContact 1:");
	System.out.println(c1);
	System.out.println("\nContact 2:");
	System.out.println(c2);
	
	if(c1.equals(c2)) {
		System.out.println("\nContact 1 is same as Contact 2");
	}
	else
		System.out.println("\nContact 1 and Contact 2 are different");
}
}
