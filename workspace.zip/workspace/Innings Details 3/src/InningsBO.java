public class InningsBO 

{

	public void displayAllInningsDetails(Innings[] inningsList)

	{

		System.out.println("Innings Details");

		System.out.println(inningsList[0].toString());

		System.out.println(inningsList[1].toString());

	}



}



