class Innings {

	private long inningsNumber;

	public Innings() {

		// TODO Auto-generated constructor stub

	}

	public Innings(long inningsNumber) {

		

		this.inningsNumber = inningsNumber;

	}



	public long getInningsNumber() {

		return inningsNumber;

	}



	public void setInningsNumber(long inningsNumber) {

		this.inningsNumber = inningsNumber;

	}



}