class EventBO {

	

	public Event createEvent(String data, Innings[] InningList)

	{



		//fill your code;

		String s[]=data.split(",");

		Event e=null;

		for(int i=0; i<InningList.length;i++)

		{

			if(Long.parseLong(s[s.length-1])==InningList[i].getInningsNumber())

			{

				e=new Event(Long.parseLong(s[0]),s[1],Long.parseLong(s[2]),Long.parseLong(s[3]),InningList[i]);

			}

		}

		return e;

	}

	

	



	public long findInningsNumber(Event[] eventList, long eventNumber) {

		//fill your code;

		long l=0;

		for(int i=0; i<eventList.length; i++)

		{

			if(eventNumber==eventList[i].getEventNumber())

			{

				

				l=eventList[i].innings.getInningsNumber();

			}

		}

		

		return l;

	}



}