import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int i,n1,n2;
	ArrayList<String>s1=new ArrayList<String>();
    for(i=0;i<5;i++) {
	s1.add(sc.nextLine());

}
System.out.println("Enter swap positons");
 n1=sc.nextInt();
 n2=sc.nextInt();
Collections.swap(s1, n1, n2);
for(i=0;i<5;i++)
{
	System.out.println(s1.get(i));
}
}
}
