package filecc;
interface A{
	int a=10;
	public static final int b=20;
	
	
	void disp1();
	public abstract void disp2();
}
class demo implements A{
	public void disp1(){
		System.out.println("disp1"+(a+b));
	}
	public void disp2(){
		System.out.println("disp2"+(a+b));
	}
}
public class Finaldemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
