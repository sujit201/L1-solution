import java.text.*;
public class Bike {
	private String VIN,brand,model,engineDisplacement,brakeSystem;
	private double cost;
	public String getVIN() {
		return VIN;
	}
	public void setVIN(String vIN) {
		VIN = vIN;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngineDisplacement() {
		return engineDisplacement;
	}
	public void setEngineDisplacement(String engineDisplacement) {
		this.engineDisplacement = engineDisplacement;
	}
	public String getBrakeSystem() {
		return brakeSystem;
	}
	public void setBrakeSystem(String brakeSystem) {
		this.brakeSystem = brakeSystem;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Bike(String vIN, String brand, String model, String engineDisplacement, String brakeSystem, double cost) {
	
		VIN = vIN;
		this.brand = brand;
		this.model = model;
		this.engineDisplacement = engineDisplacement;
		this.brakeSystem = brakeSystem;
		this.cost = cost;
	}
	public Bike() {
		
		// TODO Auto-generated constructor stub
	}
	DecimalFormat df=new DecimalFormat("##.0");
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return (String.format("%-20s %-10s %-10s %-20s %-12s %s\n",VIN,brand,model,engineDisplacement,brakeSystem,df.format(cost)));
	}
	
	
	
	
}
