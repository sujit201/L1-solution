import java.util.*;
public class BikeBO {
	public List<Bike> findBike(List<Bike> bikeList,String engineDisplacement){
		//Your code here
		List<Bike> lb=new ArrayList<Bike>();
		Bike b;
		Iterator<Bike> it=bikeList.iterator();
		for(int i=0;i<bikeList.size();i++){
			b=it.next();
			if(b.getEngineDisplacement().equalsIgnoreCase(engineDisplacement)){
				lb.add(b);
				
			}
			
		}
		return lb;
		
	}
	public List<Bike> findBike(List<Bike> bikeList,Double cost){
		//Your code here
		
		List<Bike> lb=new ArrayList<Bike>();
		Bike b;
		Iterator<Bike> it=bikeList.iterator();
		for(int i=0;i<bikeList.size();i++){
			b=it.next();
			if(b.getCost()<cost){
				lb.add(b);
				
			}
			
		}
		return lb;
	}
}
