import java.util.*;

public class Main {
	public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of bikes:");
		int n=sc.nextInt();
		sc.nextLine();
		Bike b;
		List<Bike> b1=new ArrayList<Bike>();
		List<Bike> b2=new ArrayList<Bike>();
		for(int i=0;i<n;i++){
			String a[]=sc.nextLine().split(",");
			double d=Double.parseDouble(a[5]);
			b=new Bike(a[0],a[1],a[2],a[3],a[4],d);
			b1.add(b);
		}
		BikeBO bo=new BikeBO();
		System.out.println("Enter a search type:\n1.By Engine Displacement\n2.By Cost");
		int c=sc.nextInt();
		Iterator<Bike> it;
		if(c==1){
			System.out.println("Enter the engine displacement:");
			sc.nextLine();
		b2=bo.findBike(b1,sc.nextLine());
		 it=b2.iterator();
		if(b2.size()==0)
			System.out.println("No such bike is present");
		else{
			System.out.format("%-20s %-10s %-10s %-20s %-12s %s\n","VIN","Brand","Model","Engine Displacement","Brake System","Cost");
			while(it.hasNext()){
			System.out.print(it.next());
			}
		}
		}
		else if(c==2){
			System.out.println("Enter the cost:");
			b2=bo.findBike(b1,sc.nextDouble());
			it=b2.iterator();
			if(b2.size()==0)
				System.out.println("No such bike is present");
			else{
				System.out.format("%-20s %-10s %-10s %-20s %-12s %s\n","VIN","Brand","Model","Engine Displacement","Brake System","Cost");
				while(it.hasNext()){
				System.out.print(it.next());
				}
			}
		}
		else
			System.out.println("Invalid choice");
	}
}
