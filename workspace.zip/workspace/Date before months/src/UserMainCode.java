import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;



public class UserMainCode {

	public static void displayDate(String date) throws Exception

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		Date dt=sdf.parse(date);

		Calendar cal=Calendar.getInstance();

		cal.setTime(dt);

		cal.add(Calendar.MONTH, -20);

		dt=cal.getTime();

		System.out.println("20 months before "+date+" will be "+sdf.format(dt));

	}

}