import java.util.*;

  public class Main {

  

	public static void main(String[] args) {



 Scanner sc=new Scanner(System.in);

 

 System.out.println("Enter the number of innings");

 

 int n=sc.nextInt();

 

 sc.nextLine();

 

 Innings inn[]=new Innings[n];

 

 String innings[]=new String[n];

 

 int i;

 

 InningsBO ibo=new InningsBO();

 

 for(i=0;i<n;i++)

{

 System.out.println("Enter innings "+(i+1)+" details");

 

 innings[i]=sc.nextLine();

 

 inn[i]=ibo.createInnings(innings[i]);

}



 System.out.println("Enter the number of deliveries");

 

 int m=sc.nextInt();

 

 sc.nextLine();

 

 Delivery d[]=new Delivery[m];

 

 DeliveryBO dbo=new DeliveryBO();

 

 String delivery[]=new String[m];

 

 for(i=0;i<m;i++)

{

 System.out.println("Enter innings "+(i+1)+" details");

 

 delivery[i]=sc.nextLine();

 

 d[i]=dbo.createDelivery(delivery[i], inn);

}



 System.out.println("Enter the delivery number for which you need to find the innings number");

 

 long deliveryNumber=sc.nextLong();

 

 System.out.println(dbo.findInningsNumber(d, deliveryNumber));



 sc.close();

}

}

