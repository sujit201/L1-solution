public class InningsBO {

 

	public Innings createInnings(String data)

{

 String s[]=data.split(",");

 

 Innings i=new Innings(Long.valueOf(s[0]), s[1]);

 

 return i;

}

}