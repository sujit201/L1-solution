import java.util.*;

import java.io.*;

import java.lang.reflect.Constructor;

public class Main {



	public static void main(String[] args)throws InstantiationException {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		try

		{

			Player ps= (Player) Player.class.newInstance();

			

		}

		catch(Exception e)

		{

			System.out.println("Trying to invoke a no-argument constructor (that is not available) using newInstance method");

			System.out.println("Exception Occured : "+e.getClass().getCanonicalName());

		}

		System.out.println("Enter name of the player");

		String name=a.nextLine();

		System.out.println("Enter country of the player");

		String cou=a.nextLine();

		System.out.println("Enter skillset of the player");

		String skill=a.nextLine();

		Player p=new Player(name, cou,skill);

		System.out.println(p.getName()+", "+p.getCountry()+", "+p.getSkill());

	}



}

