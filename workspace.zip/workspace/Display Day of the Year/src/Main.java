import java.util.*;







 public class Main 







{







    public static void main(String args[]) throws Exception







{







 Scanner sc= new Scanner(System.in);







 







 int y= sc.nextInt();







 







 int m= sc.nextInt();



















 UserMainCode.dislayDate(y, m);







}







}