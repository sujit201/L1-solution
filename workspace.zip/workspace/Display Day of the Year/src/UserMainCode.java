import java.text.*;







import java.util.*;







public class UserMainCode 







{







 public static void dislayDate(int a, int b) throws Exception







 {







 SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");







 Calendar c= Calendar.getInstance();







 c.set(Calendar.YEAR,a);







 c.set(Calendar.MONTH,0);







 c.set(Calendar.DATE,1);







 c.add(Calendar.DATE,b-1);







 Date d= c.getTime();







 String s= sdf.format(d);







 System.out.println(b+"th day of "+a+" : "+s);







 }







}