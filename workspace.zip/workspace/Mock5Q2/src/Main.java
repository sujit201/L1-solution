import java.util.*;
public class Main{
	public static void main(String[] args)throws Exception{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the registration number to be validated:");
		String rNo=sc.nextLine();
		
		if(validate(rNo)==true){
			System.out.println("Registration Number is valid");
		}
		else {
			System.out.println("Registration Number is invalid");
		}
	}
	static Boolean validate(String regno){
		if(regno.matches("[A-Z]{2}\\s([0-9][0-9]|[1-9]?)\\s?[A-Z]{0,2}\\s[1-9]([0-9]{1,3})?"))
		return true;
		else return false;
	}
}
