		SubBank		QuestionInstructions	QuestionText	QuestionType	Choice1	Choice2	Choice3	Choice4	Choice5	Grade1	Grade2	Grade3	Grade4	Grade5

		Access Specifiers Constructors Methods NewQB			"What will be the result of compiling the following program?

public class MyClass {

long var;

public void MyClass(long param) { var = param; } // (Line no 1)

public static void main(String[] args) {

MyClass a, b;

a = new MyClass(); // (Line no 2) 

}

}"	MCQ	A compilation error will occur at (Line no 1), since constructors cannot specify a return value	A compilation error will occur at (2), since the class does not have a default constructor	A compilation error will occur at (Line no 2), since the class does not have a constructor that takes one argument of type int.	The program will compile without errors.		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			Which of the following declarations are correct? (Choose TWO)	MCA	boolean b = TRUE;	byte b = 256;	String s = �null�;	int i = new Integer(�56�);		0	0	0.5	0.5	

		Access Specifiers Constructors Methods NewQB			"What will happen when you attempt to compile and run this code?

abstract class Base{

    abstract public void myfunc();

    public void another(){

    System.out.println(""Another method"");

    }

}



public class Abs extends Base{

    public static void main(String argv[]){

    Abs a = new Abs();

    a.amethod();

    }

    public void myfunc(){

        System.out.println(""My Func"");

        } 

    public void amethod(){

    myfunc();    

    }

}"	MCQ	"The code will compile and run, printing out the words ""My Func"""	The compiler will complain that the Base class has non abstract methods	The code will compile but complain at run time that the Base class has non abstract methods	The compiler will complain that the method myfunc in the base class has no body, nobody at all to print it		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			class A, B and C are in multilevel inheritance hierarchy repectively . In the main method of some other class if class C object is created, in what sequence the three constructors execute?	MCQ	Constructor of A executes first, followed by the constructor of B and C	Constructor of C executes first followed by the constructor of A and B	Constructor of C executes first followed by the constructor of B and A	Constructor of A executes first followed by the constructor of C and B		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

package aj; private class S{ int roll;

 S(){roll=1;} }

package aj; class T 

{ public static void main(String ar[]){ 

System.out.print(new S().roll);}}"	MCQ	Compilation error	Compiles and display 1	Compiles but no output	Compiles and diplay 0		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Here is the general syntax for method definition: 



accessModifier returnType methodName( parameterList )

{

 Java statements



 return returnValue;

}





What is true for the returnType and the returnValue?"	MCQ	The returnValue can be any type, but will be automatically converted to returnType when the method returns to the caller	If the returnType is void then the returnValue can be any type	The returnValue must be the same type as the returnType, or be of a type that can be converted to returnType without loss of information	The returnValue must be exactly the same type as the returnType.		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"A) A call to instance method can not be made from static context.

B) A call to static method can be made from non static context."	MCQ	Both are FALSE	Both are TRUE	Only A is TRUE	Only B is TRUE		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class A{ A(){System.out.print(""From A"");}}

class B extends A{ B(int z){z=2;}

public static void main(String args[]){

 new B(3);}}"	MCQ	Compilation error	Comiples and prints From A	Compiles but throws runtime exception	Compiles and display 3		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"class Sample

{int a,b;

Sample()

{ a=1; b=2;

System.out.println(a+""\t""+b);

}

Sample(int x)

{ this(10,20);

a=b=x;

System.out.println(a+""\t""+b);

}

Sample(int a,int b)

{ this();

this.a=a;

this.b=b;

System.out.println(a+""\t""+b);

}

}

class This2

{ public static void main(String args[])

{

Sample s1=new Sample (100);

}

}

What is the Output of the Program?"	MCQ	100 100 1 2 10 20	1 2 100 100 10 20	10 20 1 2 100 100	1 2 10 20 100 100		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class A{ private static void display(){ System.out.print(""Hi"");}

public static void main(String ar[]){

display();}}"	MCQ	Compiles and display Hi	Compiles and throw run time exception	Compiles but doesn't display anything	Compilation fails		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

package aj; class A{ protected int j; }

package bj; class B extends A

{ public static void main(String ar[]){ 

System.out.print(new A().j=23);}}"	MCQ	code compiles fine and will display 23	code compiles but will not display output	compliation error	j can not be initialized		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class A{ int z; A(int x){z=x;} }

class B extends A{ 

public static void main(String arg){

new B();}}"	MCQ	Compilation error	Compiles but throws run time exception	Compiles and displays nothing	None of the listed options		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"class Test{

static void method(){

this.display();

}

static display(){

System.out.println((""hello"");

}

public static void main(String[] args){

new Test().method();

}

}

consider the code above & select the proper output from the options."	MCQ	hello	Runtime Error	compiles but no output	does not compile		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"What will be the result when you try to compile and run the following code? 

private class Base{

  Base(){

 int i = 100;

 System.out.println(i);

  }

}



public class Pri extends Base{

  static int i = 200;

  public static void main(String argv[]){

 Pri p = new Pri();

 System.out.println(i);

  }

}"	MCQ	200	100 followed by 200	Compile time error	100		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"public class MyClass {

 static void print(String s, int i) {

  System.out.println(""String: "" + s + "", int: "" + i);

 }



 static void print(int i, String s) {

  System.out.println(""int: "" + i + "", String: "" + s);

 }



 public static void main(String[] args) {

  print(""String first"", 11);

  print(99, ""Int first"");

 }

}What would be the output?"	MCQ	String: String first, int: 11 int: 99, String: Int first	int: 27, String: Int first String: String first, int: 27	Compilation Error	Runtime Exception		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"A) No argument constructor is provided to all Java classes by default

B) No argument constructor is provided to the class only when no constructor is defined.

C) Constructor can have another class object as an argument

D) Access specifiers are not applicable to Constructor"	MCQ	Only A is TRUE	All are TRUE	B and C is TRUE	All are FALSE		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class Test{ private static void display(){

System.out.println(""Display()"");}

private static void show() { display();

System.out.println(""show()"");}

public static void main(String arg[]){

show();}}"	MCQ	Compiles and prints show()	Compiles and prints Display() show()	Compiles but throws runtime exception	Compilation error		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"Which of the following sentences is true?

A) Access to data member depends on the scope of the class and the scope of data members

B) Access to data member depends only on the scope of the data members

C) Access to data member depends on the scope of the method from where it is accessed"	MCQ	Only A and C is TRUE	All are TRUE	All are FALSE	Only A is TRUE		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"Given:

 public class Yikes {



 public static void go(Long n) {System.out.print(""Long "");}

 public static void go(Short n) {System.out.print(""Short "");}

 public static void go(int n) {System.out.print(""int "");}

 public static void main(String [] args) {

 short y = 6;

 long z = 7;

 go(y);

 go(z);

 }

 }

What is the result?"	MCQ	int Long	Short Long	Compilation fails.	An exception is thrown at runtime.		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			Which of the following will print -4.0	MCQ	System.out.println(Math.ceil(-4.7));	System.out.println(Math.floor(-4.7));	System.out.println(Math.round(-4.7));	System.out.println(Math.min(-4.7));		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Suppose class B is sub class of class A:

A) If class A doesn't have any constructor, then class B also must not have any constructor

B) If class A has parameterized constructor, then class B can have default as well as parameterized constructor

C) If class A has parameterized constructor then call to class A constructor should be made explicitly by constructor of class B"	MCQ	Only B and C is TRUE	Only A is TRUE	All are FALSE	Only A and C is TRUE		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"class Order{

Order(){

System.out.println(""Cat"");

}

public static void main(String... Args){

System.out.println(""Ant"");

}

static{

System.out.println(""Dog"");

}

{

System.out.println(""Man"");

}}

consider the code above & select the proper output from the options."	MCQ	Dog Ant	Dog Man Cat Ant	Man Dog Ant	Dog Man Ant		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class A{ private void display(){ System.out.print(""Hi"");}

public static void main(String ar[]){

display();}}"	MCQ	Compiles but doesn't display anything	Compiles and throws run time exception	Compilation fails	Compiles and displays Hi		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

public class MyClass {

 public static void main(String arguments[]) {

 amethod(arguments);

 }

 public void amethod(String[] arguments) {

 System.out.println(arguments[0]);

 System.out.println(arguments[1]);

 }

}

Command Line arguments - Hi, Hello"	MCQ	prints Hi Hello	Compiler Error	Runs but no output	Runtime Error		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"package QB;

 class Sphere {

       protected int methodRadius(int r) {

   System.out.println(""Radious is: ""+r);

  return 0;

  }

  }

package QB;

public class MyClass {

 public static void main(String[] args) {

 double x = 0.89;

 Sphere sp = new Sphere();

 // Some code missing

}

} to get the radius value what is the code of line to be added ?"	MCQ	methodRadius(x);	sp.methodRadius(x);	Nothing to add	Sphere.methodRadius();		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"class One{

int var1;

One (int x){

var1 = x;

}}

class Derived extends One{

int var2;

void display(){

System.out.println(""var 1=""+var1+""var2=""+var2);

}}

class Main{

public static void main(String[] args){

Derived obj = new Derived();

obj.display();

}}

consider the code above & select the proper output from the options."	MCQ	0 , 0	compiles successfully but runtime error	compile error	none of these		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class Test{ private void display(){

System.out.println(""Display()"");}

private static void show() { display();

System.out.println(""show()"");}

public static void main(String arg[]){

show();}}"	MCQ	Compiles and prints show()	Compiles and prints Display() show()	Compiles but throws runtime exception	Compilation error		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the best option:

class Super{ int x; Super(){x=2;}}

class Sub extends Super { void displayX(){

System.out.print(x);}

public static void main(String args[]){

  new Sub().displayX();}}"	MCQ	Compilation error	Compiles and runs without any output	Compiles and display 2	Compiles and display 0		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"class One{

int var1;

One (int x){

var1 = x;

}}

class Derived extends One{

int var2;

Derived(){

super(10);

var2=10;

}

void display(){

System.out.println(""var1=""+var1+"" , var2=""+var2);

}}

class Main{

public static void main(String[] args){

Derived obj = new Derived();

obj.display();

}}

consider the code above & select the proper output from the options."	MCQ	var1=10 , var2=10	0,0	compile error	runtime error		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"public class MyAr {

 static int i1;

 public static void main(String argv[]) {

 MyAr m = new MyAr();

 m.amethod();

 }

 public void amethod() {

 System.out.println(i1);

 }

}

What is the output of the program?"	MCQ		Compilation Error	Garbage Value	It is not possible to access a static variable in side of non static method		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"What will be printed out if you attempt to compile and run the following code ? 

public class AA {

 public static void main(String[] args) {

 int i = 9;

 switch (i) {

 default:

  System.out.println(""default"");

 case 0:

  System.out.println(""zero"");

  break;

 case 1:

  System.out.println(""one"");

 case 2:

  System.out.println(""two"");

 }

 }

}"	MCQ	Compilation Error	default	default zero	default zero one two		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"Which statements, when inserted at (1), will not result in compile-time errors?

public class ThisUsage {

int planets;

static int suns;

public void gaze() {

int i;

// (1) INSERT STATEMENT HERE

}

}"	MCA	i = this.planets;	i = this.suns;	this = new ThisUsage();	this.i = 4;	this.suns = planets;	0.33	0.33	0	0	0.33

		Access Specifiers Constructors Methods NewQB			Which modifier is used to control access to critical code in multi-threaded programs?	MCQ	default	public	transient	synchronized		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"Given:

package QB;



class Meal {

 Meal() {

  System.out.println(""Meal()"");

 }

}

class Cheese {

 Cheese() {

  System.out.println(""Cheese()"");

 }

}

class Lunch extends Meal {

 Lunch() {

  System.out.println(""Lunch()"");

 }

}

class PortableLunch extends Lunch {

 PortableLunch() {

  System.out.println(""PortableLunch()"");

 }

}

class Sandwich extends PortableLunch {

  private Cheese c = new Cheese();



 public Sandwich() {

  System.out.println(""Sandwich()"");

 }

}

public class MyClass7 {

 public static void main(String[] args) {

  new Sandwich();

 }

} What would be the output?"	MCQ	Meal() Lunch() PortableLunch() Cheese() Sandwich()	Meal() Cheese() Lunch() PortableLunch() Sandwich()	Meal() Lunch() PortableLunch() Sandwich() Cheese()	Cheese() Sandwich() Meal() Lunch() PortableLunch()		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class A{ int a; A(int a){a=4;}}

class B extends A{ B(){super(3);} void displayA(){

System.out.print(a);}

public static void main(String args[]){

 new B().displayA();}}"	MCQ	compiles and display 0	compilation error	Compiles and display 4	Compiles and display 3		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"Given the following code what will be output? 

public class Pass{

  static int j=20;

  public static void main(String argv[]){

 int i=10;

 Pass p = new Pass();

 p.amethod(i);

 System.out.println(i);

 System.out.println(j);

  }



  public void amethod(int x){

 x=x*2;

 j=j*2;

  }

}"	MCQ	Error: amethod parameter does not match variable	20 and 40	10 and 40	10, and 20		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"What will happen if a main() method of a ""testing"" class tries to access a private instance variable of an object using dot notation?"	MCQ	The compiler will automatically change the private variable to a public variable	The compiler will find the error and will not make a .class file	The program will compile and run successfully	The program will compile successfully, but the .class file will not run correctly		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"11. class Mud {

12. // insert code here

13. System.out.println(""hi"");

14. }

15. }

And the following five fragments:

public static void main(String...a) {

public static void main(String.* a) {

public static void main(String... a) {

public static void main(String[]... a) {

public static void main(String...[] a) {

How many of the code fragments, inserted independently at line 12, compile?"	MCQ		1	2	3		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"class Order{

Order(){

System.out.println(""Cat"");

}

public static void main(String... Args){

Order obj = new Order();

System.out.println(""Ant"");

}

static{

System.out.println(""Dog"");

}

{

System.out.println(""Man"");

}}

consider the code above & select the proper output from the options."	MCQ	Man Dog Cat Ant	Cat Ant Dog Man	Dog Man Cat Ant	compile error		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"abstract class MineBase {

 abstract void amethod();

 static int i;

}

public class Mine extends MineBase {

 public static void main(String argv[]){

 int[] ar=new int[5];

 for(i=0;i < ar.length;i++)

 System.out.println(ar[i]);

 }

}"	MCQ	A Sequence of 5 zero's will be printed like 0 0 0 0 0	A Sequence of 5 one's will be printed like 1 1 1 1 1	IndexOutOfBoundes Error	Compilation Error occurs and to avoid them we need to declare Mine class as abstract		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"public class Q {

 public static void main(String argv[]) {

 int anar[] = new int[] { 1, 2, 3 };

 System.out.println(anar[1]);

 }

}"	MCQ	Compiler Error: anar is referenced before it is initialized	2	1	Compiler Error: size of array must be defined		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			A constructor may return value including class type	MCQ	true	false				0	1			

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

package aj; class S{ int roll =23;

private S(){} }

package aj; class T 

{ public static void main(String ar[]){ 

System.out.print(new S().roll);}}"	MCQ	Compilation error	Compiles and display 0	Compiles and display 23	Compiles but no output		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			"public class c123 {

 private c123() {

 System.out.println(""Hellow"");

 }

 public static void main(String args[]) {

 c123 o1 = new c123();

 c213 o2 = new c213();

 }

}

class c213 {

 private c213() {

 System.out.println(""Hello123"");

 }

}



What is the output?"	MCQ	Hellow	It is not possible to declare a constructor as private	Compilation Error	Runs without any output		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"class MyClass1

 {

 private int area(int side)

 {

  return(side * side);

 }

 public static void main(String args[ ])

 {

  MyClass1 MC = new MyClass1( );

  int area = MC.area(50);

  System.out.println(area);

 }

 }

 What would be the output?"	MCQ	Compilation error	Runtime Exception	2500	50		0	0	1	0	

		Access Specifiers Constructors Methods NewQB			"public class MyAr {

 public static void main(String argv[]) {

 MyAr m = new MyAr();

 m.amethod();

 }

 public void amethod() {

 static int i1;

 System.out.println(i1);

 }

}

What is the Output of the Program?"	MCQ		Compile time error because i has not been initialized	Compilation and output of null	It is not possible to declare a static variable in side of non static method or instance method. Because Static variables are class level dependencies.		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"public class MyAr {

 public static void main(String argv[]) {

 MyAr m = new MyAr();

 m.amethod();

 }

 public void amethod() {

 final int i1;

 System.out.println(i1);

 }

}

What is the Output of the Program?"	MCQ		Unresolved compilation problem: The local variable i1 may not have been initialized	Compilation and output of null	None of the given options		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"public class c1 {

private c1()

{

 System.out.println(""Hello"");

}

public static void main(String args[])

{

 c1 o1=new c1();

}

}



What is the output?"	MCQ	Hello	It is not possible to declare a constructor private	Compilation Error	Can't create object because constructor is private		1	0	0	0	

		Access Specifiers Constructors Methods NewQB			Which modifier indicates that the variable might be modified asynchronously, so that all threads will get the correct value of the variable.	MCQ	synchronized	volatile	transient	default		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"class A {

 int i, j;



  A(int a, int b) {

  i = a;

  j = b;

 }

 void show() {

  System.out.println(""i and j: "" + i + "" "" + j);

 }

}

class B extends A {

 int k;



 B(int a, int b, int c) {

  super(a, b);

  k = c;

 }

 void show(String msg) {

  System.out.println(msg + k);

 }

}

class Override {

 public static void main(String args[]) {

  B subOb = new B(3, 5, 7);

  subOb.show(""This is k: ""); // this calls show() in B

  subOb.show(); // this calls show() in A

 }

} What would be the ouput?"	MCQ	This is j: 5 i and k: 3 7	This is i: 3 j and k: 5 7	This is i: 7 j and k: 3 5	This is k: 7 i and j: 3 7		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"Consider the following code and choose the correct option:

class X { int x; X(int x){x=2;}}

class Y extends X{ Y(){} void displayX(){

System.out.print(x);}

public static void main(String args[]){

 new Y().displayX();}}"	MCQ	Compiles and display 2	Compiles and runs without any output	Compiles and display 0	Compilation error		0	0	0	1	

		Access Specifiers Constructors Methods NewQB			"class Order{

Order(){

System.out.println(""Cat"");

}

public static void main(String... Args){

Order obj = new Order();

System.out.println(""Ant"");

}

static{

System.out.println(""Dog"");

}}

consider the code above & select the proper output from the options."	MCQ	Cat Ant Dog	Dog Cat Ant	Ant Cat Dog	none		0	1	0	0	

		Access Specifiers Constructors Methods NewQB			"What will be the result when you attempt to compile this program? 

public class Rand{

  public static void main(String argv[]){

 int iRand;

 iRand = Math.random();

 System.out.println(iRand);

  }

}"	MCQ	Compile time error referring to a cast problem	A random number between 1 and 10	A random number between 0 and 1	A compile time error as random being an undefined method		1	0	0	0	

		Annotations_NewQB			Choose the meta annotations. (Choose THREE)	MCA	Override	Retention	Depricated	Documented	Target	0	0.333333	0	0.333333	0.333333

		Annotations_NewQB			If no retention policy is specified for an annotation, then the default policy of __________ is used.	MCQ	method	class	source	runtime		0	1	0	0	

		Annotations_NewQB			Select the variable which are in java.lang.annotation.RetentionPolicy class. (Choose THREE)	MCA	SOURCE	METHOD	RUNTIME	CONSTRUCTOR	CLASS	0.333333	0	0.333333	0	0.333333

		Annotations_NewQB			Select the Uses of annotations. (Choose THREE)	MCA	Information For the Compiler	Information for the JVM	Compile time and deploytime processing	Runtime processing	Information for the OS	0.333333	0	0.333333	0.333333	0

		Annotations_NewQB			All annotation types should maually extend the Annotation interface. State TRUE/FALSE	MCQ	true	false				0	1			

		Annotations_NewQB			Custom annotations can be created using	MCQ	@interface	@inherit	@include	all the listed options		1	0	0	0	

		Collections_util_NewQB			"Given:

10. interface A { void x(); }

11. class B implements A { 

   public void x() { } 

   public void y() { }    }

12. class C extends B { 

   public void x() {}     }

And:

20. java.util.List<a> list = new    java.util.ArrayList</a>();

21. list.add(new B());

22. list.add(new C());

23. for (A a:list) {

24. a.x();

25. a.y();;

26. }

What is the result?"	MCQ	Compilation fails because of an error in line 25	The code runs with no output.	An exception is thrown at runtime	Compilation fails because of an error in line 21	Compilation fails because of an error in line 23.	1	0	0	0	0

		Collections_util_NewQB			"Given:

 public static Collection get() {

 Collection sorted = new LinkedList();

 sorted.add(""B""); sorted.add(""C""); sorted.add(""A"");

 return sorted;

 }

 public static void main(String[] args) {

 for (Object obj: get()) {

 System.out.print(obj + "", "");

 }

 }

What is the result?"	MCQ	A, B, C,	B, C, A,	Compilation fails.	An exception is thrown at runtime.		0	1	0	0	

		Collections_util_NewQB			"Which statement is true about the following program?

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

public class WhatISThis {

public static void main(String[] na){

List<StringBuilder> list=new ArrayList<StringBuilder>();

list.add(new StringBuilder(""B""));

list.add(new StringBuilder(""A""));

list.add(new StringBuilder(""C""));

Collections.sort(list,Collections.reverseOrder());

System.out.println(list.subList(1,2));

}

}"	MCQ	The program will compile and print the following output: [B]	The program will compile and print the following output: [B,A]	The program will compile and throw a runtime exception	The program will not compile		0	0	1	0	

		Collections_util_NewQB			"Consider the following code and choose the correct option:

public static void before() {

Set set = new TreeSet();

set.add(""2"");

set.add(3);

set.add(""1"");

Iterator it = set.iterator();

while (it.hasNext())

System.out.print(it.next() + "" "");

}"	MCQ	The before() method will print 1 2	The before() method will print 1 2 3	The before() method will throw an exception at runtime	The before() method will not compile		0	0	1	0	

		Collections_util_NewQB			"import java.util.StringTokenizer;

class ST{

public static void main(String[] args){

String input = ""Today is$Holiday"";

StringTokenizer st = new StringTokenizer(input,""$"");

while(st.hasMoreTokens()){

System.out.println(st.nextElement());

}}"	MCQ	Today is Holiday	Today is Holiday	Both	none of the listed options		0	1	0	0	

		Collections_util_NewQB			"Given:

 public static Iterator reverse(List list) {

 Collections.reverse(list);

 return list.iterator();

 }

 public static void main(String[] args) {

 List list = new ArrayList();

 list.add(""1""); list.add(""2""); list.add(""3"");

 for (Object obj: reverse(list))

 System.out.print(obj + "", "");

 }

What is the result?"	MCQ	3, 2, 1,	1, 2, 3,	Compilation fails.	The code runs with no output.		0	0	1	0	

		Collections_util_NewQB			"Which collection class allows you to grow or shrink its size and provides indexed access to

its elements, but its methods are not synchronized?"	MCQ	java.util.HashSet	java.util.LinkedHashSet	java.util.List	java.util.ArrayList	java.util.Vector	0	0	0	1	0

		Collections_util_NewQB			int indexOf(Object o) - What does this method return if the element is not found in the List?	MCQ	null	-1		none of the listed options		0	1	0	0	

		Collections_util_NewQB			"What is the result of attempting to compile and run the following code?

 import java.util.Vector; import java.util.LinkedList; public class Test1{ public static void main(String[] args) { Integer int1 = new Integer(10); Vector vec1 = new Vector(); LinkedList list = new LinkedList(); vec1.add(int1); list.add(int1); if(vec1.equals(list)) System.out.println(""equal""); else System.out.println(""not equal""); } } 1. The code will fail to compile. 2. Runtime error due to incompatible object comparison 3. Will run and print ""equal"". 4. Will run and print ""not equal""."	MCQ	1	2	3	4		0	0	1	0	

		Collections_util_NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){

  Integer arr[]={3,4,3,2};

  Set<Integer> s=new TreeSet<Integer>(Arrays.asList(arr));

  s.add(1);

  for(Integer ele :s){

  System.out.println(ele);  } }}"	MCQ	Compilation error	prints 3,4,2,1,	prints 1,2,3,4	Compiles but exception at runtime		0	0	1	0	

		Collections_util_NewQB			"Inorder to remove one element from the given Treeset, place the appropriate line of code 

public class Main {

 public static void main(String[] args) {

  TreeSet<Integer> tSet = new TreeSet<Integer>();

  System.out.println(""Size of TreeSet : "" + tSet.size());

  tSet.add(new Integer(""1""));

  tSet.add(new Integer(""2""));

  tSet.add(new Integer(""3""));

  System.out.println(tSet.size());

  // remove the one element from the Treeset

  System.out.println(""Size of TreeSet after removal : "" + tSet.size());

 }

}"	MCQ	"tSet.clear(new Integer(""1""));"	"tSetdelete(new Integer(""1""));"	"tSet.remove(new Integer(""1""));"	"tSet.drop(new Integer(""1""));"		0	0	1	0	

		Collections_util_NewQB			"Consider the code below & select the correct ouput from the options:

public class Test{

 public static void main(String[] args) {

 String []colors={""orange"",""blue"",""red"",""green"",""ivory""};

 Arrays.sort(colors);

 int s1=Arrays.binarySearch(colors, ""ivory"");

 int s2=Arrays.binarySearch(colors, ""silver"");

 System.out.println(s1+"" ""+s2); }}"	MCQ	2 -4	3 -5	2 -6	3 -4		0	0	1	0	

		Collections_util_NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  TreeMap<Integer, String> hm=new TreeMap<Integer, String>();

 hm.put(2,""Two"");

 hm.put(4,""Four"");

 hm.put(1,""One"");

 hm.put(6,""Six"");

 hm.put(7,""Seven"");

 SortedMap<Integer, String> sm=hm.subMap(2,7);

 SortedMap<Integer,String> sm2=sm.tailMap(4);

 System.out.print(sm2);

 }}"	MCQ	{2=Two, 4=Four, 6=Six, 7=Seven}	{4=Four, 6=Six, 7=Seven}	{4=Four, 6=Six}	{2=Two, 4=Four, 6=Six}		0	0	1	0	

		Collections_util_NewQB			next() method of Scanner class will return _________	MCQ	Integer	Long	int	String		0	0	0	1	

		Collections_util_NewQB			"Given:

import java.util.Arrays;

import java.util.HashSet;

import java.util.Set;



public class MainClass {



 public static void main(String[] a) {

  String elements[] = { ""A"", ""B"", ""C"", ""D"", ""E"" };

  Set set = new HashSet(Arrays.asList(elements));



  elements = new String[] { ""A"", ""B"", ""C"", ""D"" };

  Set set2 = new HashSet(Arrays.asList(elements));



  System.out.println(set.equals(set2));

 }

} What is the result of given code?"	MCQ	true	false	Compile time error	Runtime Exception		0	1	0	0	

		Collections_util_NewQB			"A)Property files help to decrease coupling

B) DateFormat class allows you to format dates and times with customized styles.

C) Calendar class allows to perform date calculation and conversion of dates and times between timezones.

D) Vector class is not synchronized"	MCQ	A and B is TRUE	A and D is TRUE	A and C is TRUE	B and D is TRUE		0	0	1	0	

		Collections_util_NewQB			Which interface does java.util.Hashtable implement?	MCQ	Java.util.Map	Java.util.List	Java.util.Table	Java.util.Collection		1	0	0	0	

		Collections_util_NewQB			Object get(Object key) - What does this method return if the key is not found in the Map?	MCQ		-1	null	none of the listed options		0	0	1	0	

		Collections_util_NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){

  TreeSet<Integer> ts=new TreeSet<Integer>();

  ts.add(1);

  ts.add(8);

  ts.add(6);

  ts.add(4);

  SortedSet<Integer> ss=ts.subSet(2, 10);

  ss.add(9);

  System.out.println(ts);

  System.out.println(ss);

 }}"	MCQ	[1,4,6,8] [4,6,8,9]	[1,8,6,4] [8,6,4,9]	[1,4,6,8,9] [4,6,8,9]	[1,4,6,8,9] [4,6,8]		0	0	1	0	

		Collections_util_NewQB			"A) Iterator does not allow to insert elements during traversal

B) Iterator allows bidirectional navigation.

C) ListIterator allows insertion of elements during traversal

D) ListIterator does not support bidirectional navigation"	MCQ	A and B is TRUE	A and D is TRUE	A and C is TRUE	B and D is TRUE		0	0	1	0	

		Collections_util_NewQB			static void sort(List list) method is part of ________	MCQ	Collection interface	Collections class	Vector class	ArrayList class		0	1	0	0	

		Collections_util_NewQB			static int binarySearch(List list, Object key) is a method of __________	MCQ	Vector class	ArrayList class	Collection interface	Collections class		0	0	0	1	

		Collections_util_NewQB			Which collection class allows you to access its elements by associating a key with an element's value, and provides synchronization?	MCQ	java.util.SortedMap	java.util.TreeMap	java.util.TreeSet	java.util.Hashtable		0	0	0	1	

		Collections_util_NewQB			"Consider the following code and select the correct output:

import java.util.ArrayList;

import java.util.LinkedList;

import java.util.List;

public class Lists {

public static void main(String[] args) {

List<String> list=new ArrayList<String>();

list.add(""1"");

list.add(""2"");

list.add(1, ""3"");

List<String> list2=new LinkedList<String>(list);

list.addAll(list2);

list2 =list.subList(2,5);

list2.clear();

System.out.println(list);

}

}"	MCQ	[1,3,2]	[1,3,3,2]	[1,3,2,1,3,2]	[3,1,2]	[3,1,1,2]	1	0	0	0	0

		Collections_util_NewQB			"Given:

 import java.util.*;



 public class LetterASort{

 public static void main(String[] args) {

 ArrayList<String> strings = new ArrayList<String>();

 strings.add(""aAaA"");

 strings.add(""AaA"");

 strings.add(""aAa"");

 strings.add(""AAaa"");

 Collections.sort(strings);

 for (String s : strings) { System.out.print(s + "" ""); }

 }

 }

What is the result?"	MCQ	Compilation fails.	aAaA aAa AAaa AaA	AAaa AaA aAa aAaA	AaA AAaa aAaA aAa		0	0	1	0	

		Collections_util_NewQB			"A) It is a good practice to store heterogenous data in a TreeSet.

B) HashSet has default initial capacity (16) and loadfactor(0.75)

C)HashSet does not maintain order of Insertion

D)TreeSet maintains order of Inserstion"	MCQ	A and B is TRUE	A and D is TRUE	A and C is TRUE	B and C is TRUE		0	0	0	1	

		Collections_util_NewQB			"TreeSet<String> s = new TreeSet<String>();

 TreeSet<String> subs = new TreeSet<String>();

 s.add(""a""); s.add(""b""); s.add(""c""); s.add(""d""); s.add(""e"");



 subs = (TreeSet)s.subSet(""b"", true, ""d"", true);

 s.add(""g"");

 s.pollFirst();

 s.pollFirst();

 s.add(""c2"");

 System.out.println(s.size() +"" ""+ subs.size());"	MCA	The size of s is 4	The size of s is 5	The size of subs is 3	The size of s is 7	The size of subs is 1	0	0.5	0.5	0	0

		Collections_util_NewQB			"Consider the following code was executed on June 01, 1983. What will be the output?

class Test{

 public static void main(String args[]){

  Date date=new Date();

  SimpleDateFormat sd;

 sd=new SimplpeDateFormat(""E MMM dd yyyy"");

 System.out.print(sd.format(date));}}"	MCQ	Wed Jun 01 1983	244 JUN 01 1983	PST JUN 01 1983	GMT JUN 01 1983		1	0	0	0	

		Collections_util_NewQB			"Given:

 public class Venus {

 public static void main(String[] args) {

 int [] x = {1,2,3};

 int y[] = {4,5,6};

 new Venus().go(x,y);

 }

 void go(int[]... z) {

 for(int[] a : z)

 System.out.print(a[0]);

 }

 } What is the result?"	MCQ	123	12	14	1		0	0	1	0	

		Collections_util_NewQB			"You wish to store a small amount of data and make it available for rapid access. You do not have a need for the data to be sorted, uniqueness is not an issue and the data will remain fairly static Which data structure might be most suitable for this requirement?



1) TreeSet

2) HashMap

3) LinkedList

4) an array"	MCQ	1	2	3	4		0	0	0	1	

		Collections_util_NewQB			"What will be the output of following code?

class Test{

 public static void main(String args[]){

 TreeSet<Integer> ts=new TreeSet<Integer>();

 ts.add(2);

 ts.add(3);

 ts.add(7);

 ts.add(5);

SortedSet<Integer> ss=ts.subSet(1,7);

 ss.add(4);

 ss.add(6);

System.out.print(ss);}}"	MCQ	[2,3,7,5]	[2,3,7,5,4,6]	[2,3,4,5,6,7]	[2,3,4,5,6]		0	0	0	1	

		Collections_util_NewQB			"Consider the following code and choose the correct option:

class Data{ Integer data; Data(Integer d){data=d;}

 public boolean equals(Object o){return true;}

 public int hasCode(){return 1;}}

class Test{

 public static void main(String ar[]){

  Set<Data> s=new HashSet<Data>();

  s.add(new Data(4));

  s.add(new Data(2));

  s.add(new Data(4));

  s.add(new Data(1));

  s.add(new Data(2));

 System.out.print(s.size());}}"	MCQ	3	5	compilation error	Compiles but error at run time		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the code below & select the correct ouput from the options:

public class Test{

public static void main(String[] args) {

 String num="""";

 z: for(int x=0;x<3;x++)

 for(int y=0;y<2;y++){

  if(x==1) break;

  if(x==2 && y==1) break z;

  num=num+x+y;

 }System.out.println(num);}}"	MCQ	0001	000120	00012021	Compilation error		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public class Test {

 public enum Dogs {collie, harrier};

 public static void main(String [] args) {

 Dogs myDog = Dogs.collie;

 switch (myDog) {

 case collie:

 System.out.print(""collie "");

 case harrier:

 System.out.print(""harrier "");

 }

 }

 }

What is the result?"	MCQ	collie	harrier	Compilation fails.	collie harrier		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  boolean flag=true;

  if(flag=false){

  System.out.print(""TRUE"");}else{

  System.out.print(""FALSE"");}}}"	MCQ	true	false	compilation error	Compiles		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Cosider the following code and choose the correct option: 

class Test{

 public static void main(String args[]){  System.out.println(Integer.parseInt(""2147483648"", 10));

 }}"	MCQ	Compilation error	2.147483648E9	NumberFormatException at run time	Compiles but no output		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public class Test {

 public enum Dogs {collie, harrier, shepherd};

 public static void main(String [] args) {

 Dogs myDog = Dogs.shepherd;

 switch (myDog) {

 case collie:

 System.out.print(""collie "");

 case default:

 System.out.print(""retriever "");

 case harrier:

 System.out.print(""harrier "");

 }

 }

 }

What is the result?"	MCQ	harrier	shepherd	retriever	Compilation fails.		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"Given:

static void myFunc()

  {

  int i, s = 0;

  for (int j = 0; j < 7; j++) {

  i = 0;

  do {

  i++;

  s++;

  } while (i < j);

  }

  System.out.println(s);

  }

   } What would be the result"	MCQ	20	21	22	23	24	0	0	1	0	0

		Control structures wrapper classes auto boxing NewQB			"What is the range of the random number r generated by the code below?

int r = (int)(Math.floor(Math.random() * 8)) + 2;"	MCQ	2 <= r <= 9	3 <= r <= 10	2<= r <= 10	3 <= r <= 9		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"class Test{

 public static void main(String[] args) {

 int x=-1,y=-1;  

 if(++x=++y)    

  System.out.println(""R.T. Ponting""); 

 else     

  System.out.println(""C.H. Gayle"");

 }

}

consider the code above & select the proper output from the options."	MCQ	R.T.Ponting	C.H.Gayle	Compile error	none of the listed options		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public class Breaker2 {

 static String o = """";

 public static void main(String[] args) {

 z:

 for(int x = 2; x < 7; x++) {

 if(x==3) continue;

 if(x==5) break z;

 o = o + x;

 }

 System.out.println(o);

 }

 }

What is the result?"	MCQ	2	24	234	246		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  int a=5;

  if(a=3){

  System.out.print(""Three"");}else{

 System.out.print(""Five"");}}}"	MCQ	Compilation error	Three	Five	Compiles but no output		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public class Batman {

 int squares = 81;

 public static void main(String[] args) {

 new Batman().go();

 }

 void go() {

 incr(++squares);

 System.out.println(squares);

 }

 void incr(int squares) { squares += 10; }

 }

What is the result?"	MCQ	81	82	91	92		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"public void foo( boolean a, boolean b)

{ 

  if( a ) 

  {

    System.out.println(""A""); /* Line 5 */

  } 

  else if(a && b) /* Line 7 */

  { 

    System.out.println( ""A && B""); 

  } 

  else /* Line 11 */

  { 

    if ( !b ) 

    {

      System.out.println( ""notB"") ;

    } 

    else 

    {

      System.out.println( ""ELSE"" ) ; 

    } 

  } 

}



What would be the result?"	MCQ	"If a is true and b is false then the output is ""notB"""	"If a is true and b is true then the output is ""A && B"""	"If a is false and b is false then the output is ""ELSE"""	"If a is false and b is true then the output is ""ELSE"""		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"What is the value of �n� after executing the following code?

int n = 10;

int p = n + 5;

int q = p - 10;

int r = 2 * (p - q);

switch(n)

{

case p: n = n + 1;

case q: n = n + 2;

case r: n = n + 3;

default: n = n + 4;

}"	MCQ	14	28	Compilation Error	10	Runtime Error	0	0	1	0	0

		Control structures wrapper classes auto boxing NewQB			"public class While 

{

  public void loop() 

  {

    int x= 0;

    while ( 1 ) /* Line 6 */

    {

      System.out.print(""x plus one is "" + (x + 1)); /* Line 8 */

    }

  }

}



Which statement is true?"	MCQ	There is a syntax error on line 1	There are syntax errors on lines 1 and 6	There are syntax errors on lines 1, 6, and 8	There is a syntax error on line 6		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"Which of the following loop bodies DOES compute the product from 1 to 10 like (1 * 2 * 3 * 4 * 5 *

6 * 7 * 8 * 9 * 10)?

int s = 1;

for (int i = 1; i <= 10; i++)

{

<What to put here?>

}"	MCQ	s += i * i;	s++;	s = s + s * i;	s *= i;	Compilation error	0	0	0	1	0

		Control structures wrapper classes auto boxing NewQB			Which of the following statements are true regarding wrapper classes? (Choose TWO)	MCA	String is a wrapper class	Double has a compareTo() method	Character has a intValue() method	Byte extends Number	String is the wrapper class of char	0	0.5	0	0.5	0

		Control structures wrapper classes auto boxing NewQB			"Given:

 class Atom {

 Atom() { System.out.print(""atom ""); }

 }

 class Rock extends Atom {

 Rock(String type) { System.out.print(type); }

}

 public class Mountain extends Rock {

 Mountain() {

 super(""granite "");

 new Rock(""granite "");

 }

 public static void main(String[] a) { new Mountain(); }

 }

What is the result?"	MCQ	Compilation fails.	granite granite	atom granite granite	atom granite atom granite		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"What are the thing to be placed to complete the code?

class Wrap {

 public static void main(String args[]) {



  _______________ iOb = ___________ Integer(100);



  int i = iOb.intValue();



  System.out.println(i + "" "" + iOb); // displays 100 100

 }

}"	MCQ	int, int	Integer, new	Integer, int	int, Integer		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"public class SwitchTest 

{  

  public static void main(String[] args) 

  {

    System.out.println(""value ="" + switchIt(4)); 

  } 

  public static int switchIt(int x) 

  {

    int j = 1;  

    switch (x) 

    { 

      case 1: j++; 

      case 2: j++;  

      case 3: j++; 

      case 4: j++; 

      case 5: j++; 

      default: j++; 

      } 

    return j + x;  

  } 

}

What will be the output of the program?"	MCQ	value = 8	value = 2	value = 4	value = 6		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public class Barn {

 public static void main(String[] args) {

 new Barn().go(""hi"", 1);

 new Barn().go(""hi"", ""world"", 2);

 }

 public void go(String... y, int x) {

 System.out.print(y[y.length - 1] + "" "");

 }

 }

What is the result?"	MCQ	hi hi	hi world	world world	Compilation fails.		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){  int x=034;

  int y=12;   

  int ans=x+y;

  System.out.println(ans);

 }}"	MCQ	40	46	compilation error	Compiles but error at run time		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"11. double input = 314159.26;

12. NumberFormat nf = NumberFormat.getInstance(Locale.ITALIAN);

13. String b;

14. //insert code here



Which code, inserted at line 14, sets the value of b to 314.159,26?"	MCQ	b = nf.parse( input );	b = nf.format( input );	b = nf.equals( input );	b = nf.parseObject( input );		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

class Test{

public static void main(String ar[]){

 TreeMap<Integer,String> tree = new TreeMap<Integer,String>();

 tree.put(1, ""one"");

 tree.put(2, ""two"");

 tree.put(3, ""three"");

 tree.put(4,""Four"");

  System.out.println(tree.higherKey(2));

  System.out.println(tree.ceilingKey(2));

  System.out.println(tree.floorKey(1));

  System.out.println(tree.lowerKey(1));

}}"	MCQ	3 2 1 null	3 2 1 1	2 2 1 1	4 2 1 1		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option: 

class Test{

 public static void main(String args[]){

 Long data=23;

 System.out.println(data); }}"	MCQ	23	Compilation error	Compiles but error at run time	None of the listed options		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"class AutoBox {

  public static void main(String args[]) {

  

 int i = 10;  

 Integer iOb = 100; 

   i = iOb; 

   System.out.println(i + "" "" + iOb); 

  }

 } whether this code work properly, if so what would be the result?"	MCQ	No, Compilation error	No, Runtime error	Yes, 10, 100	Yes, 100, 100		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option: 

class Test{

 public static void main(String args[]){

 Long l=0l;

 System.out.println(l.equals(0));}}"	MCQ	Compilation error	true	false	1		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"int I = 0;

  outer:

  while (true) 

  {

    I++;

    inner:

    for (int j = 0; j < 10; j++) 

    {

      I += j;

      if (j == 3)

        continue inner;

      break outer;

    }

    continue outer;

  }

System.out.println(I);



What will be thr result?"	MCQ	3	2	4	1		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			"what will be the result of attempting to compile and run the following class?

Public class IFTest{

public static void main(String[] args){

int i=10;

if(i==10)       

if(i<10)

System.out.println(""a"");

else

System.out.println(""b"");

}}"	MCQ	The code will fail to compile because the syntax of the if statement is incorrect	The code will fail to compile because the compiler will not be able to determine which if statement the else clause belongs to	The code will compile correctly and display the letter a,when run	The code will compile correctly and display the letter b,when run	The code will compile correctly,but will not display any output	0	0	0	1	0

		Control structures wrapper classes auto boxing NewQB			"What is the output of the following code :

class try1{

 public static void main(String[] args) {

 System.out.println(""good"");

 while(false){

  System.out.println(""morning"");

 }

 }

}"	MCQ	good	good morning morning �.	compiler error	runtime error		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  int num=3;  switch(num){

  case 1: case 3: case 4: {

  System.out.println(""bat man""); }   

  case 2: case 5: {

  System.out.println(""spider man""); }break; } }}"	MCQ	bat man	Compilation error	bat man spider man	spider man		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

int n = 10;

switch(n)

{

case 10: n = n + 1;

case 15: n = n + 2;

case 20: n = n + 3;

case 25: n = n + 4;

case 30: n = n + 5;

}

System.out.println(n);

What is the value of �n� after executing the following code?"	MCQ	23	32	25	Compilation Error	Runtine Error	0	0	1	0	0

		Control structures wrapper classes auto boxing NewQB			"What will be the output of following code? 



TreeSet map = new TreeSet();

map.add(""one"");

map.add(""two"");

map.add(""three"");

map.add(""four"");

map.add(""one"");

Iterator it = map.iterator();

while (it.hasNext() ) 

{

  System.out.print( it.next() + "" "" );

}"	MCQ	one two three four	four three two one	four one three two	one two three four one		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"public class Test {

 public static void main(String [] args) {

 int x = 5;

 boolean b1 = true;

 boolean b2 = false;



 if ((x == 4) && !b2 )

 System.out.print(""1 "");

 System.out.print(""2 "");

 if ((b2 = true) && b1 )

System.out.print(""3 "");

 }

 }

What is the result?"	MCQ	2	3	2 3	1 2 3		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			Which of these statements are true?	MCA	HashTable is a sub class of Dictionary	ArrayList is a sub class of Vector	LinkedList is a subclass of ArrayList	Stack is a subclass of Vector		0.5	0	0	0.5	

		Control structures wrapper classes auto boxing NewQB			"Given:

 import java.util.*;

 public class Explorer3 {

 public static void main(String[] args) {

 TreeSet<Integer> s = new TreeSet<Integer>();

 TreeSet<Integer> subs = new TreeSet<Integer>();

 for(int i = 606; i < 613; i++)

 if(i%2 == 0) s.add(i);

 subs = (TreeSet)s.subSet(608, true, 611, true);

 subs.add(629);

 System.out.println(s + "" "" + subs);

 }

 }

What is the result?"	MCQ	Compilation fails.	[608, 610, 612, 629] [608, 610]	An exception is thrown at runtime.	[608, 610, 612, 629] [608, 610, 629]		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"What is the output :

class try1{

 public static void main(String[] args) {

 int x=1;  

 if(x--)   

  System.out.println(""good"");

 else    

 System.out.println(""bad"");

  }

 }"	MCQ	good	bad	compile error	run time error		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  int num='b';  switch(num){

  default :{

  System.out.print(""default"");}

  case 100 : case 'b' : case 'c' : {

  System.out.println(""brownie""); break;}   

  case 200: case 'e': {

  System.out.println(""pastry""); }break; } }}"	MCQ	brownie	default brownie	compilation error	default		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given: 

int a = 5;

int b = 5;

int c = 5;

if (a > 3)

if (b > 4)

if (c > 5)

c += 1;

else

c += 2;

else

c += 3;

c += 4;

What is the value of variable c after executing the following code?"	MCQ	3	5	7	9	11	0	0	0	0	1

		Control structures wrapper classes auto boxing NewQB			"Given:

 Float pi = new Float(3.14f);

 if (pi > 3) {

 System.out.print(""pi is bigger than 3. "");

 }

 else {

 System.out.print(""pi is not bigger than 3. "");

 }

 finally {

 System.out.println(""Have a nice day."");

 }

What is the result?"	MCQ	Compilation fails.	pi is bigger than 3.	An exception occurs at runtime.	pi is bigger than 3. Have a nice day.		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public void go() {

 String o = """";

 z:

 for(int x = 0; x < 3; x++) {

 for(int y = 0; y < 2; y++) {

 if(x==1) break;

 if(x==2 && y==1) break z;

 o = o + x + y;

 }

 }

 System.out.println(o);

 }

What is the result when the go() method is invoked?"	MCQ	00	0001	000120	00012021		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Examine the following code: 



  int count = 1;                  

  while ( ___________ )  

  {

   System.out.print( count + "" "" );

   count = count + 1;

  }

  System.out.println( );



What condition should be used so that the code prints: 



1 2 3 4 5 6 7 8"	MCQ	count < 9	count+1 <= 8	count < 8	count != 8		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"What will be the output of the program? 



public class Switch2 

{

  final static short x = 2;

  public static int y = 0;

  public static void main(String [] args) 

  {

    for (int z=0; z < 3; z++) 

    {

      switch (z) 

      {

        case y: System.out.print(""0 "");  /* Line 11 */

        case x-1: System.out.print(""1 ""); /* Line 12 */

        case x: System.out.print(""2 "");  /* Line 13 */

      }

    }

  }

}"	MCQ	0 1 2	0 1 2 1 2 2	Compilation fails at line 11	Compilation fails at line 12.		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 int x = 0;

 int y = 10;

 do {

 y--;

 ++x;

 } while (x < 5);

 System.out.print(x + "","" + y);

What is the result?"	MCQ	5,6	5,5	6,5	6,6		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"What is the output :

class Test{

 public static void main(String[] args) {

  int a=5,b=10,c=1;   

  if(a>c){     

  System.out.println(""success"");  

  }   

  else{ 

  break;   

  }

  }

 }"	MCQ	success	runtime error	compiler error	none of the listed options		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

public class Test{

public static void main(String[] args) {

 int x = 0;

 int y = 10;

 do {

 y--;

 ++x;

 } while (x < 5);

 System.out.print(x + "","" + y);

}

}"	MCQ	5,6	5,5	6,5	6,6		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){

  int l=7;

  Long L = (Long)l;  

  System.out.println(L); }}"	MCQ	7	Compilation error	Compiles but error at run time	None of the listed options		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

double height = 5.5;

  if(height-- >= 5.0)

  System.out.print(""tall "");

  if(--height >= 4.0)

  System.out.print(""average "");

  if(height-- >= 3.0)

  System.out.print(""short "");

  else

  System.out.print(""very short "");

 }

What would be the Result?"	MCQ	tall	tall short	short	very short	average	0	1	0	0	0

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){

  String hexa  = ""0XFF"";  

 int number = Integer.decode(hexa);  

  System.out.println(number); }}"	MCQ	Compilation error	1515	255	Compiles but error at run time		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

int i = l, j = -1; 

switch (i) 

{

  case 0, 1: j = 1;

  case 2: j = 2; 

  default: j = 0; 

} 

System.out.println(""j = "" + j);"	MCQ	j = -1	j = 0	j = 1	Compilation fails		0	0	0	1	

		Control structures wrapper classes auto boxing NewQB			Which of the following statements about arrays is syntactically wrong?	MCQ	Person[] p = new Person[5];	Person p[5];	Person[] p [];	Person p[][] = new Person[2][];		0	1	0	0	

		Control structures wrapper classes auto boxing NewQB			"What will be the output of following code? 



import java.util.*; 

class I 

{

  public static void main (String[] args) 

  {

    Object i = new ArrayList().iterator(); 

    System.out.print((i instanceof List)+"",""); 

    System.out.print((i instanceof Iterator)+"",""); 

    System.out.print(i instanceof ListIterator); 

  } 

}"	MCQ	Prints: false, false, false	Prints: false, false, true	Prints: false, true, false	Prints: false, true, true		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"Given:

 public static void test(String str) {

 int check = 4;

 if (check = str.length()) {

 System.out.print(str.charAt(check -= 1) +"", "");

 } else {

 System.out.print(str.charAt(0) + "", "");

 }

 }

and the invocation:

 test(""four"");

 test(""tee"");

 test(""to"");

What is the result?"	MCQ	r, t, t,	r, e, o,	Compilation fails.	An exception is thrown at runtime.		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"What will be the output of the program? 

int x = 3; 

int y = 1; 

if (x = y) /* Line 3 */

{

  System.out.println(""x ="" + x); 

}"	MCQ	x = 1	x = 3	Compilation fails.	The code runs with no output.		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"import java.util.SortedSet;

import java.util.TreeSet;



public class Main {



 public static void main(String[] args) {

  TreeSet<String> tSet = new TreeSet<String>();

  tSet.add(""1"");

  tSet.add(""2"");

  tSet.add(""3"");

  tSet.add(""4"");

  tSet.add(""5"");

  SortedSet sortedSet =_____________(""3"");

  System.out.println(""Head Set Contains : "" + sortedSet);

 }

} What is the missing method in the code to get the head set of the tree set?"	MCQ	tSet.headSet	tset.headset	headSet	HeadSet		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct output:

class Test{

 public static void main(String args[]){

  int num=3;  switch(num){

  default :{

  System.out.print(""default"");}

  case 1: case 3: case 4: {

  System.out.println(""apple""); break;}   

  case 2: case 5: {

  System.out.println(""black berry""); }break; } }}"	MCQ	apple	default apple	compilation error	default		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void main(String args[]){

  Long L = null;  long l = L;

 System.out.println(L); 

 System.out.println(l);

 }}"	MCQ	null 0	Compilation error	Compiles but error at run time	0 null		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"What does the following code fragment write to the monitor? 





int sum = 21; 

if ( sum != 20 )

 System.out.print(""You win "");

else

 System.out.print(""You lose "");



System.out.println(""the prize."");



What does the code fragment prints?"	MCQ	You win the prize	You lose the prize.	You win	You lose		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			Which statements are true about maps? (Choose TWO)	MCA	The return type of the values() method is set	Changes made in the Set view returned by keySet() will be reflected in the original map	The Map interface extends the Collection interface	All keys in a map are unique	All Map implementations keep the keys sorted	0	0.5	0	0.5	0

		Control structures wrapper classes auto boxing NewQB			Which collection implementation is suitable for maintaining an ordered sequence of objects,when objects are frequently inserted in and removed from the middle of the sequence?	MCQ	TreeMap	HashSet	Vector	LinkedList	ArrayList	0	0	0	1	0

		Control structures wrapper classes auto boxing NewQB			Choose TWO correct options:	MCA	OutputStream is the abstract superclass of all classes that represent an outputstream of bytes.	Subclasses of the class Reader are used to read character streams.	To write characters to an outputstream, you have to make use of the class CharacterOutputStream.	To write an object to a file, you use the class ObjectFileWriter		0.5	0.5	0	0	

		Control structures wrapper classes auto boxing NewQB			"What is the output :

class One{

 public static void main(String[] args) {

 int a=100;  

 if(a>10)   

  System.out.println(""M.S.Dhoni"");  

 else if(a>20)    

  System.out.println(""Sachin"");  

 else if(a>30)     

  System.out.println(""Virat Kohli"");}

 }"	MCQ	M.S.Dhoni	M.S.Dhoni Sachin Virat Kohli	Virat Kohli	all of these		1	0	0	0	

		Control structures wrapper classes auto boxing NewQB			Which of the following statements is TRUE regarding a Java loop?	MCQ	A continue statement doesn�t transfer control to the test statement of the for loop	An overflow error can only occur in a loop	A loop may have multiple exit points	If a variable of type int overflows during the execution of a loop, it will cause an exception		0	0	1	0	

		Control structures wrapper classes auto boxing NewQB			"switch(x) 

{ 

 default: 

 System.out.println(""Hello""); 

}

Which of the following are acceptable types for x? 

1.byte 

2.long 

3.char 

4.float 

5.Short 

6.Long"	MCQ	1 ,3 and 5	2 and 4	3 and 5	4 and 6		1	0	0	0	

		Exception_handling_NewQB			Which are true with respect to finally block? (Choose THREE)	MCA	Used to release the resources which are obtained in try block.	Writing finally block is optional.	When an exception occurs then a part of try block will execute one appropriate catch block and finally block will be executed.	finally block will never execute when no exceptions are there.	When no exception occurs then complete try block and finally block will execute but no catch block will execute.	0.25	0.25	0.25	0	0.25

		Exception_handling_NewQB			"What will happen when you attempt to compile and run the following code?

public class Bground extends Thread{

public static void main(String argv[]){

        Bground b = new Bground();

        b.run();

    }

    public void start(){

        for (int i = 0; i <10; i++){

            System.out.println(""Value of i = "" + i);

        }

    }

}"	MCQ	A compile time error indicating that no run method is defined for the Thread class	A run time error indicating that no run method is defined for the Thread class	Clean compile and at run time the values 0 to 9 are printed out	Clean compile but no output at runtime		0	0	0	1	

		Exception_handling_NewQB			"Given:

 public void testIfA() {

 if (testIfB(""True"")) {

 System.out.println(""True"");

 } else {

 System.out.println(""Not true"");

 }

 }

 public Boolean testIfB(String str) {

 return Boolean.valueOf(str);

 }

What is the result when method testIfA is invoked?"	MCQ	true	Not true	An exception is thrown at runtime.	none		1	0	0	0	

		Exception_handling_NewQB			Which of the following statements are true? (Choose TWO)	MCA	Deadlock will not occur if wait()/notify() is used	The wait() method is overloaded to accept a duration	A thread will resume execution as soon as its sleep duration expires.	The notify() method is overloaded to accept a duration	Both wait() and notify() must be called from a synchronized context.	0	0.33	0.33	0	0.33

		Exception_handling_NewQB			"public class MyProgram 

{

  public static void throwit() 

  {

    throw new RuntimeException();

  }

  public static void main(String args[])

  {

    try 

    {

      System.out.println(""Hello world "");

      throwit();

      System.out.println(""Done with try block "");

    }

    finally 

    {

      System.out.println(""Finally executing "");

    }

  }

}

which answer most closely indicates the behavior of the program?"	MCQ	The program will not compile.	The program will print Hello world, then will print that a RuntimeException has occurred, then will print Done with try block, and then will print Finally executing.	The program will print Hello world, then will print that a RuntimeException has occurred, and then will print Finally executing.	The program will print Hello world, then will print Finally executing, then will print that a RuntimeException has occurred.		0	0	0	1	

		Exception_handling_NewQB			If a method is capable of causing an exception that it does not handle, it must specify this behavior using throws so that callers of the method can guard themselves against such Exception	MCQ	false	true				0	1			

		Exception_handling_NewQB			"A) Checked Exception must be explicity caught or propagated to the calling method 

B) If runtime system can not find an appropriate method to handle the exception, then the runtime system terminates and uses the default exception handler."	MCQ	Only A is TRUE	Only B is TRUE	Bothe A and B is TRUE	Both A and B is FALSE		0	0	1	0	

		Exception_handling_NewQB			"public class RTExcept 

{

  public static void throwit () 

  {

    System.out.print(""throwit "");

    throw new RuntimeException();

  }

  public static void main(String [] args) 

  {

    try 

    {

      System.out.print(""hello "");

      throwit();

    }

    catch (Exception re ) 

    {

      System.out.print(""caught "");

    }

    finally 

    {

      System.out.print(""finally "");

    }

    System.out.println(""after "");

  }

}"	MCQ	hello throwit caught finally after	hello throwit caught	hello throwit RuntimeException caught after	Compilation fails		1	0	0	0	

		Exception_handling_NewQB			"class s implements Runnable 

{ 

  int x, y; 

  public void run() 

  { 

    for(int i = 0; i < 1000; i++) 

      synchronized(this) 

      { 

        x = 12; 

        y = 12; 

      } 

    System.out.print(x + "" "" + y + "" ""); 

  } 

  public static void main(String args[]) 

  { 

    s run = new s(); 

    Thread t1 = new Thread(run); 

    Thread t2 = new Thread(run); 

    t1.start(); 

    t2.start(); 

  } 

} What is the output?"	MCQ	DeadLock	Compilation Error	Cannot determine output.	prints 12 12 12 12		0	0	0	1	

		Exception_handling_NewQB			"What is wrong with the following code?



Class MyException extends Exception{}

public class Test{

public void foo() {

try {

bar();

} finally {

baz();

} catch(MyException e) {}

}

public void bar() throws MyException {

throw new MyException();

}

public void baz() throws RuntimeException {

throw new RuntimeException();

}

}"	MCQ	Since the method foo() does not catch the exception generated by the method baz(),it must declare the RuntimeException in a throws clause	A try block cannot be followed by both a catch and a finally block	An empty catch block is not allowed	A catch block cannot follow a finally block	A finally block must always follow one or more catch blocks	0	0	0	1	0

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

class Test{

static void test() throws RuntimeException {

 try { System.out.print(""test "");

 throw new RuntimeException();

 } catch (Exception ex) {   System.out.print(""exception ""); }

 } public static void main(String[] args) {

 try { test(); } catch (RuntimeException ex) { System.out.print(""runtime ""); } System.out.print(""end""); } }"	MCQ	test end	test runtime end	test exception runtime end	test exception end		0	0	0	1	

		Exception_handling_NewQB			Choose TWO correct options:	MCA	If an exception is not caught in a method,the method will terminate and normal execution will resume	An overriding method must declare that it throws the same exception classes as the method it overrides	The main() method of a program can declare that it throws checked exception	A method declaring that it throws a certain exception class may throw instances of any subclass of that exception class	Finally blocks are executed if,an exception gets thrown while inside the corresponding try block	0	0	0.5	0.5	0

		Exception_handling_NewQB			"Which four can be thrown using the throw statement? 



1.Error 

2.Event 

3.Object 

4.Throwable 

5.Exception 

6.RuntimeException"	MCQ	1, 2, 3 and 4	2, 3, 4 and 5	1, 4, 5 and 6	2, 4, 5 and 6		0	0	1	0	

		Exception_handling_NewQB			"class X implements Runnable 

{ 

  public static void main(String args[]) 

  {

    /* Missing code? */

  } 

  public void run() {} 

}

Which of the following line of code is suitable to start a thread ?"	MCQ	Thread t = new Thread(X);	Thread t = new Thread(X); t.start();	X run = new X(); Thread t = new Thread(run); t.start();	Thread t = new Thread(); x.run();		0	0	1	0	

		Exception_handling_NewQB			"Given:

 class X { public void foo() { System.out.print(""X ""); } }



 public class SubB extends X {

 public void foo() throws RuntimeException {

 super.foo();

 if (true) throw new RuntimeException();

 System.out.print(""B "");

 }

 public static void main(String[] args) {

 new SubB().foo();

 }

 }

What is the result?"	MCQ	X, followed by an Exception.	No output, and an Exception is thrown.	X, followed by an Exception, followed by B.	none		1	0	0	0	

		Exception_handling_NewQB			"What will the output of following code?



try 

{ 

  int x = 0; 

  int y = 5 / x; 

} 

catch (Exception e) 

{

  System.out.println(""Exception""); 

} 

catch (ArithmeticException ae) 

{

  System.out.println("" Arithmetic Exception""); 

} 

System.out.println(""finished"");"	MCQ	finished	Exception	compilation fails	ArithmeticException		0	0	1	0	

		Exception_handling_NewQB			Which of the following methods are static?	MCA	start()	join()	yield()	sleep()		0	0	0.5	0.5	

		Exception_handling_NewQB			Which of the following statements regarding static methods are correct? (2 answers)	MCA	static methods are difficult to maintain, because you can not change their implementation.	static methods can be called using an object reference to an object of the class in which this method is defined.	static methods are always public, because they are defined at class-level.	static methods do not have direct access to non-static methods which are defined inside the same class.		0	0.5	0	0.5	

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

class Test{

 static void display(){

  throw new RuntimeException();

 } public static void main(String args[]){

   try{display();

   }catch(Exception e){ throw new NullPointerException();}    

    finally{try{ display();     

    }catch(NullPointerException e){  System.out.println(""caught"");}

    finally{ System.out.println(""exit"");}}}}"	MCQ	caught exit	exit	exit RuntimeException thrown at run time	Compilation fails		0	0	1	0	

		Exception_handling_NewQB			"class Test{

public static void main(String[] args){

try{

Integer.parseInt(""1.0"");

}

catch(Exception e){

System.out.println(""Exception occurred"");

}

catch(RuntimeException ex){

System.out.println(""RuntimeException"");

}

} }

consider the code above & select the proper output from the options."	MCQ	Exception occurred	RuntimeException	Exception occurred RuntimeException	does not compile		0	0	0	1	

		Exception_handling_NewQB			"Which three of the following are methods of the Object class? 



1.notify(); 

2.notifyAll(); 

3.isInterrupted(); 

4.synchronized(); 

5.interrupt(); 

6.wait(long msecs); 

7.sleep(long msecs); 

8.yield();"	MCQ	1, 2, 4	2, 4, 5	1, 2, 6	2, 3, 4		0	0	1	0	

		Exception_handling_NewQB			"In the given code snippet

try { int a = Integer.parseInt(""one""); }

what is used to create an appropriate catch block? (Choose all that apply.)

A. ClassCastException

B. IllegalStateException

C. NumberFormatException

D. IllegalArgumentException"	MCA	ClassCastException	NumberFormatException	IllegalStateException	IllegalArgumentException		0	0.5	0	0.5	

		Exception_handling_NewQB			"class Trial{

public static void main(String[] args){

try{

System.out.println(""One"");

int y = 2 / 0;

System.out.println(""Two"");

} 

catch(RuntimeException ex){

System.out.println(""Catch"");

} 

finally{

System.out.println(""Finally"");

}

} }"	MCQ	One Two Catch Finally	One Catch	One Catch Finally	One Two Catch		0	0	1	0	

		Exception_handling_NewQB			"Which digit,and in what order,will be printed when the following program is run?



Public class MyClass {

 public static void main(String[] args) {

  int k=0;

 try {

     int i=5/k;

    }

catch(ArithmeticException e) {

  System.out.println(""1"");

  }

catch(RuntimeException e) {

  System.out.println(""2"");

 return;

  }

catch(Exception e) {

  System.out.println(""3"");

  }

finally{

System.out.println(""4"");

}

System.out.println(""5"");

}

}"	MCQ	The program will only print 5	The program will only print 1 and 4 in order	The program will only print 1,2 and 4 in order	The program will only print 1 ,4 and 5 in order	The program will only print 1,2,4 and 5 in order	0	0	0	1	0

		Exception_handling_NewQB			"class Trial{

public static void main(String[] args){

try{

System.out.println(""Java is portable"");

} } }"	MCQ	Java is portable	We cannot have a try block without a catch block	We cannot have a try block block without a catch / finally block	Nothing is diaplayed		0	0	1	0	

		Exception_handling_NewQB			"class Animal { public String noise() { return ""peep""; } }

 class Dog extends Animal {

 public String noise() { return ""bark""; }

 }

 class Cat extends Animal {

 public String noise() { return ""meow""; }

 }

class try1{

public static void main(String[] args){

Animal animal = new Dog();

 Cat cat = (Cat)animal;

 System.out.println(cat.noise());

}}

consider the code above & select the proper output from the options."	MCQ	bark	meow	Compilation fails	An exception is thrown at runtime.	peep	0	0	0	1	0

		Exception_handling_NewQB			"Given:

class X implements Runnable 

{ 

  public static void main(String args[]) 

  {

    /* Some code */

  } 

  public void run() {} 

}

Which of the following line of code is suitable to start a thread ?"	MCQ	X run = new X(); Thread t = new Thread(run); t.start();	Thread t = new Thread(X);	Thread t = new Thread(); x.run();	Thread t = new Thread(X); t.start();		1	0	0	0	

		Exception_handling_NewQB			Which statement is true?	MCQ	A static method cannot be synchronized.	If a class has synchronized code, multiple threads can still access the nonsynchronized code.	Variables can be protected from concurrent access problems by marking them with the synchronized keyword.	When a thread sleeps, it releases its locks		0	1	0	0	

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

class Test{

 static void display(){

  throw new RuntimeException();

 }

   public static void main(String args[]){

   try{display();

   }catch(Exception e){ }

    catch(RuntimeException re){}

    finally{System.out.println(""exit"");}}}"	MCQ	exit	Compiles and no output	Compilation fails	Compiles but exception at runtime		0	0	1	0	

		Exception_handling_NewQB			"Given:

public class ExceptionTest 

{ 

  class TestException extends Exception {} 

  public void runTest() throws TestException {} 

  public void test() /* Line X */ 

  { 

    runTest(); 

  } 

}

At Line X, which code is necessary to make the code compile?"	MCQ	No code is necessary	throws Exception	throw Exception	throws RuntimeException		0	1	0	0	

		Exception_handling_NewQB			Which two can be used to create a new Thread?	MCA	Implement java.lang.Runnable and implement the run() method.	Extend java.lang.Thread and override the run() method.	Implement java.lang.Thread and implement the start() method.	Extend java.lang.Runnable and override the start() method.	Implement java.lang.Thread and implement the run() method.	0.5	0.5	0	0	0

		Exception_handling_NewQB			Choose the correct option:	MCQ	A try statement must have at least one corresponding catch block	Multiple catch statements can catch the same class of exception more than once.	An Error that might be thrown in a method must be declared as thrown by that method, or be handled within that method.	Except in case of VM shutdown, if a try block starts to execute, a corresponding finally block will always start to execute.		0	0	0	1	

		Exception_handling_NewQB			"class PropagateException{

public static void main(String[] args){

try{

method();

System.out.println(""method() called"");

}

catch(ArithmeticException ex){

System.out.println(""Arithmetic Exception"");

}

catch(RuntimeException re){

System.out.println(""Runtime Exception"");

}}

static void method(){

int y = 2 / 0;

}}

consider the code above & select the proper output from the options."	MCQ	Arithmetic Exception	Runtime Exception	Arithmetic Exception Runtime Exception	compilation error		1	0	0	0	

		Exception_handling_NewQB			"Given:

 static void test() {

 try {

 String x = null;

 System.out.print(x.toString() + "" "");

 }

 finally { System.out.print(""finally ""); }

 }

 public static void main(String[] args) {

 try { test(); }

 catch (Exception ex) { System.out.print(""exception ""); }

 }

What is the result?"	MCQ	null	Compilation fails.	finally exception	finally		0	0	1	0	

		Exception_handling_NewQB			"Given two programs:

1. package pkgA;

2. public class Abc {

3. int a = 5;

4. protected int b = 6;

5. public int c = 7;

6. }



3. package pkgB;

4. import pkgA.*;

5. public class Def {

6. public static void main(String[] args) {

7. Abc f = new Abc();

8. System.out.print("" "" + f.a);

9. System.out.print("" "" + f.b);

10. System.out.print("" "" + f.c);

11. }

12. }

What is the result when the second program is run? (Choose all that apply)"	MCA	5 6 7	5 followed by an exception	Compilation fails with an error on line 7	Compilation fails with an error on line 8	Compilation fails with an error on line 9	0	0	0	0.5	0.5

		Exception_handling_NewQB			"Consider the following code:



System.out.print(""Start "");

try 

{

  System.out.print(""Hello world"");

  throw new FileNotFoundException();

}

System.out.print("" Catch Here ""); /* Line 7 */

catch(EOFException e) 

{

  System.out.print(""End of file exception"");

}

catch(FileNotFoundException e) 

{

  System.out.print(""File not found"");

}



given that EOFException and FileNotFoundException are both subclasses of IOException. If this block of code is pasted in a method, choose the best option."	MCQ	The code will not compile.	Code output: Start Hello world File Not Found	Code output: Start Hello world End of file exception.	Code output: Start Hello world Catch Here File not found.		1	0	0	0	

		Exception_handling_NewQB			Which of the following statements is true?	MCQ	catch(X x) can catch subclasses of X where X is a subclass of Exception.	The Error class is a RuntimeException.	Any statement that can throw an Error must be enclosed in a try block.	Any statement that can throw an Exception must be enclosed in a try block.		1	0	0	0	

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

int array[] = new int[10];

array[-1] = 0;"	MCQ	compiles successfully	does not compile	runtime error	none of the listed options		0	0	1	0	

		Exception_handling_NewQB			"What will be the output of the program? 



public class RTExcept 

{

  public static void throwit () 

  {

    System.out.print(""throwit "");

    throw new RuntimeException();

  }

  public static void main(String [] args) 

  {

    try 

    {

      System.out.print(""hello "");

      throwit();

    }

    catch (Exception re ) 

    {

      System.out.print(""caught "");

    }

    finally 

    {

      System.out.print(""finally "");

    }

    System.out.println(""after "");

  }

}"	MCQ	hello throwit caught	Compilation fails	hello throwit RuntimeException caught after	hello throwit caught finally after		0	0	0	1	

		Exception_handling_NewQB			What is the keyword to use when the access of a method has to be restricted to only one thread at a time	MCQ	volatile	synchronized	final	private		0	1	0	0	

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

class Test{

 public static void parse(String str) {

  try {  int num = Integer.parseInt(str);

  } catch (NumberFormatException nfe) {

  num = 0;  } finally {  System.out.println(num);

  } } public static void main(String[] args) {

  parse(""one"");  }"	MCQ		NumberFormatException thrown at runtime	Compilation fails	ParseException thrown at runtime		0	0	1	0	

		Exception_handling_NewQB			"public static void parse(String str) {

try {

float f = Float.parseFloat(str);

} catch (NumberFormatException nfe) {

f = 0;

} finally {

System.out.println(f);

}

}

public static void main(String[] args) {

parse(""invalid"");

}"	MCQ		Compilation fails	A ParseException is thrown by the parse method at runtime.	A NumberFormatException is thrown by the parse method at runtime.		0	1	0	0	

		Exception_handling_NewQB			"Given the following program,which statements are true? (Choose TWO)

 Public class Exception {

 public static void main(String[] args) {

  try {

 if(args.length == 0) return;

System.out.println(args[0]);

}finally {

System.out.println(""The end"");

}}}"	MCA	If run with no arguments,the program will produce no output	"If run with no arguments,the program will produce ""The end"""	The program will throw an ArrayIndexOutOfBoundsException	If run with one arguments,the program will simply print the given argument	"If run with one arguments,the program will print the given argument followed by ""The end"""	0	0.5	0	0	0.5

		Exception_handling_NewQB			"Which can appropriately be thrown by a programmer using Java SE technology to create

a desktop application?"	MCQ	ClassCastException	NullPointerException	NoClassDefFoundError	NumberFormatException		0	0	0	1	

		Exception_handling_NewQB			Which of the following is a checked exception?	MCQ	Arithmetic Exception	IOException	NullPointerException	ArrayIndexOutOfBoundsException		0	1	0	0	

		Exception_handling_NewQB			"Given:

11. class A {

12. public void process() { System.out.print(""A,""); }

13. class B extends A {

14. public void process() throws IOException {

15. super.process();

16. System.out.print(""B,"");

17. throw new IOException();

18. }

19. public static void main(String[] args) {

20. try { new B().process(); }

21. catch (IOException e) { System.out.println(""Exception""); }

22. }

What is the result?"	MCQ	Exception	A,B,Exception	Compilation fails because of an error in line 20.	Compilation fails because of an error in line 14.		0	0	0	1	

		Exception_handling_NewQB			Which statement is true?	MCQ	The notifyAll() method must be called from a synchronized context	To call sleep(), a thread must own the lock on the object	The notify() method is defined in class java.lang.Thread	The notify() method causes a thread to immediately release its locks.		1	0	0	0	

		Exception_handling_NewQB			"class Trial{

public static void main(String[] args){

try{

System.out.println(""Try Block"");

} 

finally{

System.out.println(""Finally Block"");

}

} }"	MCQ	Try Block	Try Block Finally Block	Finally Block	Finally Block Try Block		0	1	0	0	

		Exception_handling_NewQB			"consider the code & choose the correct output:

class Threads2 implements Runnable {



 public void run() {

 System.out.println(""run."");

 throw new RuntimeException(""Problem"");

 }

 public static void main(String[] args) {

 Thread t = new Thread(new Threads2());

 t.start();

 System.out.println(""End of method."");

 }

 }"	MCQ	java.lang.RuntimeException: Problem	run java.lang.RuntimeException: Problem	End of method. java.lang.RuntimeException: Problem	End of method. run. java.lang.RuntimeException: Problem		0	0	0	1	

		Exception_handling_NewQB			The exceptions for which the compiler doesn�t enforce the handle or declare rule	MCQ	Checked exceptions	Unchecked exceptions	Exception	all of these		0	1	0	0	

		Exception_handling_NewQB			"Consider the code below & select the correct ouput from the options:

public class Test{

 Integer i;

 int x; 

 Test(int y){

 x=i+y;

 System.out.println(x);

 }

public static void main(String[] args) {

 new Test(new Integer(5));

}}"	MCQ	5	Compilation error	Compiles but error at run time			0	0	1	0	

		Exception_handling_NewQB			"Given:

 public class TestSeven extends Thread {

 private static int x;

 public synchronized void doThings() {

 int current = x;

 current++;

 x = current;

 }

 public void run() {

 doThings();

 }

}

Which statement is true?"	MCQ	Compilation fails.	Synchronizing the run() method would make the class thread-safe.	Declaring the doThings() method as static would make the class thread-safe.	An exception is thrown at runtime.		0	0	1	0	

		Exception_handling_NewQB			"Consider the following code and choose the correct option:

class Test{

 static void display(){

  throw new RuntimeException();

 } public static void main(String args[]){

   try{ display(); }catch(Exception e){

    throw new NullPointerException();}    

   finally{try{ display();     

    }catch(NullPointerException e){ System.out.println(""caught"");}

System.out.println(""exit"");}}}"	MCQ	caught exit	exit	Compilation fails	Compiles but exception at runtime		0	0	0	1	

		Garbage_Collection_NewQB			Which statements describe guaranteed behaviour of the garbage collection and finalization mechanisms? (Choose TWO)	MCA	An object is deleted as soon as there are no more references that denote the object	The finilize() method will eventually be called on every object	The finalize() method will never be called more than once on an object	An object will not be garbage collected as long as it possible for a live thread to access it through a reference.	The garbage collector will use a mark and sweep algorithm	0	0	0.5	0.5	0

		Garbage_Collection_NewQB			"Which statement is true?

A. A class's finalize() method CANNOT be invoked explicitly.

B. super.finalize() is called implicitly by any overriding finalize() method.

C. The finalize() method for a given object is called no more than once by the garbage collector.

D. The order in which finalize() is called on two objects is based on the order in which the two

objects became finalizable."	MCQ	A	B	C	D		0	0	1	0	

		Garbage_Collection_NewQB			Which of the following allows a programmer to destroy an object x?	MCQ	x.delete()	x.finalize()	Runtime.getRuntime().gc()	Only the garbage collection system can destroy an object.		0	0	0	1	

		Garbage_Collection_NewQB			"class X2 

{

  public X2 x;

  public static void main(String [] args) 

  {

    X2 x2 = new X2(); /* Line 6 */

    X2 x3 = new X2(); /* Line 7 */

    x2.x = x3;

    x3.x = x2;

    x2 = new X2();

    x3 = x2; /* Line 11 */    

  }

}



after line 11 runs, how many objects are eligible for garbage collection?"	MCQ		1	2	3		0	0	1	0	

		Garbage_Collection_NewQB			"Given :

public class MainOne {

  public static void main(String args[]) {

   String str = ""this is java"";

   System.out.println(removeChar(str,'s'));

  }



  public static String removeChar(String s, char c) {

   String r = """";

   for (int i = 0; i < s.length(); i++) {

    if (s.charAt(i) != c)

     r += s.charAt(i);

   }

   return r;

  }

 } What would be the result?"	MCQ	This is java	Thi is java	This i java	Thi i java	none of the listed options	0	0	0	1	0

		Garbage_Collection_NewQB			How can you force garbage collection of an object?	MCQ	Set all references to the object to new values(null, for example).	Call System.gc() passing in a reference to the object to be garbage collected	Call System.gc()	Call Runtime.gc().	Garbage collection cannot be forced	0	0	0	0	1

		Garbage_Collection_NewQB			"Consider the following code and choose the correct option:

public class X 

{

  public static void main(String [] args) 

  {

    X x = new X();

    X x2 = m1(x); /* Line 6 */

    X x4 = new X();

    x2 = x4; /* Line 8 */

    doComplexStuff();  }

  static X m1(X mx)   {

    mx = new X();

    return mx;  }}

After line 8 runs. how many objects are eligible for garbage collection?"	MCQ		1	2	3		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"interface interface_1 {

 void f1();

}

class Class_1 implements interface_1 {

 void f1() {

 System.out.println(""From F1 funtion in Class_1 Class"");

 }

}

public class Demo1 {

 public static void main(String args[]) {

 Class_1 o11 = new Class_1();

 o11.f1();

 }

}"	MCQ	From F1 function in Class_1 Class	Compile time error	Create an object for Interface only	Runtime Error		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

class A {

   final void meth() {

   System.out.println(""This is a final method."");

  }

 }

  class B extends A {

  void meth() {

   System.out.println(""Illegal!"");

  }

 }

 class MyClass8{

  public static void main(String[] args) {

  A a = new A();

  a.meth();

  B b= new B();

  b.meth();

  }

 }What would be the result?"	MCQ	This is a final method illegal	This is a final method Some error message	Compilation error	illegal Some error message		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Which Man class properly represents the relationship ""Man has a best friend who is a Dog""?

A)class Man extends Dog { }

B)class Man implements Dog { }

C)class Man { private BestFriend dog; }

D)class Man { private Dog bestFriend; }"	MCQ	A	B	C	D		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"What will be the output of the program? 



class SuperClass 

{ 

  public Integer getLength() 

  {

    return new Integer(4); 

  } 

} 



public class SubClass extends SuperClass 

{ 

  public Long getLength() 

  {

    return new Long(5); 

  } 



  public static void main(String[] args) 

  { 

    SuperClass sp = new SuperClass(); 

    SubClass sb = new SubClass(); 

    System.out.println( 

    sp.getLength().toString() + "","" + sub.getLength().toString() ); 

  } 

}"	MCQ	4, 4	4, 5	5, 4	Compilation fails		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the code below & select the correct ouput from the options:

abstract class Ab{ public int getN(){return 0;}}

class Bc extends Ab{ public int getN(){return 7;}}

class Cd extends Bc { public int getN(){return 47;}}

class Test{

 public static void main(String[] args) {

 Cd cd=new Cd();

 Bc bc=new Cd();

 Ab ab=new Cd();

 System.out.println(cd.getN()+"" ""+

  bc.getN()+"" ""+ab.getN()); }}"	MCQ	0 0 0	47 7 0	Compilation error	47 47 47		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"interface A{}

class B implements A{}

class C extends B{}

public class Test extends C{

public static void main(String[] args) {

 C c=new C();

 /* Line6 */}}



Which code, inserted at line 6, will cause a java.lang.ClassCastException?"	MCQ	B b=c;	A a2=(B)c;	C c2=(C)(B)c;	A a1=(Test)c;		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given :

What would be the result of compiling and running the following program?

// Filename: MyClass.java

public class MyClass {

public static void main(String[] args) {

C c = new C();

System.out.println(c.max(13, 29));

}

}

class A {

int max(int x, int y) { if (x>y) return x; else return y; }

}

class B extends A{

int max(int x, int y) { return super.max(y, x) - 10; }

}

class C extends B {

int max(int x, int y) { return super.max(x+10, y+10); }

}"	MCQ	The code will fail to compile because the max() method in B passes the arguments in the call super.max(y, x) in the wrong order.	The code will fail to compile because a call to a max() method is ambiguous.	The code will compile and print 23, when run.	The code will compile and print 29, when run.		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"The concept of multiple inheritance is implemented in Java by



(A) extending two or more classes

(B) extending one class and implementing one or more interfaces

(C) implementing two or more interfaces

(D) all of these"	MCQ	(A)	(A) & (C)	(D)	(B) & (C)		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

interface DoMath 

{

  double getArea(int r); 

}

interface MathPlus 

{

  double getVolume(int b, int h); 

}

/* Missing Statements ? */

Select the correct missing statements."	MCQ	class AllMath extends DoMath { double getArea(int r); }	interface AllMath implements MathPlus { double getVol(int x, int y); }	abstract class AllMath implements DoMath, MathPlus { public double getArea(int rad) { return rad * rad * 3.14; } }	class AllMath implements MathPlus { double getArea(int rad); }		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

class A{

 void display(byte a, byte b){

 System.out.println(""sum of byte""+(a+b)); }

 void display(int a, int b){

 System.out.println(""sum of int""+(a+b)); }

 public static void main(String[] args) {

 new A().display(3, 4); }}"	MCQ	sum of byte 7	Compilation error	sum of int7	Compiles but error at runtime		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface Output{

 void display();

 void show();

}

class Screen implements Output{ 

 void display(){ System.out.println(""display""); }public static void main(String[] args) {

 new Screen().display();}}"	MCQ	display	Compilation error	Compiles but error at run time	Runs but no output		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"class Animal {

void makeNoise() {System.out.println(""generic noise""); }

}

class Dog extends Animal {

void makeNoise() {System.out.println(""bark""); }

void playDead() { System.out.println(""roll over""); }

}

class CastTest2 {

public static void main(String [] args) {

Dog a = (Dog) new Animal();

a.makeNoise();

}

}

consider the code above & select the proper output from the options."	MCQ	run time error	generic noise	bark	compile error		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface employee{

 void saldetails();

 void perdetails();

}

abstract class perEmp implements employee{

 public void perdetails(){

 System.out.println(""per details""); }}

 class Programmer extends perEmp{

 public void saldetails(){

 perdetails();

 System.out.println(""sal details""); }

 public static void main(String[] args) {

 perEmp emp=new Programmer();

 emp.saldetails(); }}"	MCQ	sal details	sal details per details	compilation error	per details sal details		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the code below & select the correct ouput from the options:

class A{

 static int sq(int n){

 return n*n; }}

public class Test extends A{

 static int sq(int n){

 return super.sq(n); }

 public static void main(String[] args) {

 System.out.println(new Test().sq(3)); }}"	MCQ	3	Compilation error	Compiles but error at run time	9		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

public static void main( String[] args ) { SomeInterface x; ... } 

Can an interface name be used as the type of a variable"	MCQ	No�a variable must always be an object reference type	No�a variable must always be an object reference type or a primitive type	No�a variable must always be a primitive type	Yes�the variable can refer to any object whose class implements the interface		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface A{

 int i=3;} 

interface B{

 int i=4;}

class Test implements A,B{

 public static void main(String[] args) {

 System.out.println(i);

 }

}"	MCQ	3	4	compilation error	Compiles but error at runtime		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given the following classes and declarations, which statements are true?

// Classes

class A {

private int i;

public void f() { /* ... */ }

public void g() { /* ... */ }

}

class B extends A{

public int j;

public void g() { /* ... */ }

}

// Declarations:

A a = new A();

B b = new B();

Select the three correct answers."	MCA	The B class is a subclass of A.	The statement b.f(); is legal	The statement a.j = 5; is legal.	The statement a.g(); is legal	The statement b.i = 3; is legal.	0.333333	0.333333	0	0.333333	0

		Inheritance_Interfaces_Abstract Classes_NewQB			"Which declaration can be inserted at (1) without causing a compilation error?

interface MyConstants {

int r = 42;

int s = 69;

// (1) INSERT CODE HERE

}"	MCA	int total = total + r + s;	final double circumference = 2 * Math.PI * r;	protected int CODE = 31337;	int AREA = r * s;	public static MAIN = 15;	0	0.5	0	0.5	0

		Inheritance_Interfaces_Abstract Classes_NewQB			"What is the output for the following code:

abstract class One{

private abstract void test();

}

class Two extends One{

void test(){

System.out.println(""hello"");

}}

class Test{

public static void main(String[] args){

Two obj = new Two();

obj.test();

}

}"	MCQ	run time exception	compile time error	hello	hellohello		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the code below & select the correct ouput from the options:



class Money {

private String country = ""Canada"";

 public String getC() { return country; } }

 class Yen extends Money {

 public String getC() { return super.country; } 

 public static void main(String[] args) {

 System.out.print(new Yen().getC() ); } }"	MCQ	Canada	Compilation error	Compiles but error at run time	null		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			When we use both implements & extends keywords in a single java program then what is the order of keywords to follow?	MCQ	we must use always extends and later we must use implements keyword.	we must use always implements and later we must use extends keyword.	we can use in any order its not at all a problem	extends and implements can't be used together		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the code below & select the correct ouput from the options:

1. public class Mountain {

2. protected int height(int x) { return 0; }

3. }

4. class Alps extends Mountain {

5. // insert code here

6. }

Which five methods, inserted independently at line 5, will compile? (Choose three.)

A. public int height(int x) { return 0; }

B. private int height(int x) { return 0; }

C. private int height(long x) { return 0; }

D. protected long height(long x) { return 0; }

E. protected long height(int x) { return 0; }"	MCQ	A,B,E	A,C,D	B,D,E	C,D,E		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

 interface DeclareStuff {

 public static final int Easy = 3;

void doStuff(int t); }

public class TestDeclare implements DeclareStuff {

 public static void main(String [] args) {

int x = 5;

 new TestDeclare().doStuff(++x);

}

 void doStuff(int s) {

 s += Easy + ++s;

System.out.println(""s "" + s);

 }

} What is the result?"	MCQ	s 14	s 16	s 10	Compilation fails.		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

interface A { public void methodA(); }

interface B { public void methodB(); }

interface C extends A,B{ public void methodC(); } //Line 3

class D implements B {

public void methodB() { } //Line 5

}

class E extends D implements C { //Line 7

public void methodA() { }

public void methodB() { } //Line 9

public void methodC() { }

}

What would be the result?"	MCQ	Compilation fails, due to an error in line 3	If you define D e = (D) (new E()), then e.methodB() invokes the version of methodB() defined at line 9	Compilation fails, due to an error in line 7	If you define D e = (D) (new E()), then e.methodB() invokes the version of methodB() defined at line 5		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Which of the following statements is true regarding the super() method?	MCQ	It can only be used in the parent's constructor	Only one child class can use it	It must be used in the last statement of the constructor.	It must be used in the first statement of the constructor.		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface Output{

 void display();

 void show();

}

class Screen implements Output{

 void show() {System.out.println(""show"");}

 void display(){ System.out.println(""display""); }public static void main(String[] args) {

 new Screen().display();}}"	MCQ	display	Compilation error	Compiles but error at run time	Runs but no output		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

class A{

 void display(){ System.out.println(""Hello A""); }}

class B extends A{

 void display(){

 System.out.println(""Hello B""); }}

public class Test {

 public static void main(String[] args) {  

 B b=(B) new A();

 b.display(); }}"	MCQ	Hello A	Compilation error	Hello B	Compiles but error at runtime		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code: 

// Class declarations:

class Super {}

class Sub extends Super {}

// Reference declarations:

Super x;

Sub y;

Which of the following statements is correct for the code: y = (Sub) x?"	MCQ	Illegal at compile time	Legal at compile time, but might be illegal at runtime	Definitely legal at runtime, but the cast operator (Sub) is not strictly needed.	Definitely legal at runtime, and the cast operator (Sub) is needed.		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

11. class ClassA {}

12. class ClassB extends ClassA {}

13. class ClassC extends ClassA {}

and:

21. ClassA p0 = new ClassA();

22. ClassB p1 = new ClassB();

23. ClassC p2 = new ClassC();

24. ClassA p3 = new ClassB();

25. ClassA p4 = new ClassC();

Which TWO are valid? (Choose two.)"	MCA	p0 = p1;	p2 = p4;	p1 = (ClassB)p3;	p1 = p2;		0.5	0	0.5	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

abstract class Car{

 abstract void accelerate(); 

}

class Lamborghini extends Car{

 @Override

 void accelerate() {

 System.out.println(""90 mph"");  }

 void nitroBooster(){

 System.out.print(""150 mph""); }

 public static void main(String[] args) {

 Car mycar=new Lamborghini();

 Lamborghini lambo=(Lamborghini) mycar;

 lambo.nitroBooster();}}"	MCQ	150 mph	Compilation error	90 mph	Compiles but error at runtime		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

class A{

 void display(){ System.out.println(""Hello A""); }}

class B extends A{

 void display(){

 System.out.println(""Hello B""); }}

public class Test {

 public static void main(String[] args) {

 A a=new B();

 B b= (B)a;

 b.display(); }}"	MCQ	Hello A	Compilation error	Hello B	Compiles but error at runtime		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			A class Animal has a subclass Mammal. Which of the following is true:	MCQ	Because of single inheritance, Mammal can have no subclasses	Because of single inheritance, Mammal can have no other parent than Animal	Because of single inheritance, Animal can have only one subclass	Because of single inheritance, Mammal can have no siblings.		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"class Animal {

void makeNoise() {System.out.println(""generic noise""); }

}

class Dog extends Animal {

void makeNoise() {System.out.println(""bark""); }

void playDead() { System.out.println(""roll over""); }

}

class CastTest2 {

public static void main(String [] args) {

Animal a = new Dog();

a.makeNoise();

}

}

consider the code above & select the proper output from the options."	MCQ	run time error	generic noise	bark	compile error		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"What will be the result when you try to compile and run the following code? 

class Base1 {

 Base1() {

 int i = 100;

 System.out.println(i);

 }

}



public class Pri1 extends Base1 {

 static int i = 200;



 public static void main(String argv[]) {

 Pri1 p = new Pri1();

 System.out.println(i);

 }

}"	MCQ	Error at compile time	200	100 followed by 200	100		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"What is the output :

interface A{

void method1();

void method2();

}

class Test implements A{

public void method1(){

System.out.println(""hello"");}}

class RunTest{

public static void main(String[] args){

Test obj = new Test();

obj.method1();

}}"	MCQ	hello	compile error	runtime error	none		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given the following classes and declarations, which statements are true?

// Classes

class Foo {

private int i;

public void f() { /* ... */ }

public void g() { /* ... */ }

}

class Bar extends Foo {

public int j;

public void g() { /* ... */ }

}

// Declarations:

Foo a = new Foo();

Bar b = new Bar();"	MCA	The Bar class is a subclass of Foo.	The statement a.j = 5; is legal.	The statement b.f(); is legal.	The statement a.g(); is legal.		0.333333	0	0.333333	0.333333	

		Inheritance_Interfaces_Abstract Classes_NewQB			Given a derived class method which overrides one of it�s base class methods. With derived class object you can invoke the overridden base method using:	MCQ	super keyword	this keyword	by creating an instance of the base class	cannot call because it is overridden in derived class		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

abstract class Car{

 abstract void accelerate(); 

}class Lamborghini extends Car{

 @Override

 void accelerate() {

 System.out.println(""90 mph"");  

 } void nitroBooster(){

 System.out.print(""150 mph""); } 

 public static void main(String[] args) {

 Car mycar=new Lamborghini();

 mycar.nitroBooster(); }}"	MCQ	Compilation error	Compiles but error at run time	90 mph	150 mph		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given:

 class Pizza {

 java.util.ArrayList toppings;

 public final void addTopping(String topping) {

 toppings.add(topping);

 }

 }

 public class PepperoniPizza extends Pizza {

 public void addTopping(String topping) {

 System.out.println(""Cannot add Toppings"");

 }

 public static void main(String[] args) {

 Pizza pizza = new PepperoniPizza();

 pizza.addTopping(""Mushrooms"");

 }

 }

What is the result?"	MCQ	Compilation fails.	Cannot add Toppings	The code runs with no output.	A NullPointerException is thrown		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface console{ 

 int line=10;

 void print();}

class a implements console{

  void print(){

 System.out.print(""A"");}

 public static void main(String ar[]){

 new a().print();}}"	MCQ	A	Compilation error	Compiles but error at run time	Runs but no output		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Which of these field declarations are legal in an interface? (Choose all applicable)	MCA	public int answer = 42;	final static int answer = 42;	private final static int answer = 42;	int answer;	public static int answer = 42;	0.25	0.25	0.25	0	0.25

		Inheritance_Interfaces_Abstract Classes_NewQB			"Given :  



Day d;

BirthDay bd = new BirthDay(""Raj"", 25);

d = bd;  // Line X



Where Birthday is a subclass of Day. State whether the code given at Line X is correct:"	MCQ	No�there must always be an exact match between the variable and the object	No�but a object of parent type can be assigned to a variable of child type.	Yes�an object can be assigned to a reference variable of the parent type.	Yes�any object can be assigned to any reference variable.		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Select the correct statement:	MCQ	A super() or this() call must always be provided explicitly as the first statement in the body of a constructor.	If both a subclass and its superclass do not have any declared constructors, the implicit default constructor of the subclass will call super() when run	If neither super() nor this() is declared as the first statement in the body of a constructor, this() will implicitly be inserted as the first statement.	If super() is the first statement in the body of a constructor, this() can be declared as the second statement	Calling super() as the first statement in the body of a constructor of a subclass will always work, since all superclasses have a default constructor.	0	1	0	0	0

		Inheritance_Interfaces_Abstract Classes_NewQB			Choose the correct declaration of variable in an interface:	MCQ	public final data type varaibale=intialization;	static data type variable;	static final data type varaiblename;	final data type variablename=intialization;		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

abstract class Fun{

 void time(){

 System.out.println(""Fun Time""); }}

class Run extends Fun{

 void time(){

 System.out.println(""Fun Run""); }

 public static void main(String[] args) {

 Fun f1=new Run();

 f1.time(); }}"	MCQ	Fun Time	Compilation error	Fun Run	Compiles but error at runtime		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"interface Vehicle{

void drive();

}

final class TwoWheeler implements Vehicle{

int wheels = 2;

public void drive(){

System.out.println(""Bicycle"");

}

}

class ThreeWheeler extends TwoWheeler{

public void drive(){

System.out.println(""Auto"");

}}

class Test{

public static void main(String[] args){

ThreeWheeler obj = new ThreeWheeler();

obj.drive();

}}

consider the code above & select the proper output from the options."	MCQ	Auto	Bicycle Auto	compile error	runtime error		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface employee{

 void saldetails();

 void perdetails();

}

abstract class perEmp implements employee{

 public void perdetails(){

 System.out.println(""per details""); }}

 class Programmer extends perEmp{ 

 public static void main(String[] args) {

 perEmp emp=new Programmer();

 emp.saldetails(); }}"	MCQ	sal details	sal details per details	compilation error	per details sal details		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			All data members in an interface are by default	MCQ	abstract and final	public and abstract	public ,static and final	default and abstract		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

interface console{ 

 int line;

 void print();}

class a implements console{

  public void print(){

 System.out.print(""A"");}

 public static void main(String ar[]){

 new a().print();}}"	MCQ	A	Compilation error	Compiles but error at run time	Runs but no output		0	1	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Which of the following is correct for an abstract class. (Choose TWO)	MCA	An abstract class is one which contains general purpose methods	An abstract class is one which contains some defined methods and some undefined methods	An abstract class is one which contains only static methods	Abstract class can be declared final		0.5	0.5	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Which of the following defines a legal abstract class?	MCQ	class Vehicle { abstract void display(); }	abstract Vehicle { abstract void display(); }	class abstract Vehicle { abstract void display(); }	"abstract class Vehicle { abstract void display(); { System.out.println(""Car""); }}"	abstract class Vehicle { abstract void display(); }	0	0	0	0	1

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the code below & select the correct ouput from the options:



class Mountain{

 int height;

 protected Mountain(int x) { height=x; }

 public int getH(){return height;}}



class Alps extends Mountain{

 public Alps(int h){ super(h); } 

 public Alps(){ this(100); }

 public static void main(String[] args) {

 System.out.println(new Alps().getH());

 }

}"	MCQ	100	Compilation error	Compiles but error at run time	Compiles but no output		1	0	0	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the given code and select the correct output: 



class SomeException {

}



class A {

public void doSomething() { }

}



class B extends A {

public void doSomething() throws SomeException { }

}"	MCQ	Compilation of both classes A & B will fail	Compilation of both classes will succeed	Compilation of class A will fail. Compilation of class B will succeed	Compilation of class B will fail. Compilation of class A will succeed		0	0	0	1	

		Inheritance_Interfaces_Abstract Classes_NewQB			Is it possible if a class definition implements two interfaces, each of which has the same definition for the constant?	MCQ	No�if a class implements several interfaces, each constant must be defined in only one interface	No�a class may not implement more than one interface	Yes� either of the two variables can be accessed through : interfaceName.variableName	Yes�since the definitions are the same it will not matter		0	0	1	0	

		Inheritance_Interfaces_Abstract Classes_NewQB			Select the correct statement:	MCQ	Private methods cannot be overridden in subclasses	A subclass can override any method in a superclass	An overriding method can declare that it throws checked exceptions that are not thrown by the method it is overriding	The parameter list of an overriding method can be a subset of the parameter list of the method that it is overriding	The overriding method must have different return type as the overridden method	1	0	0	0	0

		Inheritance_Interfaces_Abstract Classes_NewQB			"Consider the following code and choose the correct option:

class A{

 void display(){ System.out.println(""Hello A""); }}

class B extends A{

 void display(){

 System.out.println(""Hello B""); }}

public class Test {

 public static void main(String[] args) {

 A a=new B();

 B b= a;

 b.display(); }}"	MCQ	Hello A	Compilation error	Hello B	Compiles but error at runtime		0	1	0	0	

		Introduction_to_Java_and_SDE_NewQB			Which of the following option gives one possible use of the statement 'the name of the public class should match with its file name'?	MCQ	To maintain the uniform standard	Helps the compiler to find the source file that corresponds to a class, when it does not find a class file while compiling	Helps JVM to find and execute the classes	Helps Javadoc to build the Java Documentation easily		0	1	0	0	

		Introduction_to_Java_and_SDE_NewQB			Which of the following statement gives the use of CLASSPATH?	MCQ	Holds the location of Core Java Class Library (Bootstrap classes)	Holds the location of Java Extension Library	Holds the location of User Defined classes, packages and JARs	Holds the location of Java Software		0	0	1	0	

		Introduction_to_Java_and_SDE_NewQB			Which of the following are true about packages? (Choose 2)	MCA	Packages can contain only Java Source files	Packages can contain both Classes and Interfaces (Compiled Classes)	Packages can contain non-java elements such as images, xml files etc.	Sub packages should be declared as private in order to deny importing them	Class and Interfaces in the sub packages will be automatically available to the outer packages without using import statement.	0	0.5	0.5	0	0

		Introduction_to_Java_and_SDE_NewQB			Which of the following options give the valid argument types for main() method? (Choose 2)	MCA	String [][]args	String args	String[] args[]	String[] args	String args[]	0	0	0	0.5	0.5

		Introduction_to_Java_and_SDE_NewQB			Which of the following options give the valid package names? (Choose 3)	MCA	dollorpack.$pack.$$pack	$$.$$.$$	_score.pack.__pack	p@ckage.subp@ckage.innerp@ckage	.package.subpackage.innerpackage	0.333333	0.333333	0.333333	0	0

		Introduction_to_Java_and_SDE_NewQB			Which of the following statements are true regarding java.lang.Object class? (Choose 2)	MCA	Object class is an abstract class	Object class cannot be instantiated directly	Object class has the core methods for thread synchronization	Object class provides the method for Set implementation in Collection framework	Object class implements Serializable interface internally	0	0	0.5	0.5	0

		Introduction_to_Java_and_SDE_NewQB			The term 'Java Platform' refers to ________________.	MCQ	Java Compiler (Javac)	Java Runtime Environment (JRE)	Java Database Connectivity (JDBC)	Java Debugger		0	1	0	0	

		JDBC_NewQB			Which of the following methods are needed for loading a database driver in JDBC?	MCQ	registerDriver() method	Class.forName()	registerDriver() method and Class.forName()	getConnection		0	0	1	0	

		JDBC_NewQB			how to register driver class in the memory?	MCQ	Using forName() which is a static method	Using the static method registerDriver() method which is available in DriverManager Class.	Either forName() or registerDriver()	None of the given options		0	0	1	0	

		JDBC_NewQB			"Give Code snipet:

{// Somecode

ResultSet rs = st.executeQuery(""SELECT * FROM survey"");



  while (rs.next()) {

   String name = rs.getString(""name"");

   System.out.println(name);

  }



  rs.close();

// somecode

} What should be imported related to ResultSet?"	MCQ	java.sql.ResultSet	java.sql.Driver	java.sql.DriverManager	java.sql.Connection		1	0	0	0	

		JDBC_NewQB			"Consider the following code & select the correct option for output.

String sql =""select empno,ename from emp"";  

 PreparedStatement pst=cn.prepareStatement(sql);

  System.out.println(pst.toString());

 ResultSet rs=pst.executeQuery();

  System.out.println(rs.getString(1)+ "" ""+rs.getString(2));"	MCQ	will show first employee record	Compilation error	Compiles but error at run time	Compiles but no output		0	0	1	0	

		JDBC_NewQB			Which of the following methods finds the maximum number of connections that a specific driver can obtain?	MCQ	Connection.getMaxConnections	ResultSetMetaData.getMaxConnections	DatabaseMetaData.getMaxConnections	Database.getMaxConnections		0	0	1	0	

		JDBC_NewQB			By default all JDBC transactions are autocommit. State TRUE/FALSE.	MCQ	true	false				1	0			

		JDBC_NewQB			getConnection() is method available in?	MCQ	DriverManager Class	Driver Interface	ResultSet Interface	Statement Interface	PreparedStatement Interface	1	0	0	0	0

		JDBC_NewQB			"A) By default, all JDBC transactions are auto commit

B) PreparedStatement suitable for dynamic sql and requires one time compilation

C) with JDBC it is possible to fetch information about the database"	MCQ	Only A and B is TRUE	Only B and C is True	Both A and C is TRUE	All are TRUE		0	0	0	1	

		JDBC_NewQB			What is the use of wasNull() in ResultSet interface?	MCQ	There is no such method in ResultSet interface	It returns true when last read column contain SQL NULL else returns false	It returns int value as mentioned below: > 0 if many columns Contain Null Value < 0 if no column contains Null Value = 0 if one column contains Null value	none of the listed options		0	1	0	0	

		JDBC_NewQB			"Given :

public class MoreEndings {

 public static void main(String[] args) throws Exception {

  Class driverClass = Class.forName(""sun.jdbc.odbc.JdbcOdbcDriver"");

DriverManager.registerDriver((Driver) driverClass.newInstance());

// Some code

} Inorder to compile & execute this code, what should we import?"	MCQ	java.sql.Driver	java.sql.Driver	java.sql.Driver java.sql.DriverManager	java.sql.DataSource		0	0	1	0	

		JDBC_NewQB			Which of the following method can be used to execute to execute all type of queries i.e. either Selection or Updation SQL Queries?	MCQ	executeAll()	executeAllSQL()	execute()	executeQuery()	executeUpdate()	0	0	1	0	0

		JDBC_NewQB			Which method will return boolean when we try to execute SQL Query from a JDBC program?	MCQ	executeUpdate()	executeSQL()	execute()	executeQuery()		0	0	1	0	

		JDBC_NewQB			"Cosider the following code & select the correct output.

String sql =""select rollno, name from student""; 

 PreparedStatement pst=cn.prepareStatement(sql);

 System.out.println(pst.toString());

 ResultSet rs=pst.executeQuery();

  while(rs.next()){

  System.out.println(rs.getString(3)); }"	MCQ	will show only name	Compilation error	will show city	Compiles but error at run time		0	0	0	1	

		JDBC_NewQB			It is possible to insert/update record in a table by using ResultSet. State TRUE/FALSE	MCQ	true	false				1	0			

		JDBC_NewQB			What is the default type of ResultSet in JDBC applications?	MCQ	Read Only, Forward Only	Updatable, Forward only	Read only, Scroll Sensitive	Updatable, Scroll sensitive		1	0	0	0	

		JDBC_NewQB			An application can connect to different Databases at the same time. State TRUE/FALSE.	MCQ	true	false				1	0			

		JDBC_NewQB			"A) It is not possible to execute select query with execute() method

B) CallableStatement can executes store procedures only but not functions"	MCQ	Both A and B is FALSE	Only A is TRUE	Only B is TRUE	Both A and B is TRUE		1	0	0	0	

		JDBC_NewQB			"A) When one use callablestatement, in that case only parameters are send over network not sql query. 

B) In preparestatement sql query will compile for first time only"	MCQ	Both A and B is FALSE	Both A and B is TRUE	Only A is TRUE	Only B is TRUE		0	1	0	0	

		JDBC_NewQB			"Consider the code below & select the correct ouput from the options:



String sql =""select * from ?"";

 String table="" txyz "";

 PreparedStatement pst=cn.prepareStatement(sql);

 pst.setString(1,table );

 ResultSet rs=pst.executeQuery();

  while(rs.next()){

  System.out.println(rs.getString(1)); }"	MCQ	will show all row of first column	Compilation error	Compiles but error at run time	Compiles but run without output		0	0	1	0	

		JDBC_NewQB			Sylvy wants to develop Student management system, which requires frequent insert operation about student details. In order to insert student record which statement interface will give good performance	MCQ	Statement	CallableStatement	PreparedStatement	RowSet		0	0	1	0	

		JDBC_NewQB			"class CreateFile{

public static void main(String[] args) {

try {

File directory = new File(""c""); //Line 13

File file = new File(directory,""myFile"");

if(!file.exists()) {

file.createNewFile(); //Line 16

}}

catch(IOException e) {

e.printStackTrace }

}}}

If the current direcory does not consists of directory ""c"", Which statements are true ? (Choose TWO)"	MCA	Line 16 is never executed	An exception is thrown at runtime	Line 13 creates a File object named �c�	Line 13 creates a directory named �c� in the file system.		0	0.5	0.5	0	

		JDBC_NewQB			Which of the following options contains only JDBC interfaces?	MCQ	1) Driver 2) Connection 3) ResultSet 4) DriverManager 5) Class	1) Driver 2) Connection 3) ResultSet 4) ResultSetMetaData 5) Statement 6) DriverManager 7) PreparedStatement 8) Callablestatement 9) DataBaseMetaData	1) Driver 2) Connection 3) ResultSet 4) ResultSetMetaData 5) Statement 6) PreparedStatement 7) Callablestatement 8) DataBaseMetaData	All of the given options		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:



 public class Test {

 public static void main(String [] args) {

 int x = 5;

 boolean b1 = true;

 boolean b2 = false;

 if ((x == 4) && !b2 )

 System.out.print(""1 "");

 System.out.print(""2 "");

 if ((b2 = true) && b1 )

 System.out.print(""3 ""); }"	MCQ	2 3	1 3	2	3		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			Which three are legal array declarations? (Choose THREE)	MCA	int [] myScores [];	char [] myChars;	int [6] myScores;	Dog myDogs [];	Dog myDogs [7];	0.333333	0.333333	0	0.333333	0

		Keywords_variables_operators_datatypes_NewQB			"Consider the given code and select the correct output:

class Test{  

 public static void main(String[] args){

 int num1 = 012;

 int num2 = 0x110;

 int sum =num1+=num2;  

 System.out.println(""Ans = ""+sum); }}"	MCQ	26	282	Compiles but error at run time	Compilation error		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Say that class Rodent has a child class Rat and another child class Mouse. Class Mouse has a child class PocketMouse. Examine the following 



Rodent rod;

Rat rat = new Rat();

Mouse mos = new Mouse();

PocketMouse pkt = new PocketMouse();



Which one of the following will cause a compiler error?"	MCQ	rod = mos	pkt = rat	pkt = null	rod = rat		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:

class Test{

 public static void main(String[] args) {

 parse(""Four""); } 

 static void parse(String s){

 try {

  double d=Double.parseDouble(s);

 }catch(NumberFormatException nfe){

  d=0.0; }finally{

  System.out.println(d); } }}"	MCQ		Compilation error	A ParseException is thrown by the parse method at runtime	A NumberFormatException is thrown by the parse method at runtime		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:

class A{

 public int a=7; 

 public void add(){

 this.a+=2; System.out.print(""a""); }}



public class Test extends A{

 public int a=2;

 public void add(){

 this.a+=2; System.out.print(""t""); }

 public static void main(String[] args) {

 A a =new Test();

 a.add();

 System.out.print(a.a); }}"	MCQ	t 7	t 9	a 9	Compilation error		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"What will be the output of the program? 



public class CommandArgsTwo 

{

  public static void main(String [] argh) 

  {

    int x;

    x = argh.length;

    for (int y = 1; y <= x; y++) 

    {

      System.out.print("" "" + argh[y]);

    }

  }

}



and the command-line invocation is 



> java CommandArgsTwo 1 2 3"	MCQ	0 1 2	2 3	0 0 0	An exception is thrown at runtime		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"What will be the result of the following program?

public class Init {

String title;

boolean published;

static int total;

static double maxPrice;

public static void main(String[] args) {

Init initMe = new Init();

double price;

if (true)

price = 100.00;

System.out.println(""|"" + initMe.title + ""|"" + initMe.published + ""|"" +

Init.total + ""|"" + Init.maxPrice + ""|"" + price+ ""|"");

}

}"	MCQ	The program will compile, and print |null|false|0|0.0|0.0|, when run	The program will compile, and print |null|true|0|0.0|100.0|, when run	The program will compile, and print | |false|0|0.0|0.0|, when run	The program will compile, and print |null|false|0|0.0|100.0|, when run	Compilation error	0	0	0	1	0

		Keywords_variables_operators_datatypes_NewQB			"Here is the general syntax for method definition: 



accessModifier returnType methodName( parameterList )

{

 Java statements



 return returnValue;

}





What is true for the returnType and the returnValue?"	MCQ	The returnValue must be exactly the same type as the returnType	The returnValue can be any type, but will be automatically converted to returnType when the method returns to the caller.	If the returnType is void then the returnValue can be any type	The returnValue must be the same type as the returnType, or be of a type that can be converted to returnType without loss of information.		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct option:

class Test{ 

 class A{ static int x=3; } 

 static void display(){

 System.out.println(A.x); }

 public static void main(String[] args) {

 display(); }}"	MCQ	3	Compilation error	Compiles but error at run time			0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Which of the following lines of code will compile without warning or error? 

1) float f=1.3; 

2) char c=""a""; 

3) byte b=257; 

4) boolean b=null; 

5) int i=10;"	MCQ	Line 3	Line 1, Line 3, Line 5	Line 1, Line 5	Line 4	Line 5	0	0	0	0	1

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct option: 

class Test{  

 interface Y{

 void display(); } 

 public static void main(String[] args) {

 new Y(){

  public void display(){

  System.out.println(""Hello World""); }

 }.display(); }}"	MCQ	Hello World	Compilation error	Compiles but error at run time	Compiles but run without output		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct option:

class Test{ 

 static class A{  

  interface X{

  int z=4;  } } 

 static void display(){

 System.out.println(A.X.z); }

 public static void main(String[] args) {

 display(); }}"	MCQ	4	Compilation error	Compiles but error at run time			1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"What is the output of the following program?

public class MyClass

{

public static void main( String[] args )

{

private static final int value =9;

float total;

total = value + value / 2;

System.out.println( total );

}

}"	MCQ	13	13.5	13	Compilation Error	Runtime Error	0	0	0	1	0

		Keywords_variables_operators_datatypes_NewQB			"Which of the given options is similar to the following code: 



value += sum++ ;"	MCQ	value = value + sum; sum = sum + 1;	sum = sum + 1; value = value + sum;	value = value + sum;	value = value + ++sum;		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"What will happen if you attempt to compile and run the following code? 

Integer ten=new Integer(10);

Long nine=new Long (9);

System.out.println(ten + nine);

int i=1;

System.out.println(i + ten);"	MCQ	19 followed by 11	19 follwed by 20	Compile time error	10 followed by 1		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Identify the statements that are correct:

(A) int a = 13, a>>2 = 3

(B) int b = -8, b>>1 = -4

(C) int a = 13, a>>>2 = 3

(D) int b = -8, b>>>1 = -4"	MCQ	(A), (B) & (C)	(A), (B), (C) & (D)	(C) & (D)	(A) & (B)		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code: 

int x, y, z;

y = 1;

z = 5;

x = 0 - (++y) + z++;

After execution of this, what will be the values of x, y and z?"	MCQ	x = -7, y = 1, z = 5	x = 3, y = 2, z = 6	x = 4, y = 1, z = 5	x = 4, y = 2, z = 6		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Here is the general syntax for method definition: 



accessModifier returnType methodName( parameterList )

{

 Java statements



 return returnValue;

}





What is true for the accessModifier?"	MCQ	It must always be private or public	It can be omitted, but if not omitted there are several choices, including private and public	The access modifier must agree with the type of the return value	It can be omitted, but if not omitted it must be private or public		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"What will be the output of the program? 



public class CommandArgs 

{

  public static void main(String [] args) 

  {

    String s1 = args[1];

    String s2 = args[2];

    String s3 = args[3];

    String s4 = args[4];

    System.out.print("" args[2] = "" + s2);

  }

}



and the command-line invocation is 



> java CommandArgs 1 2 3 4"	MCQ	args[2] = 2	args[2] = 3	args[2] = null	An exception is thrown at runtime		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code snippet: 

int i = 10;

int n = ++i%5;

What are the values of i and n after the code is executed?"	MCQ	10, 1	11, 1	10, 0	11 , 0		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			Which will legally declare, construct, and initialize an array?	MCQ	"int [] myList = {""1"", ""2"", ""3""};"	int [] myList = (5, 8, 2);	int myList [] [] = {4,9,7,0};	int myList [] = {4, 3, 7};		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:

public class Test { 

 public static void main(String[] args) {

 int x=5;

 Test t=new Test();

 t.disp(x);

 System.out.println(""main X=""+x);

 }

void disp(int x) {

 System.out.println(""disp X = ""+x++);

 }}"	MCQ	disp X = 6 main X=6	disp X = 5 main X=5	disp X = 5 main X=6	Compilation error		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"How many objects and reference variables are created by the following lines of code?

Employee emp1, emp2;

emp1 = new Employee() ;

Employee emp3 = new Employee() ;"	MCQ	Two objects and three reference variables.	Three objects and two reference variables	Four objects and two reference variables	Two objects and two reference variables.		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"A) The purpose of the method overriding is to perform different operation, though input remains the same.

B) one of the important Object Oriented principle is the code reusability that can be achieved using abstraction"	MCQ	Only A is TRUE	Only B is True	Both A and B is True	Both A and B is FALSE		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"class Test{  

 public static void main(String[] args){

 byte b=(byte) (45 << 1);

 b+=4;

 System.out.println(b); }}

What should be the output for the code written above?"	MCQ	48	94	Compiles but error at run time	Compilation error		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"What is the value of y when the code below is executed?

int a = 4;

  int b = (int)Math.ceil(a % 3 + a / 3.0);"	MCQ	1	2	3	4		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct option:

class Test{ 

 class A{  

  interface X{

  int z=4;  } }

 static void display(){

 System.out.println(new A().X.z); }

 public static void main(String[] args) {

 display(); }}"	MCQ		Compilation error	Compiles but error at run time	4		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:

public class Test { 

 public static void main(String[] args) {

 String[] elements = { ""for"", ""tea"", ""too"" };

 String first = (elements.length > 0) ?elements[0] : null;

 System.out.println(first); }}"	MCQ	Compilation error	The variable first is set to null.	The variable first is set to elements[0].	Compiles but error at runtime		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"Given the following piece of code:

public class Test {

public static void main(String args[]) {

int i = 0, j = 5 ;

for( ; (i < 3) && (j++ < 10) ; i++ ) {

System.out.print("" "" + i + "" "" + j );

}

System.out.print("" "" + i + "" "" + j );

}

}

what will be the output?"	MCQ	0 6 1 7 2 8 3 8	0 6 1 7 2 8 3 9	0 5 1 5 2 5 3 5	compilation fails		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Given 

class MybitShift 

{

  public static void main(String [] args) 

  {

    int a = 0x5000000;

    System.out.print(a + "" and "");

    a = a >>> 25;

    System.out.println(a);

  }

}"	MCQ	83886080 and -2	2 and 83886080	2 and -83886080	83886080 and 2		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the code below & select the correct ouput from the options:



public class Test {

 int squares = 81;

 public static void main(String[] args) {

 new Test().go(); }

void go() {

 incr(++squares);

 System.out.println(squares); }

 void incr(int squares) { squares += 10; } }"	MCQ	92	91	Compilation error	82		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"class C{

public static void main (String[] args) {

byte b1=33;       //1

b1++;          //2

byte b2=55;       //3

b2=b1+1;         //4

System.out.println(b1+""""+b2);

}}

Consider the code above & select the correct output."	MCQ	compile time error at line 2	compile time error at line 4	prints 34,56	runtime exception	none of the listed options	0	1	0	0	0

		Keywords_variables_operators_datatypes_NewQB			"What will be the output of the program ? 



public class Test 

{

  public static void main(String [] args) 

  {

    signed int x = 10;

    for (int y=0; y<5; y++, x--)

      System.out.print(x + "", "");

  }

}"	MCQ	10, 9, 8, 7, 6,	9, 8, 7, 6, 5,	Compilation fails	An exception is thrown at runtime		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"1. public class LineUp {

2. public static void main(String[] args) {

3. double d = 12.345;

4. // insert code here

5. }

6. }

Which code fragment, inserted at line 4, produces the output | 12.345|?



A. System.out.printf(""|%7f| \n"", d);

B. System.out.printf(""|%3.7f| \n"", d);

C. System.out.printf(""|%7.3d| \n"", d);

D. System.out.printf(""|%7.3f| \n"", d);"	MCQ	A	B	C	D		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct option:

class Test{  

 interface Y{

 void display(); } 

 public static void main(String[] args) {

 Y y=new Y(){

  public void display(){

  System.out.println(""Hello World"");  } };

 y.display(); }}"	MCQ	Hello World	Compilation error	Compiles but error at run time	Compiles but run without output		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"class Test{

public static void main(String[] args){

int var;

var = var +1;

System.out.println(""var =""+var);

}}

consider the code above & select the proper output from the options."	MCQ	compiles and runs with no output	var = 1	does not compile	run time error		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"State the class relationship that is being implemented by the following code:

class Employee

{

private int empid;

private String ename;

public double getBonus()

{

Accounts acc = new Accounts();

return acc.calculateBonus();

}

}



class Accounts

{

public double calculateBonus(){//method's code}

}"	MCQ	Aggregation	Simple Association	Dependency	Composition		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"Given classes A, B, and C, where B extends A, and C extends B, and where all classes

implement the instance method void doIt(). How can the doIt() method in A be

called from an instance method in C?"	MCQ	It is not possible	super.doIt()	his.super.doIt()	((A) this).doIt();	A.this.doIt()	1	0	0	0	0

		Keywords_variables_operators_datatypes_NewQB			Which of the following will declare an array and initialize it with five numbers?	MCQ	Array a = new Array(5);	int [] a = {23,22,21,20,19};	int a [] = new int[5];	int [5] array;		0	1	0	0	

		Keywords_variables_operators_datatypes_NewQB			Which of the following are correct variable names? (Choose TWO)	MCA	int #ss;	int 1ah;	int _;	int $abc;		0	0	0.5	0.5	

		Keywords_variables_operators_datatypes_NewQB			"What is the output of the following: 



int a = 0;

int b = 10;



a = --b ;

System.out.println(""a: "" + a + "" b: "" + b );"	MCQ	a: 9 b:11	a: 10 b: 9	a: 9 b:9	a: 0 b:9		0	0	1	0	

		Keywords_variables_operators_datatypes_NewQB			"As per the following code fragment, what is the value of a?

String s;

int a;

s = ""Foolish boy."";

a = s.indexOf(""fool"");"	MCQ	-1		4	random value		1	0	0	0	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code snippet: 

int i = 10;

int n = i++%5;

What are the values of i and n after the code is executed?"	MCQ	10, 1	11, 1	10, 0	11 , 0		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and choose the correct output:



int value = 0;

int count = 1;

value = count++ ;

System.out.println(""value: ""+ value + "" count: "" + count);"	MCQ	value: 0 count: 0	value: 0 count: 1	value: 1 count: 1	value: 1 count: 2		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"Consider the following code and select the correct output:

class Test{  

 interface Y{

 void display(); } 

 public static void main(String[] args) {

 new Y(){

  public void display(){

  System.out.println(""Hello World"");  } };

 }}"	MCQ	Hello World	Compilation error	Compiles but error at run time	Compiles but run without output		0	0	0	1	

		Keywords_variables_operators_datatypes_NewQB			"What is the output of the following program?

public class demo {

 public static void main(String[] args) {

 int arr[5];

 for (int i = 0; i < arr.length; i++) {

 arr[i] = arr[i] + 10;

 }

 for (int j = 0; j < arr.length; j++)

 System.out.println(arr[j]);



 }

}"	MCQ	A sequence of five 10's are printed	A sequence of Garbage Values are printed	compile time Error	Compiles but no output		0	0	1	0	

		Threads_NewQB			Which of the following methods registers a thread in a thread scheduler?	MCQ	run();	construct();	start();	register();		0	0	1	0	

		Threads_NewQB			"class PingPong2 {

synchronized void hit(long n) {

for(int i = 1; i < 3; i++)

System.out.print(n + ""-"" + i + "" "");

}

}

 public class Tester implements Runnable {

 static PingPong2 pp2 = new PingPong2();

 public static void main(String[] args) {

 new Thread(new Tester()).start();

 new Thread(new Tester()).start();

 }

 public void run() { pp2.hit(Thread.currentThread().getId()); }

 }

Which statement is true?"	MCQ	The output could be 5-1 6-1 6-2 5-2	The output could be 6-1 6-2 5-1 5-2	The output could be 6-1 5-2 6-2 5-1	The output could be 6-1 6-2 5-1 7-1		0	1	0	0	

		Threads_NewQB			"Consider the following code and choose the correct option:

class Cthread extends Thread{  

 public void run(){

 System.out.print(""Hi"");}

public static void main (String args[]){

 Cthread th1=new Cthread();

 th1.run();

 th1.start();

th1.run();

}}"	MCQ	will print Hi twice and throws Exception at run time	will print Hi Thrice	Compilation error	will print Hi once		0	1	0	0	

		Threads_NewQB			"class Cthread extends Thread{  

 public void run(){

 System.out.print(""Hi"");}

public static void main (String args[]){

 Cthread th1=new Cthread();

 th1.run();

 th1.start();

 th1.start();

}}"	MCQ	will start two thread	will print Hi Once	will not print	will print Hi twice and throws exception at runtime		0	0	0	1	

		Threads_NewQB			"Consider the following code and choose the correct option:

class Cthread extends Thread{

  Cthread(){start();}

 public void run(){

 System.out.print(""Hi"");}

public static void main (String args[]){

 Cthread th1=new Cthread();

Cthread th2=new Cthread();

}}"	MCQ	will create two child threads and display Hi twice	compilation error	will not create any child thread	will display Hi once		1	0	0	0	

		Threads_NewQB			Which of the following methods are defined in class Thread? (Choose TWO)	MCA	start()	wait()	notify()	run()	terminate()	0.5	0	0	0.5	0

		Threads_NewQB			"The following block of code creates a Thread using a Runnable target: 



Runnable target = new MyRunnable();

Thread myThread = new Thread(target);



Which of the following classes can be used to create the target, so that the preceding code compiles correctly?"	MCQ	public class MyRunnable implements Runnable{public void run(){}}	public class MyRunnable extends Runnable{public void run(){}}	public class MyRunnable implements Runnable{void run(){}}	public class MyRunnable extends Object{public void run(){}}		1	0	0	0	

		Threads_NewQB			Which of the following statements can be used to create a new Thread? (Choose TWO)	MCA	Extend java.lang.Thread and override the run() method.	Extend java.lang.Runnable and override the start() method.	Implement java.lang.Thread and implement the run() method.	Implement java.lang.Runnable and implement the run() method	Implement java.lang.Thread and implement the start() method.	0.5	0	0	0.5	0

		Threads_NewQB			"What will be the output of the program? 



class MyThread extends Thread 

{ 

  MyThread() {} 

  MyThread(Runnable r) {super(r); } 

  public void run() 

  { 

    System.out.print(""Inside Thread "");

  } 

} 

class MyRunnable implements Runnable 

{ 

  public void run() 

  { 

    System.out.print("" Inside Runnable""); 

  } 

} 

class Test 

{  

  public static void main(String[] args) 

  { 

    new MyThread().start(); 

    new MyThread(new MyRunnable()).start(); 

  } 

}"	MCQ	"Prints ""Inside Thread Inside Thread"""	Does not compile	"Prints ""Inside Thread Inside Runnable"""	Throws exception at runtime		1	0	0	0	

		Threads_NewQB			"A) Multiple processes share same memory location

B) Switching from one thread to another is easier than switching from one process to another

C) Thread makes it possible to maximize resource utilization

D) Process is a light weight program"	MCQ	All are FALSE	Only B and C is TRUE	Only A and B is TRUE	Only C and D is TRUE		0	1	0	0	

		Threads_NewQB			"A) Exception is the superclass of all errors and exceptions in the java language

B) RuntimeException and its subclasses are unchecked exception."	MCQ	Only A is TRUE	Only B is TRUE	Both A and B are TRUE	Both A and B are FALSE		0	1	0	0	

		Threads_NewQB			"What will be the output of the program? 



class MyThread extends Thread 

{

  public static void main(String [] args) 

  {

    MyThread t = new MyThread();

    t.start();

    System.out.print(""one. "");

    t.start();

    System.out.print(""two. "");

  }

  public void run() 

  {

    System.out.print(""Thread "");

  }

}"	MCQ	Compilation fails	An exception occurs at runtime.	"It prints ""Thread one. Thread two."""	The output cannot be determined.		0	1	0	0	

		Threads_NewQB			"Consider the following code and choose the correct option:

class A implements Runnable{ int k;

public void run(){

k++; } 

public static void main(String args[]){

A a1=new A();

a1.run();}"	MCQ	It will start a new thread	compilation error	Compiles but throws run time Exception	a1 is not a Thread		0	0	0	1	

		Threads_NewQB			"Given:

 public class Threads4 {

 public static void main (String[] args) {

 new Threads4().go();

 }

 public void go() {

 Runnable r = new Runnable() {

 public void run() {

 System.out.print(""run"");

 }

 };

 Thread t = new Thread(r);

 t.start();

 t.start();

 }

 }

What is the result?"	MCQ	Compilation fails.	An exception is thrown at runtime.	"The code executes normally and prints ""run""."	The code executes normally, but nothing is printed.		0	1	0	0	

		Threads_NewQB			"class Thread2 {

 public static void main(String[] args) {

 new Thread2().go(); }

 public void go(){

 Runnable rn=new Runnable(){

 public void run(){

 System.out.println(""Good Day..""); } };

 Thread t=new Thread(rn);

 t.start();

 }}

what should be the correct output for the code written above?"	MCQ	Compilation fails.	An exception is thrown at runtime.	"The code executes normally and prints ""Good Day.."""	prints Good Day.. Twice		0	0	1	0	

		Threads_NewQB			"public class MyRunnable implements Runnable 

{

  public void run() 

  {

    // some code here

  }

}

which of these will create and start this thread?"	MCQ	new Runnable(MyRunnable).start();	new Thread(MyRunnable).run();	new MyRunnable().start();	new Thread(new MyRunnable()).start();		0	0	0	1	

		Threads_NewQB			"Consider the following code and choose the correct option:

class Nthread extends Thread{

 public void run(){

 System.out.print(""Hi"");}

 public static void main(String args[]){

  Nthread th1=new Nthread();

  Nthread th2=new Nthread();

}"	MCQ	Will create two child threads and display Hi twice	compilation error	will not create any child thread	will display Hi once		0	0	1	0	

		Threads_NewQB			"Assume the following method is properly synchronized and called from a thread A on an object B:



wait(2000);



After calling this method, when will the thread A become a candidate to get another turn at the CPU?"	MCQ	After thread A is notified, or after two seconds.	After the lock on B is released, or after two seconds.	Two seconds after thread A is notified.	Two seconds after lock B is released.		1	0	0	0	

		Threads_NewQB			wait(), notify() and notifyAll() methods belong to ________	MCQ	Object class	Thread class	Interrupt class	none of the listed options		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

class Test {

 public static void main(String[] args) { 

 new Test().display(""hi"", 1);

 new Test().display(""hi"", ""world"", 2); }

 public void display(String... s, int x) {

 System.out.print(s[s.length-x] + "" ""); } }"	MCQ	hi hi	hi world	world	Compilation error		0	0	0	1	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String name=""Anthony Gomes"";

 int a=111;

 System.out.println(name.indexOf(a)); }}"	MCQ	4	2	6	Compilation error		1	0	0	0	

		strings_string_buffer_NewQB			"Given:

 String test = ""This is a test"";

 String[] tokens = test.split(""\s"");

 System.out.println(tokens.length);

What is the result?"	MCQ		1	4	Compilation fails.		0	0	0	1	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String data=""78"";  

 System.out.println(data.append(""abc""));  }}"	MCQ	78abc	abc78	Compilation error	Compiles but exception at run time		0	0	1	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String name=""ALDPR7882E"";

 System.out.println(name.endsWith(""E"") & name.matches(""[A-Z]{5}[0-9]{4}[A-Z]""));}}"	MCQ	false	true		1		0	1	0	0	

		strings_string_buffer_NewQB			"Examine this code: 



String stringA = ""Hello "";

String stringB = "" World"";

String stringC = "" Java"";

String result;

Which of the following puts a reference to ""Hello World Java"" in result?"	MCQ	result = stringA.concat( stringB.concat( stringC ) );	result.concat( stringA, stringB, stringC );	result+stringA+stringB+stringC;	result = concat(StringA).concat(StringB).concat(StringC)		1	0	0	0	

		strings_string_buffer_NewQB			"For two string objects obj1 and obj2:

A) Use of obj1 == obj2 tests whether two String object references refer to the same object

B) obj1.equals(obj2) compares the sequence of characters in obj1 and obj2."	MCQ	Only A is TRUE	Only B is TRUE	Both A and B is TRUE	Both A and B is FALSE		0	0	1	0	

		strings_string_buffer_NewQB			"What is the result of the following: 



String ring = ""One ring to rule them all,\n"";

String find = ""One ring to find them."";



if ( ring.startsWith(""One"") && find.startsWith(""One"") )

 System.out.println( ring+find );

else

 System.out.println( ""Different Starts"" );"	MCQ	One ring to rule them all, One ring to find them.	One ring to rule them all, One ring to find them.	One ring to rule them all,\n One ring to find them.	Different Starts		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

class MyClass {

String str1=""str1"";

String str2 =""str2"";

String str3=""str3"";

str1.concat(str2);

System.out.println(str3.concat(str1));

}

}"	MCQ	The code will fail to compile because the expression str3.concat(str1) will not result in a valid argument for the println() method	The program will print str3str1str2,when run	The program will print str3,when run	The program will print str3str1,when run	The program will print str3str2,when run	0	0	0	1	0

		strings_string_buffer_NewQB			"Given:

public class Theory {

public static void main(String[] args) {

String s1 = ""abc"";

String s2 = s1;

s1 += ""d"";

System.out.println(s1 + "" "" + s2 + "" "" + (s1==s2));



StringBuffer sb1 = new StringBuffer(""abc"");

StringBuffer sb2 = sb1;

sb1.append(""d"");

System.out.println(sb1 + "" "" + sb2 + "" "" + (sb1==sb2));

}

}

Which are true? (Choose all that apply.)"	MCA	Compilation fails	The first line of output is abc abc false	The first line of output is abcd abc false	The second line of output is abcd abc false	The second line of output is abcd abcd true	0	0	0.5	0	0.5

		strings_string_buffer_NewQB			"class StringManipulation{

public static void main(String[] args){

String str = new String(""Cognizant"");

str.concat("" Technology"");

StringBuffer sbf = new StringBuffer("" Solutions"");

System.out.println(str+sbf);

}}

consider the code above & select the proper output from the options."	MCQ	Cognizant Technology Solutions	Cognizant Technology	Cognizant Solutions	Technology Solutions		0	0	1	0	

		strings_string_buffer_NewQB			"What does this code write: 



StringTokenizer stuff = new StringTokenizer( ""abc def+ghi"", ""+"");

System.out.println( stuff.nextToken() );

System.out.println( stuff.nextToken() );"	MCQ	abc def	abc def ghi	abc def +	abc def +ghi		0	1	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 StringBuffer sb = new StringBuffer(""antarctica"");

   sb.delete(0,6);

   System.out.println(sb); }}"	MCQ	tica	anta	Compilation error	Complies but exception at run time		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String name=""vikaramaditya"";

 System.out.println(name.substring(2, 5).toUpperCase().charAt(2));}}"	MCQ	K	A	R	I		0	0	1	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 StringBuffer sb = new StringBuffer(""antarctica"");

   sb.reverse();   

   sb.replace(2, 7, ""c"");    

   sb.delete(0,2);

   System.out.println(sb); }}"	MCQ	acctna	iccratna	ctna	tna		0	0	1	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

class Test {

 public static void main(String args[]) {

 String s1 = ""abc"";

 String s2 = ""def"";

 String s3 = s1.concat(s2.toUpperCase( ) );

 System.out.println(s1+s2+s3); } }"	MCQ	abcdefabcdef	  abcabcDEFDEF	   abcdefabcDEF	none of the listed options		0	0	1	0	

		strings_string_buffer_NewQB			"What will be the result when you attempt to compile and run the following code?. 

public class Conv

 {

  public static void main(String argv[]){

 Conv c=new Conv();

 String s=new String(""ello"");

 c.amethod(s);

  }



  public void amethod(String s){

 char c='H';

 c+=s;

 System.out.println(c);

  }

}"	MCQ	"Compilation and output the string ""Hello"""	"Compilation and output the string ""ello"""	Compilation and output the string elloH	Compile time error		0	0	0	1	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String name=""Anthony Gomes"";

 System.out.println(name.replace('n', name.charAt(3)).compareTo(name)); }}"	MCQ	-6	6		Compilation error		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

class Test {

 public static void main(String args[]) {

 String name=new String(""batman"");

 int ibegin=1;

 char iend=3;

 System.out.println(name.substring(ibegin, iend));

 } }"	MCQ	bat	at	atm	Compilation error		0	1	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 StringBuffer sb=new StringBuffer(""YamunaRiver"");

 System.out.println(sb.capacity()); }}"	MCQ	10	27	24	11		0	1	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 StringBuffer sb = new StringBuffer(""antarctica"");

   sb.reverse();   

   sb.insert(4, 'r');    

   sb.replace(2, 4, ""c"");    

   System.out.println(sb); }}"	MCQ	acitcratna	acitrcratna	accircratna	accrcratna		0	0	0	1	

		strings_string_buffer_NewQB			"A)A string buffer is a mutable sequence of characters.

B) sequece of characters in the string buffer can not be changed."	MCQ	Only A is TRUE	Only B is TRUE	Both A and B is TRUE	Both A and B is FALSE		1	0	0	0	

		strings_string_buffer_NewQB			"Examine this code: 



String stringA = ""Wild"";

String stringB = "" Irish"";

String stringC = "" Rose"";

String result;



Which of the following puts a reference to ""Wild Irish Rose"" in result?"	MCQ	result = stringA.concat( stringB.concat( stringC ) );	result.concat( stringA, stringB, stringC );	result+stringA+stringB+stringC;	result = concat(StringA).concat(StringB).concat(StringC)		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

class Test {

 public static void main(String[] args) { 

 new Test().display(1,""hi"");

 new Test().display(2,""hi"", ""world"" ); }

 public void display(int x,String... s) {

 System.out.print(s[s.length-x] + "" ""); }}"	MCQ	hi hi	hi world	world	Compilation error		1	0	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String name=""vikaramaditya""; System.out.println(name.codePointAt(2)+name.charAt(3)); }}"	MCQ	203	204	205	Compilation error		0	1	0	0	

		strings_string_buffer_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 String data=""7882"";

 data+=32; System.out.println(data);  }}"	MCQ	7914	Compiles but exception at run time	788232	Compilation error		0	0	1	0	

		strings_string_buffer_NewQB			"Which code can be inserted at Line X to print ""Equal""?

public class EqTest{

 public static void main(String argv[]){

  EqTest e=new EqTest();

 }



 EqTest(){

  String s=""Java"";

  String s2=""java"";

  // Line X

  {

  System.out.println(""Equal"");

  }else

  {

  System.out.println(""Not equal"");

  }

 }

}"	MCQ	if(s==s2)	if(s.equals(s2))	if(s.equalsIgnoreCase(s2))	if(s.noCaseMatch(s2))	if(s.equalIgnoreCase(s2))	0	0	1	0	0

		IO_Operations_NewQB			"import java.io.*;

public class MyClass implements Serializable {

private int a;

public int getA() { return a; }

publicMyClass(int a){this.a=a; }

private void writeObject( ObjectOutputStream s)

throws IOException {

// insert code here

}

}



Which code fragment, inserted at line 15, will allow Foo objects to be

correctly serialized and deserialized?"	MCQ	s.writeInt(x);	s.serialize(x);	s.defaultWriteObject();	s.writeObject(x);		0	0	1	0	

		IO_Operations_NewQB			"Which of the following opens the file ""myData.stuff"" for output first deleting any file with that name?"	MCQ	"FileOutputStream fos = new FileOutputStream( ""myData.stuff"", true )"	"FileOutputStream fos = new FileOutputStream( ""myData.stuff"")"	"DataOutputStream dos = new DataOutputStream( ""myData.stuff"" )"	"FileOutputStream fos = new FileOutputStream( new BufferedOutputStream( ""myData.stuff"") )"		0	1	0	0	

		IO_Operations_NewQB			"import java.io.*;

public class MyClass implements Serializable {



private Tree tree = new Tree();



public static void main(String [] args) {

MyClass mc= new MyClass();

try {

FileOutputStream fs = new FileOutputStream(�MyClass.ser�);

ObjectOutputStream os = new ObjectOutputStream(fs);

os.writeObject(mc); os.close();

} catch (Exception ex) { ex.printStackTrace(); }

} }"	MCQ	Compilation fails	An exception is thrown at runtime	An instance of MyClass is serialized	A instance of MyClass and an instance of Tree are both serialized		1	0	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

class std implements Serializable{

 int call; std(int c){call=c;}

 int getCall(){return call;}

}

public class Test{

 public static void main(String[] args) throws IOException {

  File file=new File(""d:/std.txt"");

 FileOutputStream fos=new FileOutputStream(file);

 ObjectOutputStream oos=new ObjectOutputStream(fos);

 std s1=new std(10);

 oos.writeObject(s1);

 oos.close();

 }}"	MCQ	the state of the object s1 will be store to file std.txt	Compilation error	Compiles but error at run time	the state of the object s1 will not be store to the file.		1	0	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) throws IOException {  

 File file=new File(""D:/jlist.lst"");

 byte buffer[]=new byte[(int)file.length()+1];

 FileInputStream fis=new FileInputStream(file);

 int ch=0;

 while((ch=fis.read())!=-1){

  System.out.print(ch); } }}"	MCQ	reads data from file one byte at a time and display it on the console.	Compilation error	reads data from file named jlist.lst in byte form and ascii value	Compiles but error at runtime		0	0	1	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) throws IOException {  

 File file=new File(""D:/jlist.lst"");

 byte buffer[]=new byte[(int)file.length()+1];

 FileInputStream fis=new FileInputStream(file);

 int ch=0;

 while((ch=fis.read())!=-1){

  System.out.print((char)ch); } }}"	MCQ	reads data from file one byte at a time and display it on the console.	Compilation error	reads data from file named jlist.lst in byte form and display garbage value	Compiles but error at runtime		1	0	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 File file=new File(""d:/prj/lib"");

 file.mkdirs();}}"	MCQ	creates directory d:/prj/lib	Compilation error	Compiles but error at run time	Compiles and executes but directory is not created		1	0	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) throws IOException {  

 String data=""Confidential info"";

 byte buffer[]=data.getBytes();

 FileOutputStream fos=new FileOutputStream(""d:/temp"");

 for(byte d : buffer){

  fos.write(d); } }}"	MCQ	writes data to file in byte form.	Compilation error	writes data to the file in character form.	Compiles but error at runtime		1	0	0	0	

		IO_Operations_NewQB			"Given : 

import java.io.*;

 public class ReadingFor {

 public static void main(String[] args) {

 String s;

 try {

 FileReader fr = new FileReader(""myfile.txt"");

 BufferedReader br = new BufferedReader(fr);

 while((s = br.readLine()) != null)

 System.out.println(s);

 br.flush();

 } catch (IOException e) { System.out.println(""io error""); }

 }

}

And given that myfile.txt contains the following two lines of data:

ab

cd

What is the result?"	MCQ	ab	abcd	ab cd	a b c d	Compilation Error	0	0	0	0	1

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

class std{

 int call; std(int c){call=c;}

 int getCall(){return call;}

}

public class Test{

 public static void main(String[] args) throws IOException {

  File file=new File(""d:/std.txt"");

 FileOutputStream fos=new FileOutputStream(file);

 ObjectOutputStream oos=new ObjectOutputStream(fos);

 std s1=new std(10);

 oos.writeObject(s1);

 oos.close();

 }}"	MCQ	the state of the object s1 will be store to file std.txt	Compilation error	Compiles but error at run time	the state of the object s1 will not be store to the file.		0	0	1	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {  

 File file=new File(""D:/jlist.lst"");

 byte buffer[]=new byte[(int)file.length()+1];

 FileInputStream fis=new FileInputStream(file);

 fis.read(buffer);

 System.out.println(buffer);

 }

}"	MCQ	reads data from file named jlist.lst in byte form and display it on console.	Compilation error	reads data from file named jlist.lst in byte form and display garbage value	Compiles but error at runtime		0	1	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) throws IOException {  

 File file=new File(""D:/jlist.lst"");

 byte buffer[]=new byte[(int)file.length()+1];

 FileInputStream fis=new FileInputStream(file);

 fis.read(buffer);

 System.out.println(new String(buffer)); }}"	MCQ	reads data from file named jlist.lst in byte form and display it on console.	Compilation error	reads data from file named jlist.lst in byte form and display garbage value	Compiles but error at runtime		1	0	0	0	

		IO_Operations_NewQB			What happens when the constructor for FileInputStream fails to open a file for reading?	MCQ	throws a DataFormatException	throws a FileNotFoundException	throws a ArrayIndexOutOfBoundsException	returns null		0	1	0	0	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) {

 File file=new File(""d:/prj,d:/lib"");

 file.mkdirs();}}"	MCQ	creates directories names prj and lib in d: drive	Compilation error	Compiles but error at run time	Compiles and executes but directories are not created		0	0	0	1	

		IO_Operations_NewQB			"Consider the following code and choose the correct output:

public class Person{

public void talk(){ System.out.print(""I am a Person ""); }

}

public class Student extends Person {

public void talk(){ System.out.print(""I am a Student ""); }

}

what is the result of this piece of code:

public class Test{

public static void main(String args[]){

Person p = new Student();

p.talk();

}

}"	MCQ	I am a Person	I am a Student	I am a Person I am a Student	I am a Student I am a Person		0	1	0	0	

		IO_Operations_NewQB			"Which of these are two legal ways of accessing a File named ""file.tst"" for reading. Select the correct option:

A)FileReader fr = new FileReader(""file.tst""); 

B)FileInputStream fr = new FileInputStream(""file.tst"");

C)InputStreamReader isr = new InputStreamReader(fr, ""UTF8""); 

D)FileReader fr = new FileReader(""file.tst"", ""UTF8"");"	MCQ	A,D	B,C	C,D	A,B		0	0	0	1	

		IO_Operations_NewQB			What is the DataOutputStream method that writes double precision floating point values to a stream?	MCQ	writeBytes()	writeFloat()	write()	writeDouble()		0	0	0	1	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test{

 public static void main(String[] args) {

 File dir = new File(""dir"");

 dir.mkdir();

 File f1 = new File(dir, ""f1.txt""); try {

 f1.createNewFile(); } catch (IOException e) { ; }

 File newDir = new File(""newDir"");

 dir.renameTo(newDir);} }"	MCQ	The file system has a new empty directory named dir	The file system has a new empty directory named newDir	The file system has a directory named dir, containing a file f1.txt	The file system has a directory named newDir, containing a file f1.txt	Compilation error	0	0	0	1	0

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test {

 public static void main(String[] args) throws IOException {

 File file=new File(""d:/data"");

 byte buffer[]=new byte[(int)file.length()+1];

 FileInputStream fis=new FileInputStream(file);

 fis.read(buffer);

 FileWriter fw=new FileWriter(""d:/temp.txt"");

 fw.write(new String(buffer));}}"	MCQ	Transfer content of file data to the temp.txt	Compilation error	Compiles but error at runtime	Compiles and runs but content not transferred to the temp.txt		0	0	0	1	

		IO_Operations_NewQB			"import java.io.EOFException;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.IOException;

import java.io.InputStreamReader;

public class MoreEndings {

public static void main(String[] args) {

try {

FileInputStream fis = new FileInputStream(""seq.txt"");

InputStreamReader isr = new InputStreamReader(fis);

int i = isr.read();

while (i != -1) {

System.out.print((char)i + ""|"");

i = isr.read();

}

} catch (FileNotFoundException fnf) {

System.out.println(""File not found"");

} catch (EOFException eofe) {

System.out.println(""End of stream"");

} catch (IOException ioe) {

System.out.println(""Input error"");

}

}

}

Assume that the file ""seq.txt"" exists in the current directory, has the required

access permissions, and contains the string ""Hello"".

Which statement about the program is true?"	MCQ	The program will not compile because a certain unchecked exception is not caught.	The program will compile and print H|e|l|l|o|Input error.	The program will compile and print H|e|l|l|o|End of stream.	The program will compile, print H|e|l|l|o|, and then terminate normally.		0	0	0	1	

		IO_Operations_NewQB			"Consider the following code and choose the correct option:

public class Test{

 public static void main(String[] args) throws IOException {

 File file = new File(""d:/temp.txt"");

 FileReader reader=new FileReader(file);

 reader.skip(7); int ch;

 while((ch=reader.read())!=-1){

  System.out.print((char)ch); } }}"	MCQ	Skip the first seven characters and then starts reading file and display it on console	Compilation error	Compiles and runs without output	Compiles but error at runtime		1	0	0	0	

		IO_Operations_NewQB			"A file is readable but not writable on the file system of the host platform. What will

be the result of calling the method canWrite() on a File object representing this file?"	MCQ	A SecurityException is thrown	The boolean value false is returned	The boolean value true is returned	The file is modified from being unwritable to being writable.	none of the listed options	0	1	0	0	0

		Introduction_to_OOPS_NewQB			Which of following set of functions are example of method overloading	MCQ	void add(int x,int y) char add(int x,int y)	char add(float x) char add(float y)	void add(int x,int y) char add(char x,char y)	void add(int x,int y) void sum(double x,double y)		0	0	1	0	

		Introduction_to_OOPS_NewQB			What is the advantage of runtime polymorphism?	MCQ	Efficient utilization of memory at runtime	Code reuse	Code flexibility at runtime	avoiding method name confusion at runtime		0	0	1	0	

		Introduction_to_OOPS_NewQB			Which of the following is an example of IS A relationship?	MCQ	Ford - Car	Microprocessor - Computer	Tea -Cup	Driver -Car		1	0	0	0	

		Introduction_to_OOPS_NewQB			Which of the following is not a valid relation between classes?	MCQ	Inheritance	Segmentation	Instantiation	Composition		0	1	0	0	

		Introduction_to_OOPS_NewQB			Which of the following is not an attribute of object?	MCQ	State	Behaviour	Inheritance	Identity		0	0	0	1	

																