import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String nm,c;
	System.out.println("Enter the venue name");
	nm=sc.nextLine();
	System.out.println("Enter the city name");
	c=sc.nextLine();
	System.out.println("Venue Details");
	Venue v=new Venue();
	v.setName(nm);
	v.setCity(c);
	System.out.println(v.toString());
}
}
