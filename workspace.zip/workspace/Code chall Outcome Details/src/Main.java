import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	int n,i;

	long s;

	String w,d,p;

	System.out.println("Enter the number of outcome");

	n=sc.nextInt();

	sc.nextLine();

	Outcome o[]=new Outcome[n];

	for(i=0;i<n;i++){

		System.out.println("Enter outcome "+(i+1)+" details");

		System.out.println("Enter the date");

		d=sc.nextLine();

		System.out.println("Enter the score");

		s=sc.nextLong();

		sc.nextLine();

		System.out.println("Enter the winner team");

		w=sc.nextLine();

		System.out.println("Enter the player of match");

		p=sc.nextLine();

		

		o[i]=new Outcome(d,s,w,p);

		

		

	}

	OutcomeBO ob=new OutcomeBO();

	

		System.out.println("1.View details\n2.Search by date\nEnter your choice");

	int	j=sc.nextInt();

		switch (j){

		

		case 1:

			//System.out.println("Outcome Details");

			//System.out.println(String.format("%-20s %-20s %-20s %s","Score","Winning Team","Player Of The Match","Date"));

			ob.displayAllOutcomeDetails(o);

		break;

		case 2:

			System.out.println("Enter the date to be searhed");

			//System.out.println("Outcome Details");

			//System.out.println(String.format("%-20s %-20s %-20s %s","Score","Winning Team","Player Of The Match","Date"));

			

			sc.nextLine();

		String d2=sc.nextLine();

		ob.displaySpecificOutcomeDetails(o,d2);

		break;

		

		default:

			System.exit(1);

		

		}

		

	

	

	

	

}

}

