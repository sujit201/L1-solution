import java.io.BufferedReader;

import java.io.InputStreamReader;



public class Main{

	public static void main(String[] args)throws Exception{

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		//Your code goes here

		System.out.println("Enter the registration no. to be validated:");

		String registrationNo=reader.readLine();

		if(validateWebsite(registrationNo)==true){

			System.out.println("Registration No. is valid");

		}

		else {

			System.out.println("Registration No. is invalid");

		}

	}



	static Boolean validateWebsite(String regno){

		if(regno.matches("[A-Z]{2}\\s([0-9][0-9]|[1-9]?)\\s?[A-Z]{0,2}\\s[1-9]([0-9]{1,3})?"))

		return true;

		

		else return false;

	}

}



