import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	

	int n,i;

	n=sc.nextInt();

	

	ArrayList<Integer> r=new ArrayList<Integer>();

	

	for(i=0;i<n;i++){

		

		r.add(sc.nextInt());

		

	}

	Collections.sort(r);



	Iterator it=r.iterator();

	while(it.hasNext())

	{

		System.out.println(it.next());

	}

	



	

	

}

}