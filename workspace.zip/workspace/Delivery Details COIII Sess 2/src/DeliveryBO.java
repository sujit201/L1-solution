
public class DeliveryBO 

{

	public void displayAllDeliveryDetails(Delivery[] deliveryList)

	{

		System.out.println("Delivery Details");

		System.out.println((String.format("%-20s %-20s %-20s %-20s %-20s %s","Over","Ball","Runs","Batsman","Bowler","NonStriker")));

		for(int i=0;i<deliveryList.length;i++)

		{

			System.out.println(deliveryList[i].toString());

		}

	}

	

	public void displayBatsmanBowlerDetails(Delivery[] deliveryList,long ball,long over)

	{

		for(int i=0;i<deliveryList.length;i++)

		{

			if(deliveryList[i].getBall()==ball && deliveryList[i].getOver()==over)

			{

				System.out.println("Batsman : "+deliveryList[i].getBatsman());

				System.out.println("Bowler : "+deliveryList[i].getBowler());

			}

		}

	}

	

	public void displayMaximumRunsDetails(Delivery[] deliveryList)

	{

		long max=0;

		for(int i=0;i<deliveryList.length;i++)

		{

			if(deliveryList[i].getRuns()>max)

			{

				max=deliveryList[i].getRuns();

			}

		}

		

		for(int i=0;i<deliveryList.length;i++)

		{

			if(deliveryList[i].getRuns()==max)

			{

				System.out.println("Maximum Runs : "+deliveryList[i].getRuns());

				System.out.println("Over : "+deliveryList[i].getOver());

				System.out.println("Ball : "+deliveryList[i].getBall());

			}

		}

		

	}



}







