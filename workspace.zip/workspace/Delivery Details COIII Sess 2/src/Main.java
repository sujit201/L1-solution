import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of deliveries");

		int n=sc.nextInt();

		Delivery d[]=new Delivery[n];

		

		int i;

		long over=0;

		long ball=0;

		long runs=0;

		String nonStriker=null;

		String batsman=null;

		String bowler=null;

		

		for(i=0;i<n;i++)

		{

			System.out.println("Enter the over");

			over=sc.nextLong();

			System.out.println("Enter the ball");

			ball=sc.nextLong();

			System.out.println("Enter the runs");

			runs=sc.nextLong();

			sc.nextLine();

			System.out.println("Enter the batsman name");

			batsman=sc.nextLine();

			System.out.println("Enter the bowler name");

			bowler=sc.nextLine();

			System.out.println("Enter the nonStriker name");

			nonStriker=sc.nextLine();

			d[i]=new Delivery(over, ball, runs, nonStriker, batsman, bowler);

		}

		

		System.out.println("Enter your choice\n1.View delivery details\n2.Batsman and Bowler\n3.Maximum runs");

		int choice=sc.nextInt();

		sc.close();

		

		DeliveryBO dbo=new DeliveryBO();

		switch(choice)

		{

			case 1:

				dbo.displayAllDeliveryDetails(d);

				break;

			case 2:

				System.out.println("Enter the over for which batsman and bowler to be known");

				int o=sc.nextInt();

				System.out.println("Enter the ball for which batsman and bowler to be known");

				int b=sc.nextInt();

				dbo.displayBatsmanBowlerDetails(d, b, o);

				break;

			case 3:

				dbo.displayMaximumRunsDetails(d);

				break;

			default:

				System.exit(0);	

		}



	}



}