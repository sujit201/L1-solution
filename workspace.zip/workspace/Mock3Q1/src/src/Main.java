import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

 

public class Main {

               public static void main(String []args) throws IOException {

                               BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

                               //Your code goes here...

                               Movie m[]=new Movie[2];

                               System.out.println("Enter movie 1 detail:");

                               String name=reader.readLine();

                               String[] ar=name.split(",");

                               m[0]=new Movie(ar[0],Double.parseDouble(ar[1]),Double.parseDouble(ar[2]),Double.parseDouble(ar[3]));

                               

                               System.out.println("Enter movie 2 detail:");

                               //Your code goes here...

                               name=reader.readLine();

                               String[] ar1=name.split(",");

                               m[1]=new Movie(ar1[0],Double.parseDouble(ar1[1]),Double.parseDouble(ar1[2]),Double.parseDouble(ar1[3]));

                               

                               int i=1;

                               for(Movie mov:m)

                               {

                                               System.out.println("\nMovie "+i+"");

                                               System.out.println(mov);

                                               i++;

                               }

                               if(m[0].equals(m[1])){

                                               System.out.println("\nMovie 1 is same as Movie 2");

                               }

                               else

                                               System.out.println("\nMovie 1 and Movie 2 are different");

               }

}