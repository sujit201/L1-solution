import java.util.*;



public class Main {



public static void main(String args[])



{



	Scanner sc=new Scanner(System.in);



	



	System.out.println("Circle");



	System.out.println("Square");



	System.out.println("Rectangle");



	



	System.out.println("Enter the shape name");



	String name=sc.nextLine();



	



	if(name.equalsIgnoreCase("Circle"))



	{



		System.out.println("Enter the radius");



		int radius=sc.nextInt();



		Circle c=new Circle(name,radius);



		float area=c.calculateArea();



		System.out.printf("Area of Circle is %.2f", area);



	}



	if(name.equalsIgnoreCase("Square"))



	{



		System.out.println("Enter the side");



		int side=sc.nextInt();



		Square s=new Square(name,side);



		float area1=s.calculateArea();



		System.out.printf("Area of Square is %.2f", area1);



	}



	if(name.equalsIgnoreCase("Rectangle"))



	{



		System.out.println("Enter the length");



		int length=sc.nextInt();



		System.out.println("Enter the breadth");



		int breadth=sc.nextInt();



		



		Rectangle r=new Rectangle(name,length,breadth);



		float area2=r.calculateArea();



		System.out.printf("Area of Rectangle is %.2f", area2);



	}



}



}