public abstract class Shape {



	



	protected String name;







	public String getName() {



		return name;



	}







	public void setName(String name) {



		this.name = name;



	}



	



	Shape()



	{



		



	}



	



	Shape(String name)



	{



		this.setName(name);



	}



	



	abstract float calculateArea();



}

