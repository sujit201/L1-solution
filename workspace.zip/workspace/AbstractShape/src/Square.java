public class Square extends Shape{



	



	private int side;







	public int getSide() {



		return side;



	}







	public void setSide(int side) {



		this.side = side;



	}



	



	Square()



	{



		



	}



	



	Square(String name, int side)



	{



		super(name);



		this.setSide(side);



	}



	



	public float calculateArea()



	{



		return (float)side*side;



	}



}





