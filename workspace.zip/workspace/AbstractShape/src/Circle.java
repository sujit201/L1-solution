public class Circle extends Shape{



	



	private int radius;







	public int getRadius() {



		return radius;



	}







	public void setRadius(int radius) {



		this.radius = radius;



	}



	



	Circle()



	{



		



	}



	



	Circle(String name,int radius)



	{



		super(name);



		this.setRadius(radius);



	}



	



	public float calculateArea()



	{



		return (float)(3.14*radius*radius);



	}







}



