import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int i,n1,n2;
	String tmp;
	System.out.println("Enter the number of best bowlers in season 4");
	n1=sc.nextInt();
	sc.nextLine();
	HashSet<String> a=new HashSet<String>();
	System.out.println("Enter the name of players");
for(i=0;i<n1;i++)
{
	a.add(sc.nextLine());
	


System.out.println("Enter the number of best bowlers in season 5");
n2=sc.nextInt();
sc.nextLine();
HashSet<String> b=new HashSet<String>();
System.out.println("Enter the name of players");
for(i=0;i<n2;i++)
{
	b.add(sc.nextLine());
	
}
System.out.println("Player Set 1");
Iterator it=a.iterator();
for(i=0;i<n1;i++) {
	System.out.println(it.next());

}

System.out.println("Player Set 2");
Iterator it1=b.iterator();
for(i=0;i<n2;i++)
{
	System.out.println(it1.next());

}
System.out.println("Difference");
HashSet<String> difference = new HashSet<String>();
difference.addAll(a);
difference.removeAll(b);
it1=difference.iterator();
for(i=0;i<difference.size();i++)
{
	System.out.println(it1.next());

}
}}


