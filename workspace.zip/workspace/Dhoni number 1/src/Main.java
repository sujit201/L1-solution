import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b,i,n,t,r,flag=0,k=0;
		a=sc.nextInt();
		b=sc.nextInt();
		for(n=a;n<=b;n++)
		{
			t=n;k=0;
			while(t>0)
			{
				r=t%10;
				t=t/10;
				flag=0;
				if(r==1||r==0)
					flag=1;
				for(i=2;i<r;i++) {
					if(r%i==0) {
						flag=1;
					}
				}
				if(flag==0)
					k++;
			
		}

if(k==2)
	System.out.print(n+" ");
	}

}
}
