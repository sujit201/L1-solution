package iodemo;
class AA{
	  AA()
	{
		  super();
			System.out.println("class A");
		}
	}
	class C extends A{
		C()
		{
			System.out.println("class B");
		}
	}
	class D extends  C{
		D(){
			System.out.println("Class D");
		}
	}
public class InheritanceDemo3 {

	public static void main(String[] args) {
		new D();
		
	}

}
