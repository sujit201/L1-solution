package iodemo;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.text.ParseException;
public class CalenderDemo {

	public static void main(String[] args)throws Exception,ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("input");
		String s1=br.readLine();
		Date d=sdf.parse(s1);
		Calendar ca1=Calendar.getInstance();
		ca1.setTime(d);
		SimpleDateFormat sdf2=new SimpleDateFormat("MMM");
		String s2=sdf2.format(ca1.getTime());
		System.out.println(s2);
		}

}
