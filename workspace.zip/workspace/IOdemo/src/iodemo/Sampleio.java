package iodemo;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Sampleio {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		 int num=0, reversed = 0;
		
System.out.println("enter num");
num=Integer.parseInt(br.readLine());	    
while(num != 0) {
	            int digit = num % 10;
	            reversed = reversed * 10 + digit;
	            num=num/ 10;
	        }

	        System.out.println("Reversed Number: " + reversed);
		
	}

}
