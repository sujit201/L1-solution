/**
 * 
 */
/**
 * @author 760331
 *
 */
package iodemo;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Sample6 {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
int n;
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(isr);
System.out.println("enter number");
n=Integer.parseInt(br.readLine());