package iodemo;
class A
{
  A()
{
		System.out.println("class A");
	}
}
class C extends A{
	C()
	{
		System.out.println("class B");
	}
}
class D extends  C{
	D(){
		System.out.println("Class D");
	}
}
public class InheritanceDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
new D();
	}
}
