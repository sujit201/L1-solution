package iodemo;

public class Character1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer i=7;
char ch='a';
Character obj=ch;
char ch3=obj;
	}

}

