package iodemo;
class Demo1{
	int a=4,b=3;
	void disp(){
		System.out.println("Ans :"+(a+b));
	}
}
class Demo2 extends Demo1{
	int a=10,b=20;
	Demo2(){
		System.out.println(a+b);
		System.out.println("using super"+(super.a+super.b));
	disp();
	}
}
public class InheritanceDemo1 {

	public static void main(String[] args) {
new Demo2();
	}

}
