package iodemo;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Iodemo1 {

	public static void main(String[] args) throws Exception{
				// TODO Auto-generated method stub
		int n=0,remainder,sum=0;
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("enter number");
		n=Integer.parseInt(br.readLine());
		int n1=n;
		while (n != 0)
        {
            remainder = n% 10;
            sum=(remainder*remainder*remainder)+sum;
            n=n/ 10;
        }

        if(sum == n1)
            System.out.println(" is an Armstrong number.");
        else
            System.out.println(" is not an Armstrong number.");
	}

}
