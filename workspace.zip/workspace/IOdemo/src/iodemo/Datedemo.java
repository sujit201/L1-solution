package iodemo;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Datedemo {

	public static void main(String[] args )throws Exception {
		// TODO Auto-generated method stub
		Date d=new Date();
		System.out.println(d);
		String strDate="16/1/2019";
		SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
		Date d1=sdf.parse(strDate);
		String str=sdf.format(d1);
		System.out.println(d1);

	}

}
