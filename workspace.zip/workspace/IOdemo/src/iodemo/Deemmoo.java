package iodemo;
		class A
		{
			A()
			{
				System.out.println("Zero para");
			}
			A(int a)
			{
				System.out.println("one int para");
			}
			A(String a)
			{
				System.out.println("one String para");
			}
			A(String a,int n)
			{
				System.out.println("one string and one int para");
			}
			
		}
		public class Deemmoo {

			public static void main(String[] args) {
			new A("kiran",25);
			new A("kiran");
			new A(25);
			new A();

			}

		
	}


