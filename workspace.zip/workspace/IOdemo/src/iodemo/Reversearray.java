package iodemo;

public class Reversearray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		int arr[]={10,2,3,4};
        for(int a:arr){
        	System.out.println(a);
        }
        System.out.println();
        System.out.println("-----------------");
        for(i=0;i<arr.length;i++)
        {
        	System.out.println(i+" "+arr[i]);
        }
        System.out.println("reverse order");
        for(i=arr.length-1;i>=0;i--){
        	System.out.println(i+" "+arr[i]);
        }
        System.out.println("reverse elements");
        int tmp;
        for(i=0,j=arr.length-1;i<j;i++,j--){
        	tmp=arr[i];
        	arr[i]=arr[j];
        	arr[j]=tmp;
        }
        System.out.println("-------");
        for(i=0;i<arr.length;i++){
        	System.out.println(i+" "+arr[i]);
        }
	}

}
