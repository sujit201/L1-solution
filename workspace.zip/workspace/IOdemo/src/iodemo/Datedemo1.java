package iodemo;

import java.util.Date;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Datedemo1 {

	public static void main(String[] args )throws ParseException, IOException {
		// TODO Auto-generated method stub
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("enter date from user");
	String s1=br.readLine();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
		
				Date d=sdf.parse(s1);
				SimpleDateFormat sdf2=new SimpleDateFormat("dd-mm-yyyy");
				System.out.println(sdf2.format(d));

			}

		


	}

