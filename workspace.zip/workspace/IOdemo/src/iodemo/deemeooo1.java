package iodemo;
class B
{
	void disp()
	{
		System.out.println("Zero para");
	}
	void disp(int a)
	{
		System.out.println("one int para");
	}
	void disp(String a)
	{
		System.out.println("one String para");
	}
	void disp(String b,int a)
	{
		System.out.println("two para");
	}
	
}
public class deemeooo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
B obj1=new B();
obj1.disp(10);
obj1.disp("sss");
obj1.disp();
obj1.disp("dd",10);
	}

}
