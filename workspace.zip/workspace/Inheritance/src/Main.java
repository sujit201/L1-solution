import java.text.DecimalFormat;
import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	DecimalFormat df=new DecimalFormat(".00");
	System.out.println("Circle");
	System.out.println("Square");
	System.out.println("Rectangle");
	System.out.println("Enter the shape name");
String nm=sc.nextLine();

if(nm.equalsIgnoreCase("Circle"))
{
	System.out.println("Enter the radius");
	int r=sc.nextInt();
	Circle c=new Circle(nm, r);
	System.out.println("Area of "+c.getName()+" is "+df.format(c.calculateArea()));
}

if(nm.equalsIgnoreCase("Square"))
{
	System.out.println("Enter the side");
	int s=sc.nextInt();
	Square sq=new Square(nm, s);
	System.out.println("Area of "+sq.getName()+" is "+df.format(sq.calculateArea()));
}

if(nm.equalsIgnoreCase("Rectangle"))
{
	System.out.println("Enter the length");
	int l=sc.nextInt();
	
	System.out.println("Enter the breadth");
	int b=sc.nextInt();
	Rectangle rec=new Rectangle(nm, l, b);
	System.out.println("Area of "+rec.getName()+" is "+df.format(rec.calculateArea()));
}


}
}
