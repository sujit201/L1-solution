import java.util.ArrayList;

import java.util.Collections;

import java.util.HashSet;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Please provide the number of  players");

		int a=sc.nextInt();

		

		ArrayList<Ranking> h=new ArrayList<>();

		for(int i=0;i<a;i++)

		{

			sc.nextLine();

			System.out.println("Enter the name of the player "+(i+1));

			String name=sc.nextLine();

			System.out.println("Enter the score of the player "+(i+1));

			int b=sc.nextInt();

	

			h.add(new Ranking(name,b));

		}

		System.out.println("Player Details by Score(High to Low)");

		Collections.sort(h);

		int j=1;

		Iterator<Ranking> itr=h.iterator();

		while(itr.hasNext())

		{

			System.out.print(j+" ");

			System.out.print(itr.next());

			System.out.println();

			j++;

		}



	}



}