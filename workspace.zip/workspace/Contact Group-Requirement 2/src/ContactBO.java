import java.util.ArrayList;

import java.util.Date;

import java.util.Iterator;

import java.util.List;

public class ContactBO {

	public List<Contact> findContact(List<Contact> contactList,List<String> name){

		Iterator<Contact> itr=contactList.iterator();

		List<Contact> cont=new ArrayList<Contact>();

		while(itr.hasNext())

		{

			Contact contact=itr.next();

			Iterator<String> str=name.iterator();

			while(str.hasNext())

			{

				if(str.next().equals(contact.getName()))

					cont.add(contact);

			}

		}

		return cont;

	}

	public List<Contact> findContact(List<Contact> contactList,Date dateCreated){

		Iterator<Contact> itr=contactList.iterator();

		List<Contact> cont=new ArrayList<Contact>();

		while(itr.hasNext())

		{

			Contact contact=itr.next();

			if(contact.getDateCreated().equals(dateCreated))

					cont.add(contact);

		}

		return cont;

	}

	public List<Contact> findContact(List<Contact> contactList,String emailDomain){

		Iterator<Contact> itr=contactList.iterator();

		List<Contact> cont=new ArrayList<Contact>();

		while(itr.hasNext())

		{

			Contact contact=itr.next();

			if(contact.getEmail().contains(emailDomain))

					cont.add(contact);

		}

		return cont;

	}

}