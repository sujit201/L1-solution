
public class Shape {
 protected String shapeName;
 public String getShapeName() {
 return shapeName;
 }
 public void setShapeName(String shapeName) {
 this.shapeName = shapeName;
 }
 public Shape(String shapeName) {
 this.shapeName = shapeName;
 }
 public double calculateArea()
 {
 return 0;
 }
}











