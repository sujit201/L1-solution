import java.text.DecimalFormat;
import java.util.Scanner;
class Main
{
 public static void main(String args[])
 {
 DecimalFormat df=new DecimalFormat("0.00");
 Scanner sc=new Scanner(System.in);
 System.out.println("1. Rectangle\n2. Square\n3. Circle");
 System.out.println("Area Calculator --- Choose your shape");
 int n=sc.nextInt();
 Shape s;
 switch(n)
 {
 case 1:s=new Shape("Rectangle");
  System.out.println("Enter length and breadth:");
    int length=sc.nextInt();
    int breadth=sc.nextInt();
    Rectangle r=new Rectangle(length, breadth);
  System.out.printf("Area of "+s.getShapeName()+" is:%.2f",r.calculateArea());
  break;
 case 2:s=new Shape("Square");
  System.out.println("Enter side:");
    int side=sc.nextInt();
  Square sq=new Square(side);
  System.out.printf("Area of "+s.getShapeName()+" is:%.2f",sq.calculateArea());
  break;
 case 3:s=new Shape("Circle");
  System.out.println("Enter Radius:");
     int radius=sc.nextInt();
  Circle c=new Circle(radius);
  System.out.printf("Area of "+s.getShapeName()+" is:%.2f",c.calculateArea());
  break;
 }
 }
}