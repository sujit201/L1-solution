public class WicketKeeper extends CricketPlayer implements IPlayerStatistics

{

  private int noOfCatches;

  private int noOfStumpings;

  private int runs;

  private int noOfDismissals;

   

  public WicketKeeper(String name,String teamName,int noOfMatches,int noOfCatches,int noOfStumpings,int runs,int noOfDismissals)

  {

    super(name,teamName,noOfMatches);

    this.noOfCatches=noOfCatches;

    this.noOfStumpings=noOfStumpings;

    this.runs=runs;

    this.noOfDismissals=noOfDismissals;

  }

   

  public int getNoOfCatches()

  {

    return noOfCatches;

  }

   

  public int getNoOfStumpings()

  {

    return noOfStumpings;

  }

   

  public int getRuns()

  {

    return runs;

  }

   

  public int getNoOfDismissals()

  {

    return noOfDismissals;

  }

   

   public void displayPlayerStatistics()

  {

    System.out.println("Player name : "+this.getName());

    System.out.println("Team name : "+this.getTeamName());

    System.out.println("No of matches : "+this.getNoOfMatches());

    System.out.println("No of catches taken : "+this.getNoOfCatches());

    System.out.println("No of stumpings : "+this.getNoOfStumpings());

    System.out.println("No of dismissals : "+this.getNoOfDismissals());

    System.out.println("Runs scored : "+this.getRuns());

  }

}

