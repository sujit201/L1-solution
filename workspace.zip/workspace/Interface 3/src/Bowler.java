public class Bowler extends CricketPlayer implements IPlayerStatistics

{

  private int noOfWickets;

   

  public Bowler(String name,String teamName,int noOfMatches,int noOfWickets)

  {

    super(name,teamName,noOfMatches);

    this.noOfWickets=noOfWickets;

  }

   

  public int getNoOfWickets()

  {

    return noOfWickets;

  }

   

  public void displayPlayerStatistics()

  {

    System.out.println("Player name : "+this.getName());

    System.out.println("Team name : "+this.getTeamName());

    System.out.println("No of matches : "+this.getNoOfMatches());

    System.out.println("No of wickets taken : "+getNoOfWickets());

  }

}