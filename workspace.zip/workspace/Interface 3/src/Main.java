import java.util.Scanner;

public class Main

{

  public static void main(String args[])

  {

    String name,team;

    int noOfMatches,noOfWickets,runs,noOfCatches,noOfStumpings,noOfDismissals;

    Scanner sc=new Scanner(System.in);

    boolean flag=true;

    boolean flagTwo=false;

    while(flag)

    {

    flagTwo=false;

    System.out.println("Menu");

    System.out.println("1.Bowler");

    System.out.println("2.Batsman");

    System.out.println("3.WicketKeeper");

    System.out.println("4.AllRounder");

    System.out.println("Enter your choice");

    int choice=sc.nextInt();

//    sc.nextLine();

    switch(choice)

    {

      case 1: sc.nextLine();

          System.out.println("Enter the Bowler details");

          System.out.println("Enter player name");

          name=sc.nextLine();

          System.out.println("Enter team name");

          team=sc.nextLine();

          System.out.println("Enter number of matches played");

          noOfMatches=sc.nextInt();

          System.out.println("Enter number of wickets taken");

          noOfWickets=sc.nextInt();

          Bowler b=new Bowler(name,team,noOfMatches,noOfWickets);

          b.displayPlayerStatistics();

          break;

           

      case 2: sc.nextLine();

          System.out.println("Enter the Batsman details");

          System.out.println("Enter player name");

          name=sc.nextLine();

          System.out.println("Enter team name");

          team=sc.nextLine();

          System.out.println("Enter number of matches played");

          noOfMatches=sc.nextInt();

          System.out.println("Enter the runs scored");

          runs=sc.nextInt();

          Batsman bat=new Batsman(name,team,noOfMatches,runs);

          bat.displayPlayerStatistics();

          break;

           

      case 3: sc.nextLine();

          System.out.println("Enter the WicketKeeper details");

          System.out.println("Enter player name");

          name=sc.nextLine();

          System.out.println("Enter team name");

          team=sc.nextLine();

          System.out.println("Enter number of matches played");

          noOfMatches=sc.nextInt();

          System.out.println("Enter number of catches taken");

          noOfCatches=sc.nextInt();

          System.out.println("Enter number of stumpings");

          noOfStumpings=sc.nextInt();

          System.out.println("Enter number of dismissals");

          noOfDismissals=sc.nextInt();

          System.out.println("Enter the runs scored");

          runs=sc.nextInt();

          WicketKeeper w=new WicketKeeper(name,team,noOfMatches,noOfCatches,noOfStumpings,runs,noOfDismissals);

          w.displayPlayerStatistics();

          break;

           

      case 4: sc.nextLine();

          System.out.println("Enter the AllRounder details");

           System.out.println("Enter player name");

          name=sc.nextLine();

          System.out.println("Enter team name");

          team=sc.nextLine();

          System.out.println("Enter number of matches played");

          noOfMatches=sc.nextInt();

          System.out.println("Enter the runs scored");

          runs=sc.nextInt();

          System.out.println("Enter number of wickets taken ");

          noOfWickets=sc.nextInt();

          AllRounder a=new AllRounder(name,team,noOfMatches,runs,noOfWickets);

          a.displayPlayerStatistics();

          break;

       

      default: System.out.println("Please Enter a Valid Input");

           flagTwo=true;

    }

    if(flagTwo)

    {

      flag=true;

    }

    else

    {

    System.out.println("Do you want to continue?");

    sc.nextLine();

    String cc=sc.nextLine();

    if(cc.equalsIgnoreCase("yes"))

      flag=true;

    else

      flag=false;

    }

    }

  }

}