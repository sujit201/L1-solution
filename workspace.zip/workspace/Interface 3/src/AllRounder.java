public class AllRounder extends CricketPlayer implements IPlayerStatistics

{

  private int runs;

  private int noOfWickets;

   

  public AllRounder(String name,String teamName,int noOfMatches,int runs,int noOfWickets)

  {

    super(name,teamName,noOfMatches);

    this.runs=runs;

    this.noOfWickets=noOfWickets;

  }

   

  public int getRuns()

  {

    return runs;

  }

   

  public int getNoOfWickets()

  {

    return noOfWickets;

  }

   

  public void displayPlayerStatistics()

  {

    System.out.println("Player name : "+this.getName());

    System.out.println("Team name : "+this.getTeamName());

    System.out.println("No of matches : "+this.getNoOfMatches());

    System.out.println("Runs scored : "+this.getRuns());

    System.out.println("No of wickets taken : "+this.getNoOfWickets());

  }

}