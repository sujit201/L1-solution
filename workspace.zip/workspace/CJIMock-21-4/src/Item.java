import java.text.DecimalFormat;

public class Item implements Comparable<Item>{
	
	private String name;
	private Double price;
	private String type;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(String name, Double price, String type) {
		super();
		this.name = name;
		this.price = price;
		this.type = type;
	}
	
	static Item createItem(String detail)
	{
		String[] array = detail.split(",");
		return new Item(array[0],Double.parseDouble(array[1]),array[2]);
	}
	@Override
	public int compareTo(Item item) {
		return this.name.compareToIgnoreCase(item.name);
	}
	
	public String toString()
	{
		DecimalFormat df = new DecimalFormat("#0.0");
		return String.format("%-20s %-10s %-12s",name,df.format(price),type);
		
	}
}
