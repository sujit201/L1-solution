import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class Main {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of items:");
		int n = sc.nextInt();
		List<Item> itemList = new ArrayList<Item>();
		sc.nextLine();
		for(int i=0;i<n;i++)
		{
			String detail = sc.nextLine();
			itemList.add(Item.createItem(detail));
		}
		System.out.println("Enter a type to sort:\n1.Sort by Name\n2.Sort by Price");
		int choice = sc.nextInt();
		if(choice==1)
		{
			Collections.sort(itemList);
			System.out.format("%-20s %-10s %-12s\n","Name","Price","Type");
			for(Item item:itemList)
			{
				System.out.println(item.toString());
			}
			
		}
		else if(choice==2)
		{
			Collections.sort(itemList,new PriceComparator());
			System.out.format("%-20s %-10s %-12s\n","Name","Price","Type");
			for(Item item:itemList)
			{
				System.out.println(item.toString());
			}
		}
	}
}
