import java.text.DecimalFormat;

public class Cab {
private String driverName,registrationNumber,vehicleType;
private int capacity;
private double costPerKm;

DecimalFormat df=new DecimalFormat("#0.0");
public String getDriverName() {
	return driverName;
}
public void setDriverName(String driverName) {
	this.driverName = driverName;
}
public String getRegistrationNumber() {
	return registrationNumber;
}
public void setRegistrationNumber(String registrationNumber) {
	this.registrationNumber = registrationNumber;
}
public String getVehicleType() {
	return vehicleType;
}
public void setVehicleType(String vehicleType) {
	this.vehicleType = vehicleType;
}
public int getCapacity() {
	return capacity;
}
public void setCapacity(int capacity) {
	this.capacity = capacity;
}
public double getCostPerKm() {
	return costPerKm;
}
public void setCostPerKm(double costPerKm) {
	this.costPerKm = costPerKm;
}
Cab(){}
Cab(String driverName,String registrationNumber,String vehicleType,int capacity,double costPerKm)
{
	this.driverName=driverName;
	this.registrationNumber=registrationNumber;
	this.vehicleType=vehicleType;
	this.capacity=capacity;
	this.costPerKm=costPerKm;
}
public String toString()

{

	return String.format("%-12s %-20s %-12s %-8s %s\n",driverName,registrationNumber,vehicleType,capacity,df.format(costPerKm));



}
}
