import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args){

		//Your code goes here...

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of cabs:");

		//Your code goes here...

		int n=sc.nextInt();

		sc.nextLine();

		List <Cab> l=new ArrayList<Cab>();

		for(int i=0;i<n;i++)

		{

			String s=sc.nextLine();

			String a[]=s.split(",");

			Cab ii=new Cab(a[0],a[1],a[2],Integer.valueOf(a[3]),Double.valueOf(a[4]));

			l.add(ii);

		}

		CabBO b=new CabBO();

		

		System.out.println("Enter a search type:\n1.By Vehicle Type\n2.By Capacity");

		int x=sc.nextInt();

		//sc.nextLine();

		   if(x==1)

			{

				System.out.println("Enter the Vehicle Type:");

				sc.nextLine();

				String sa=sc.nextLine();

				//System.out.format("%-20s %-5s %s\n","Name","Price","Type");

				List<Cab> a=b.findCab(l,sa);

				//System.out.println("Enter a search type:\n1.By Type\n2.By Price");

				if(a.isEmpty())

				{

					System.out.println("No such cab is present");

				}

				else

				{

					System.out.format("%-12s %-20s %-12s %-8s %s\n","Driver Name","Registration Number","Vehicle Type","Capacity","Cost Per Km");
				for(int i=0;i<a.size();i++)

				{

					System.out.print(a.get(i).toString());

				}

				}

			}

		   else if(x==2)

			{

		  	 sc.nextLine();

				System.out.println("Enter the Capacity:");

				int d=sc.nextInt();

				

				List <Cab> a=b.findCab(l,d);

				if(a.isEmpty())

				{

					System.out.println("No such cab is present");

				}

				else

				{System.out.format("%-12s %-20s %-12s %-8s %s\n","Driver Name","Registration Number","Vehicle Type","Capacity","Cost Per Km");

				for(int i=0;i<a.size();i++)

				{

					System.out.print(a.get(i).toString());

				}

				}

			}

		   else	

		   {

		   System.out.println("Invalid choice");

		   }

		    

					

		}

	

  	}

