
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     int lwr=sc.nextInt();
     int upr=sc.nextInt();
     int x,y,n=0,a,even=0,odd=0,m=0;
     if(upr>=lwr)
     {
     for(x=lwr;x<=upr;x++)
     {
     		 n=x;even=0;odd=0;
           while(n>0)
         {
        	   a=n%10;
        	   if(a%2==0 && even<=2 && a!=0)
        		   even++;
        	   if(a%2!=0 && odd<=2)
        		   odd++;
        	   n=n/10;
         }
        	   if(even==2 && odd==2)
               System.out.print(x+" ");
    		
      } }
     
	}

}
