import java.util.*;
public class ItemBO {
	public List<Item> findItem(List<Item> itemList,String type){
		//Your code goes here...
		List<Item> l=new ArrayList<Item>();
		for(int i=0;i<itemList.size();i++)
		{
			if(itemList.get(i).getType().equals(type))
			{
				l.add(itemList.get(i));
			}
			
		}
		return l;
	}
	
	public List<Item> findItem(List<Item> itemList,Double price){
		//Your code goes here...
		List<Item> l1=new ArrayList<Item>();
		for(int i=0;i<itemList.size();i++)
		{
			if(itemList.get(i).getPrice()==(price))
			{
				l1.add(itemList.get(i));
			}
			
		}
		return l1;
	 }
}
