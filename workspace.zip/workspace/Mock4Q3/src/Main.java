import java.util.*;

public class Main {

	public static void main(String[] args){

		//Your code goes here...

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of items:");

		//Your code goes here...

		int n=sc.nextInt();

		sc.nextLine();

		List <Item> l=new ArrayList<Item>();

		for(int i=0;i<n;i++)

		{

			String s=sc.nextLine();

			String a[]=s.split(",");

			Item ii=new Item(a[0],Double.valueOf(a[1]),a[2]);

			l.add(ii);

		}

		ItemBO b=new ItemBO();

		

		System.out.println("Enter a search type:\n1.By Type\n2.By Price");

		int x=sc.nextInt();

		//sc.nextLine();

		   if(x==1)

			{

				System.out.println("Enter the Type:");

				sc.nextLine();

				String sa=sc.nextLine();

				//System.out.format("%-20s %-5s %s\n","Name","Price","Type");

				List<Item> a=b.findItem(l,sa);

				//System.out.println("Enter a search type:\n1.By Type\n2.By Price");

				if(a.isEmpty())

				{

					System.out.println("No such item is present");

				}

				else

				{

					System.out.format("%-20s %-5s %s\n","Name","Price","Type");

				for(int i=0;i<a.size();i++)

				{

					System.out.print(a.get(i).toString());

				}

				}

			}

		   else if(x==2)

			{

		  	 sc.nextLine();

				System.out.println("Enter the Price:");

				double d=sc.nextDouble();

				

				List <Item> a=b.findItem(l,d);

				if(a.isEmpty())

				{

					System.out.println("No such item is present");

				}

				else

				{System.out.format("%-20s %-5s %s\n","Name","Price","Type");

				for(int i=0;i<a.size();i++)

				{

					System.out.print(a.get(i).toString());

				}

				}

			}

		   else	

		   {

		   System.out.println("Invalid choice");

		   }

		    

					

		}

	

  	}

