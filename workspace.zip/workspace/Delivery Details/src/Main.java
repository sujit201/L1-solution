import java.util.Scanner;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	long o,b,r;
	String bt,bw,ns;
	System.out.println("Enter the over");
	o=sc.nextLong();
	System.out.println("Enter the ball");
	b=sc.nextLong();
	System.out.println("Enter the runs");
	r=sc.nextLong();
	sc.nextLine();
	System.out.println("Enter the batsman name");
	bt=sc.nextLine();
	System.out.println("Enter the bowler name");
	bw=sc.nextLine();
	System.out.println("Enter the nonStriker name");
	ns=sc.nextLine();
	Delivery d=new Delivery();
	d.setOver(o);
	d.setBall(b);
	d.setRuns(r);
	d.setBatsman(bt);
	d.setBowler(bw);
	d.setNonStriker(ns);
System.out.println("Over : "+d.getOver());
System.out.println("Ball : "+d.getBall());
System.out.println("Runs : "+d.getRuns());
System.out.println("Batsman : "+d.getBatsman());
System.out.println("Bowler : "+d.getBowler());
System.out.println("NonStriker : "+d.getNonStriker());
}
}

