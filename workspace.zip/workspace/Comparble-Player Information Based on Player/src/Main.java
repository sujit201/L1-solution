import java.util.ArrayList;

import java.util.Collections;

import java.util.Iterator;

import java.util.Scanner;



public class Main {



	public static void main(String[] args)

	{

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter number of players:");

		int a=sc.nextInt();

		ArrayList<Player> ar=new ArrayList<>();

		for(int i=0;i<a;i++)

		{

			sc.nextLine();

			System.out.println("Enter player "+(i+1)+" detail");

			System.out.println("Enter Name");

			String name=sc.nextLine();

			System.out.println("Enter Skill");

			String name1=sc.nextLine();

			System.out.println("Enter Cap Number");

			long no=sc.nextLong();

			ar.add(new Player(name,name1,no));

			

			

		}

		Collections.sort(ar);

		Iterator<Player> i=ar.iterator();

		System.out.println("Player list after sorting by cap number in descending order");

		while(i.hasNext())

		{

			System.out.println(i.next());

		}



	}



}