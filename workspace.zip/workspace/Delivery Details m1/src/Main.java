import java.util.*;

public class Main {

public static void main(String args[])

{

	Scanner sc=new Scanner(System.in);

	

	System.out.println("Menu");

	System.out.println("1.Player details of the delivery");

	System.out.println("2.Run details of the delivery");

	int rishav=sc.nextInt();

	sc.nextLine();

	

	Delivery d=new Delivery();

	switch(rishav)

	{

	case 1:

		System.out.println("Enter the bowler name");

		String bowler=sc.nextLine();

		System.out.println("Enter the batsman name");

		String batsman=sc.nextLine();

		d.displayDeliveryDetails(bowler,batsman);

		break;

		

	case 2:

		System.out.println("Enter the number of runs");

		long runs=sc.nextInt();

		d.displayDeliveryDetails(runs);

		break;

	}

}

}

