import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String a,b;
	System.out.println("Enter venue1");
	a=sc.nextLine();
	System.out.println("Enter venue2");
	b=sc.nextLine();
	if(a.equalsIgnoreCase(b))
	{
		System.out.println("Both the venues are same.");
		
	}
	else
	{
		System.out.println("Both the venues are different.");
	}
}
}
