import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
int n,i;
n=sc.nextInt();
sc.nextLine();
ArrayList<String>r1=new ArrayList<String>();
for(i=0;i<n;i++){
	r1.add(sc.nextLine());

	}
do {
System.out.println("Menu");
System.out.println("1.Insert Players");
System.out.println("2.Delete Players");

int a;
a=sc.nextInt();
sc.nextLine();
switch(a) {
case 1:
	r1.add(sc.nextLine());
System.out.println("Player details after insertion");
for(i=0;i<r1.size();i++) {
	System.out.println(r1.get(i));
	
}
System.out.println("Do you want to continue");


break;
case 2:
	String s=sc.nextLine();
	r1.remove(s);
	System.out.println("Player details after deletion");
	for(i=0;i<r1.size();i++) {
		System.out.println(r1.get(i));
	}
	System.out.println("Do you want to continue");
	break;
}

	  
}
while(sc.next().equals("Yes"));

}
}
