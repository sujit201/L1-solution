import java.sql.*;

import java.util.*;

public class JDBCDemo1 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
	//Class.forName("com.mysql.jdbc.Driver");
		Properties p = new Properties();
		p.put("user","root");
		p.put("password","root");
		
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/JDBCDb";
	Connection con=DriverManager.getConnection(url,"root","root");
	Statement stat = con.createStatement();
	String sql = "create table student(id int primary key,name varchar(50),sal float)";
	try
	{
		stat.execute("DROP TABLE student");
	}
	catch(SQLException e)
	{
		System.out.println(e.getMessage());
	}
	stat.execute(sql);
	System.out.println("Table created successfully");
	stat.close();
	con.close();
	//ResultSet rs = stat.executeQuery(sql);
	//while(rs.next())
	//{
		
	//	int id=rs.getInt(1);
		//String name=rs.getString(2);
		//String dep = rs.getString(3);
		
		//System.out.println(id+" "+name+" "+dep);
	//}
}
}
