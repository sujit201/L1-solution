import java.text.DecimalFormat;





public class Ebook extends Book

{

	DecimalFormat df = new DecimalFormat("0.00");

	

	private String diskType;

	private double size;

	public String getDiskType() {

		return diskType;

	}

	public void setDiskType(String diskType) {

		this.diskType = diskType;

	}

	public double getSize() {

		return size;

	}

	public void setSize(double size) {

		this.size = size;

	}

	

	

	public Ebook(String name, String author, double price, String publication) {

		super(name, author, price, publication);

	}

	public Ebook(String name, String author, double price, String publication,

			String diskType, double size) {

		super(name, author, price, publication);

		this.diskType = diskType;

		this.size = size;

	}

	

	public void displayDetails()

	{

		System.out.println("Name of the book :"+getName());

		System.out.println("Author:"+getAuthor());

		System.out.println("Price:"+df.format(getPrice()));

		System.out.println("Publication:"+getPublication());

		System.out.println("Disk type:"+diskType);

		System.out.println("Size:"+df.format(size));

	

	}

	

	

}

