import java.text.DecimalFormat;





public class PrintedBook extends Book

{

	private int numOfPages;

	private String bindingType;

	private String paperType;

	

	DecimalFormat df = new DecimalFormat("0.00");

	

	public PrintedBook(String name, String author, double price,

			String publication) {

		super(name, author, price, publication);

	}





	public int getNumOfPages() {

		return numOfPages;

	}





	public void setNumOfPages(int numOfPages) {

		this.numOfPages = numOfPages;

	}





	public String getBindingType() {

		return bindingType;

	}





	public void setBindingType(String bindingType) {

		this.bindingType = bindingType;

	}





	public String getPaperType() {

		return paperType;

	}





	public void setPaperType(String paperType) {

		this.paperType = paperType;

	}





	public PrintedBook(String name, String author, double price,

			String publication, int numOfPages, String bindingType,

			String paperType) {

		super(name, author, price, publication);

		this.numOfPages = numOfPages;

		this.bindingType = bindingType;

		this.paperType = paperType;

	}

	

	public void displayDetails()

	{

		System.out.println("Name of the book :"+getName());

		System.out.println("Author:"+getAuthor());

		System.out.println("Price:"+df.format(getPrice()));

		System.out.println("Publication:"+getPublication());

		System.out.println("Number of Pages:"+numOfPages);

		System.out.println("Binding type:"+bindingType);

		System.out.println("Paper type:"+paperType);

	}

	

	

	



}