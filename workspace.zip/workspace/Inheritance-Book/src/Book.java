public class Book 

{



	private String name;

	private String author;

	private double price;

	private String publication;

	public Book() {

		super();

	}

	

	

	

	public String getName() {

		return name;

	}







	public void setName(String name) {

		this.name = name;

	}







	public String getAuthor() {

		return author;

	}







	public void setAuthor(String author) {

		this.author = author;

	}







	public double getPrice() {

		return price;

	}







	public void setPrice(double price) {

		this.price = price;

	}







	public String getPublication() {

		return publication;

	}







	public void setPublication(String publication) {

		this.publication = publication;

	}







	public Book(String name, String author, double price, String publication) {

		super();

		this.name = name;

		this.author = author;

		this.price = price;

		this.publication = publication;

	}

	

	public void displayDetails()

	{

		System.out.println("Name of the book :"+name);

		System.out.println("Author:"+author);

		System.out.println("Price:"+price);

		System.out.println("Publication:"+publication);

		

	}

}