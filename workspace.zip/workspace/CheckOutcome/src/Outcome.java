public class Outcome {

private String winnerTeam ,playerOfMatch;

private long score;

public String getWinnerTeam() {

	return winnerTeam;

}

public void setWinnerTeam(String winnerTeam) {

	this.winnerTeam = winnerTeam;

}

public String getPlayerOfMatch() {

	return playerOfMatch;

}

public void setPlayerOfMatch(String playerOfMatch) {

	this.playerOfMatch = playerOfMatch;

}

public long getScore() {

	return score;

}

public void setScore(long score) {

	this.score = score;

}

public boolean equals(Outcome o)

{

	boolean a = false;

	if(this.getWinnerTeam().equalsIgnoreCase(o.winnerTeam)&&this.getScore()==o.score&&this.getPlayerOfMatch().equalsIgnoreCase(o.playerOfMatch))

		return true;

	else

		return false;

}



}