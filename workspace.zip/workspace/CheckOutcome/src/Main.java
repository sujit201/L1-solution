import java.util.Scanner;



public class Main {



	public static void main(String[] args) {

		//TODO Auto-generated method stub

    Scanner sc = new Scanner(System.in);

    Outcome ot = new Outcome();

    System.out.println("Enter the outcome 1 details");

    System.out.println("Enter the winner team");

    ot.setWinnerTeam(sc.nextLine());

    System.out.println("Enter the score");

    ot.setScore(sc.nextLong());

    sc.nextLine();

    System.out.println("Enter the player of the match");

    ot.setPlayerOfMatch(sc.nextLine());

    System.out.println(ot.getWinnerTeam()+" --- "+ot.getScore()+" --- "+ot.getPlayerOfMatch());

    System.out.println("Enter the outcome 2 details");

    Outcome ot1 = new Outcome();

    System.out.println("Enter the winner team");

    ot1.setWinnerTeam(sc.nextLine());

    System.out.println("Enter the score");

    ot1.setScore(sc.nextLong());

    sc.nextLine();

    System.out.println("Enter the player of the match");

    ot1.setPlayerOfMatch(sc.nextLine());

    System.out.println(ot1.getWinnerTeam()+" --- "+ot1.getScore()+" --- "+ot1.getPlayerOfMatch());

   // Basic Logic 

   if(ot.equals(ot1))

  	 System.out.println("Both the outcome details are same.");

   else

  	 System.out.println("Both the outcome details are different.");

   // Basic Logic

    sc.close();

	}

}