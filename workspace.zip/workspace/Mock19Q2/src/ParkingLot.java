import java.util.*;



public class ParkingLot {

	private String name;

	private List<Vehicle> vehicleList = new ArrayList<Vehicle>();

	public void addVehicleToParkingLot(Vehicle vehicle){

		this.vehicleList.add(vehicle);

	}

	public Boolean removeVehicleFromParkingLot(String registrationNo){

		for(Vehicle v:this.vehicleList)

		{

			if(v.getRegistrationNo().equalsIgnoreCase(registrationNo))

			{

				return vehicleList.remove(v);

			}

		}

		return false;

	}

	public void displayVehicles(){

		

		if(vehicleList.isEmpty())

		{

			System.out.println("No vehicles to show");

			return;

		}

		System.out.println("Vehicles in "+this.name);

		System.out.format("%-15s %-10s %-12s %-7s %s\n","Registration No","Name","Type","Weight","Ticket No");

		for(Vehicle v:vehicleList)

		{

			System.out.format("%-15s %-10s %-12s %-7s %s\n",v.getRegistrationNo(),v.getName(),v.getType(),v.getWeight(),v.getTicket().getTicketNo());;

		}

	}

	public ParkingLot() {

		super();

		// TODO Auto-generated constructor stub

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public List<Vehicle> getVehicleList() {

		return vehicleList;

	}

	public void setVehicleList(List<Vehicle> vehicleList) {

		this.vehicleList = vehicleList;

	}

	public ParkingLot(String name, List<Vehicle> vehicleList) {

		super();

		this.name = name;

		this.vehicleList = vehicleList;

	}

	

	

}