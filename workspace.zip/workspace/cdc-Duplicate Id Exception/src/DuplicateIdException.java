
public class DuplicateIdException extends Exception{

	public DuplicateIdException(String s)



	{



		super (s);



	}

}
