import java.util.Collections;

import java.util.Scanner;

import java.util.StringTokenizer;

public class Main {



public static void main(String args[])



{



    Scanner sc=new Scanner(System.in);

	String s=sc.nextLine();

	

	StringTokenizer st=new StringTokenizer(s," ");

	 String s1[]=new String[st.countTokens()];

	

      for(int i=0;i<s1.length;i++)    	  

	{

		 s1[i]=st.nextToken();	

      		System.out.println(s1[i]);

	}

	

	

	 for(int i=s1.length-1;i>=0;i--)

	 {

		 System.out.print(s1[i]+" ");

	 }

	 

	 

	 

}



}

