import java.util.*;
import java.text.*;
public class Main {
public static void main(String args[]) throws Exception{
	Scanner sc=new Scanner(System.in);
	UserMainCode u=new UserMainCode();
	String s;
	s=sc.nextLine();
	u.displayDate(s);
}
}
