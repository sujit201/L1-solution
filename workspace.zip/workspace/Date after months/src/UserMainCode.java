import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode {
	
	public static void displayDate(String date)throws Exception {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date1 = sdf.parse(date);
		
		Calendar c = Calendar.getInstance();
		c.setTime(date1);
		c.add(Calendar.MONTH, 20);
		Date date2 = c.getTime();
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		String date4 = sdf2.format(date1);
		
		SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
		String date3 = sdf3.format(date2);
		
		System.out.println("20 months after "+date4+" will be "+date3);
		
	}

}
