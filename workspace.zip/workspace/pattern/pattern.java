import java.util.*;
public class pattern 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stubs
				int i,j;
				for(i=1;i<=5;i++)
				{
					for(j=1;j<=i;j++)
					{
						System.out.println(" " +j);
					}
				System.out.println(" ");	
				}
			}

}
