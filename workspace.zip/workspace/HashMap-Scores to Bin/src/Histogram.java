import java.util.HashMap;

import java.util.Map;



public class Histogram 

{

	private HashMap<Integer,Integer> bins;

	

	int count1=0;

	int count2=0;

	int count3=0;

	int count4=0;

	

	public void addScore(int b)

	{

		

		if(b>0 && b<=10)

 	  {

 	   count1++;

 		  bins.put(10,count1);

 	  }

 	  if(b>10 && b<=20)

 	  {

 		  count2++;

 		  bins.put(20,count2);

 	  }

 	  if(b>20 && b<=30)

 	  {

 		  count3++;

 		  bins.put(30,count3);

 	  }

 	  

 	  if(b>30 && b<=40)

 	  {

 		  count4++;

 		  bins.put(40,count4);

 	  }

 	 

	}

	

	public void displayHistogram()

	{

		for(Map.Entry m:bins.entrySet())

		{

			System.out.print(m.getKey()+":");

			for(int i=0;i<(int)m.getValue();i++)

			{

				System.out.print("*");

			}

			System.out.println();

		}

	}



	public HashMap<Integer, Integer> getBins() {

		return bins;

	}



	public void setBins(HashMap<Integer, Integer> bins) {

		this.bins = bins;

	}

	

	public Histogram() {

		// TODO Auto-generated constructor stub

	}



}