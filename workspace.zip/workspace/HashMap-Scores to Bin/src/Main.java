import java.util.HashMap;

import java.util.Map;

import java.util.Scanner;

import java.util.TreeMap;



public class Main {



	public static void main(String[] args) 

	{

    Scanner sc=new Scanner(System.in);

    TreeMap<Integer,Integer> h1=new TreeMap<>();

    int a=sc.nextInt();

    int count1=0;

    int count2=0;

    int count3=0;

    int count4=0;

/*    Histogram h1=new Histogram();*/

    for(int i=0;i<a;i++)

    {

  	  int b=sc.nextInt();

  	  if(b>0 && b<=10)

   	  {

   	   count1++;

   		  h1.put(10,count1);

   	  }

   	  if(b>10 && b<=20)

   	  {

   		  count2++;

   		  h1.put(20,count2);

   	  }

   	  if(b>20 && b<=30)

   	  {

   		  count3++;

   		  h1.put(30,count3);

   	  }

   	  

   	  if(b>30 && b<=40)

   	  {

   		  count4++;

   		  h1.put(40,count4);

   	  }

  	  

    

    }

    System.out.println("Histogram");

    for(Map.Entry m:h1.entrySet())

    {

  	  System.out.print(m.getKey()+" : ");

  	  for(int i=0;i<(int)m.getValue();i++)

  	  {

  		  System.out.print("*");

  	  }

  	  System.out.println();

    }

    



	}



}