import java.util.Date;



public class Customer 

{

	private long id;

	private String name;

	private char gender;

	private String mail;

	private String contactNumber;

	private Date createdOn;

	public Customer() {

		// TODO Auto-generated constructor stub

	}

	public Customer(long id, String name, char gender, String mail, String contactNumber, Date createdOn) {

		super();

		this.id = id;

		this.name = name;

		this.gender = gender;

		this.mail = mail;

		this.contactNumber = contactNumber;

		this.createdOn = createdOn;

	}

	public long getId() {

		return id;

	}

	public void setId(long id) {

		this.id = id;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public char getGender() {

		return gender;

	}

	public void setGender(char gender) {

		this.gender = gender;

	}

	public String getMail() {

		return mail;

	}

	public void setMail(String mail) {

		this.mail = mail;

	}

	public String getContactNumber() {

		return contactNumber;

	}

	public void setContactNumber(String contactNumber) {

		this.contactNumber = contactNumber;

	}

	public Date getCreatedOn() {

		return createdOn;

	}

	public void setCreatedOn(Date createdOn) {

		this.createdOn = createdOn;

	}

	public String toString()

	{

		return("Customer: "+name+"\nCustomer contact details:"+contactNumber+", "+mail);

	}

	public boolean equals(Customer c1)

	{

		if((this.mail).equals(c1.mail) && (this.contactNumber).equals(c1.contactNumber))

		{

			return(true);

		}

		else

			return(false);

	}

	

}