 

public class MatchBO {

  

	public Match createMatch(String data, Venue[] venueList)

{

 String s[]=data.split(",");

 

 Match m=new Match();

 

 for(int i=0;i<venueList.length;i++)

{

 if(venueList[i].getName().equals(s[3]))

{

 m=new Match(s[0], s[1], s[2], venueList[i]);

}

}

 return m;

}



	public void findVenue(String matchDate, Match[] matchList)

{

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].getDate().equals(matchDate))

{

 System.out.println(matchList[i].venue.toString());

}

}

}



	public void findAllMatchesInGivenVenue(String venueName, Match[] matchList)

{

 System.out.println("Matches in venue "+venueName+" are\n"+String.format("%-15s%-15s%s","Date","TeamOne","TeamTwo"));

 

 for(int i=0;i<matchList.length;i++)

{

 if(matchList[i].venue.getName().equals(venueName))

{

 System.out.println(matchList[i].toString());

}

}

}

}



