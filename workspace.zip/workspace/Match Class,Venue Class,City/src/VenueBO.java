public class VenueBO {
public Venue createVenue(String data,City[] cityList)
{
Venue v=new Venue();
 String s[]=data.split(",");
for(int i=0;i<cityList.length;i++)
{
if(cityList[i].getName().equals(s[1]))
{
v=new Venue(s[0], cityList[i]);
}
}
return v;
}
}