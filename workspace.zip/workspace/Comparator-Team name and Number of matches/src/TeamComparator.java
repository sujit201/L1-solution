import java.util.Comparator;



public class TeamComparator implements Comparator{



	public int compare(Object o1,Object o2) {

		Team t=(Team)o1;

		Team t1=(Team)o2;

		if(t.getNumberOfMatches()>t1.getNumberOfMatches())

			return 1;

		else if(t.getNumberOfMatches()==t1.getNumberOfMatches())

			return 0;

		else 

			return -1;

	}



	

	}







