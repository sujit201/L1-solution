package myfirstproject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class FileinputstreamDemo2 {

	public static void main(String[] args)throws Exception {
		File f=new File("d:\\abcde.txt");
		FileOutputStream f=new FileOutputStream(f);
		String s1="hello from ss";
		byte 
		
		
		
	}

}
