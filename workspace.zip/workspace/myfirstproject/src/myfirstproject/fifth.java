package myfirstproject;

import java.util.Scanner;

public class fifth {
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	int a=sc.nextInt();
	int b=sc.nextInt();
	if(a>b){
		System.out.println("a is greater than b");
	}
	else if(a==b)
	{
		System.out.println("given numbers are equal");
	}
	else
	{
		System.out.println("b is greater than a");
		}
}
}
