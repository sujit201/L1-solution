package myfirstproject;

public class second {
public static void main(String args[]){
int a,b;
a=Integer.parseInt(args[0]);
b=Integer.parseInt(args[1]);
if(a>b){
	System.out.println("a is greater than b");
}
else{
	System.out.println("a is less than b");
}
}
}