package myfirstproject;

public class four {
public static void main(String[] args){
	char ch='h';
	if(ch>=65 && ch<=90)
	{
		System.out.println("upper");
	}
	else if(ch>=97 && ch<=122)
	{
		System.out.println("lower");
	
	}
	else if(ch>=48 && ch<=57)
	{
		System.out.println("digit");
		
	}
	else
	{
		ch='#';
		System.out.println("special character" +ch);
	}
}


}
