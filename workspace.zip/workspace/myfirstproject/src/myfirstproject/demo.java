package myfirstproject;

import java.util.Scanner;

public class demo {
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("input");
	int a=sc.nextInt();
	float f=sc.nextFloat();
	double d=sc.nextDouble();
}
}
