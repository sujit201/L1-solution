package myfirstproject;

import java.util.Scanner;

public class thirdscanner {
	public static void main(String[] args)
{
	int max;
	Scanner sc=new Scanner(System.in);
			System.out.println("enter number");
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	if(a>b && a>c){
		max=a;
			System.out.println("a=" +max+ "is max");
			
		}
		else if(b>a && b>c){
			max=b;
				System.out.println("b=" +max+ "is max");
				}
			else{
				max=c;
				System.out.println("c="   +max+ "is max" );
			}
		}
		
}

