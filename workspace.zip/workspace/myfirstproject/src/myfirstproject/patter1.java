import java.util.Scanner;
package myfirstproject;

public class patter1 {
	public static void main(String[] args){
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of lines");
		int rows=sc.nextInt();
		for(i=1;i<=5;i++){
			for(j=1;j<=i;j--)
			{
				System.out.println(" " +j+ " " +i);
			}
		System.out.println(" ");	
		}
	}

}
