import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.util.ArrayList;

import java.util.List;

 

public class Main {

    public static void main(String args[]) throws NumberFormatException, IOException, ParseException{

         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

         List<Movie> movies=new ArrayList<Movie>();

         Movie m=new Movie();

         System.out.println("Enter the number of movies:");

        int n=Integer.parseInt(br.readLine());

        for(int i=0;i<n;i++)

        {

          String s=br.readLine();

          Movie m1=m.createMovie(s);

          movies.add(m1);

        }

        List<Movie> al=new ArrayList<Movie>();

        al=Movie.getTopFilms(movies);

        System.out.format("%-22s %-10s %-8s %s\n","Name","Box Office","Budget","Rating");

        for(Movie m2:al)

        {

       System.out.println(m2);

        

    }

    }

}