import java.text.DecimalFormat;

import java.text.ParseException;

import java.util.Collections;

import java.util.List;

 

public class Movie implements Comparable<Movie>{

    private String name;

    private Double boxoffice;

    private Double budget;

    private Double rating;

    public Movie() {

         super();

         // TODO Auto-generated constructor stub

    }

    public Movie(String name, Double boxoffice, Double budget, Double rating) {

         super();

         this.name = name;

         this.boxoffice = boxoffice;

         this.budget = budget;

         this.rating = rating;

    }

    public String getName() {

         return name;

    }

    public void setName(String name) {

         this.name = name;

    }

    public Double getBoxoffice() {

         return boxoffice;

    }

    public void setBoxoffice(Double boxoffice) {

         this.boxoffice = boxoffice;

    }

    public Double getBudget() {

         return budget;

    }

    public void setBudget(Double budget) {

         this.budget = budget;

    }

    public Double getRating() {

         return rating;

    }

    public void setRating(Double rating) {

         this.rating = rating;

    }

    

    public static List<Movie> getTopFilms(List<Movie> movieList){

         

         Collections.sort(movieList);

         Collections.reverse(movieList);

         List<Movie> al=movieList.subList(0, 5);

         return al;

    }

    public static Movie createMovie(String movie) throws ParseException{

         String[] s=movie.split(",");

         Movie m=new Movie(s[0],new Double(s[1]),new Double(s[2]),new Double(s[3]));

         return m;

    }

    @Override

    public int compareTo(Movie arg0) {

         

         return this.getRating().compareTo(arg0.getRating());

    }

    public String toString()

    {

         DecimalFormat d=new DecimalFormat("#.00");

         

         return String.format("%-22s %-10s %-8s %s",name,d.format(boxoffice),d.format(budget),d.format(rating));

    }

}