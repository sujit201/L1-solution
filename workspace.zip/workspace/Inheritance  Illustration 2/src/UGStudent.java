public class UGStudent extends Student{

private String degree;

private String stream;

public String getDegree() {

	return degree;

}

public void setDegree(String degree) {

	this.degree = degree;

}

public String getStream() {

	return stream;

}

public void setStream(String stream) {

	this.stream = stream;

}

UGStudent()

{

	

}

UGStudent(String n,String i, int a, double g, String add, String d, String s)

{

	this.name=n;

	this.id=i;

	this.age=a;

	this.grade=g;

	this.address=add;

	this.degree=d;

	this.stream=s;

}

Student st=new Student(name,id,age,grade,address);

public void display()

{

	super.display();

	System.out.println("Degree : "+ degree);

	System.out.println("Stream : "+ stream);

//	if(isPassed()==true)

//		System.out.println("Result : Pass");

//		else

//			System.out.println("Result : Fail");

}

public boolean isPassed()

{

	if(grade>70)

		return true;

	else

		return false;

}



}