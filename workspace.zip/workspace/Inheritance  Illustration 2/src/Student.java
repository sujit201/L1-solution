public class Student {



	

		// TODO Auto-generated method stub

protected String name;

protected String id;

protected int age;

protected double grade;

protected String address;

public String getName() {

	return name;

}

public void setName(String name) {

	this.name = name;

}

public String getId() {

	return id;

}

public void setId(String id) {

	this.id = id;

}

public int getAge() {

	return age;

}

public void setAge(int age) {

	this.age = age;

}

public double getGrade() {

	return grade;

}

public void setGrade(double grade) {

	this.grade = grade;

}

public String getAddress() {

	return address;

}

public void setAddress(String address) {

	this.address = address;

}

Student(String n,String i, int a, double g, String add)

{

	this.name=n;

	this.id=i;

	this.age=a;

	this.grade=g;

	this.address=add;

}

Student()

{

	

}

public void display()

{

	//System.out.println("Student Details");

	System.out.println("Name : "+name);

	System.out.println("Id : "+ id);

	System.out.println("Age : "+ age);

	System.out.println("Grade : "+ grade);

	System.out.println("Address : "+ address);

//	if(isPassed()==true)

//		System.out.println("Result : Pass");

//		else

//			System.out.println("Result : Fail");

}

public boolean isPassed()

{

	if(grade>50) 



return true; 

 else

 return false;

}

}