import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int a,b,n,t,r,rev=0;
	a=sc.nextInt();
	b=sc.nextInt();
	for(n=a;n<=b;n++)
	{
		t=n;rev=0;
		while(t>0) {
			r=t%10;
			rev=rev*10+r;
			t=t/10;
		}
	
	if(n==rev) 
	System.out.print(n+" ");
}
}
}
