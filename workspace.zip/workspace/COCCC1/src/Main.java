import java.util.*;
public class Main {
    public static void main(String ghj[])
    {
    	Scanner in = new Scanner(System.in);
    	System.out.println("Enter the team details");
    	String hh = in.nextLine();
    	String hj[] = hh.split("#");
    	Team obn = new Team();
    	obn.setName(hj[0]);
    	obn.setCoach(hj[1]);
    	obn.setHome(hj[2]);
    	obn.setCaptain(hj[3]);
    	obn.setPlayers(hj[4]);
    	System.out.println("Team Detail");
    	System.out.println("Team : "+obn.getName());
    	System.out.println("Coach : "+obn.getCoach());
    	System.out.println("Home : "+obn.getHome());
    	System.out.println("Players : "+obn.getPlayers());
    	System.out.println("Captain : "+obn.getCaptain());
    }
}
