public class Team {
String name,coach,home,captain,players;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getCoach() {
	return coach;
}

public void setCoach(String coach) {
	this.coach = coach;
}

public String getHome() {
	return home;
}

public void setHome(String home) {
	this.home = home;
}

public String getCaptain() {
	return captain;
}

public void setCaptain(String captain) {
	this.captain = captain;
}

public String getPlayers() {
	return players;
}

public void setPlayers(String players) {
	this.players = players;
}

}
