import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

class Main

{

  public static void main(String ars[])throws IOException

  {

    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

    Person p=null;

    System.out.println("Enter the name:");

    String n=br.readLine();

    System.out.println("Enter the age:");

    int age=Integer.parseInt(br.readLine());

    System.out.println("Enter the address:");

    String add=br.readLine();

    System.out.println("Enter the phoneNumber:");

    String pn=br.readLine();

    System.out.println("Enter the department:");

    String d=br.readLine();

     

    System.out.println("Enter the type of person");

    System.out.println("1.Student");

    System.out.println("2.Staff");

    int c=Integer.parseInt(br.readLine());

    if(c==1)

    {

    	System.out.println("Enter the degree:");

    	String degree=br.readLine();

    	System.out.println("Enter the year:");

    	 int year=Integer.parseInt(br.readLine());

    	 System.out.println("Enter the id:");

    	 int id=Integer.parseInt(br.readLine());

    	//p=new Person(n,age,add,pn,d);

    	 Student st=new Student(n,age,add,pn,d,degree,year,id);

    	 System.out.println("Student Details");

    	 //p.displayDetails();

    	 st.displayDetails();

    }

    else if(c==2)

    {

    	System.out.println("Enter the specialization:");

    	String sp=br.readLine();

    	System.out.println("Enter the experience:");

    	 int exp=Integer.parseInt(br.readLine());

    	//p=new Person(n,age,add,pn,d);

    	 Staff st=new Staff(n,age,add,pn,d,sp,exp);

    	 System.out.println("Staff Details");

    	// p.displayDetails();	

    	 st.displayDetails();

    }

  }

}