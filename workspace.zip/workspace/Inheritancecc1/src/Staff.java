public class Staff extends Person {

	private String sp;

	private int exp;

	public String getSp() {

		return sp;

	}

	public void setSp(String sp) {

		this.sp = sp;

	}

	public int getExp() {

		return exp;

	}

	public void setExp(int exp) {

		this.exp = exp;

	}

	public Staff(String name, int age, String add, String pn, String d, String sp, int exp) {

		super(name, age, add, pn, d);

		this.sp = sp;

		this.exp = exp;

	}

	public void displayDetails()

	{

		System.out.println("Name :"+this.getName());

		System.out.println("Age :"+this.getAge());

		System.out.println("Address :"+this.getAdd());

		System.out.println("Phone :"+this.getPn());

		System.out.println("Department :"+this.getD());

		

		Person p=new Person();

		p.displayDetails();

		System.out.println("Specialization :"+this.getSp());

		System.out.println("Experience :"+this.getExp());	

	}	

}