public class Person {



	protected String name;

	protected int age;

	protected String add;

	protected  String pn;

	protected  String d;

	Person(){

		super();

	}

	public Person(String name, int age, String add, String pn, String d) {

		super();

		this.name = name;

		this.age = age;

		this.add = add;

		this.pn = pn;

		this.d = d;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public int getAge() {

		return age;

	}

	public void setAge(int age) {

		this.age = age;

	}

	public String getAdd() {

		return add;

	}

	public void setAdd(String add) {

		this.add = add;

	}

	public String getPn() {

		return pn;

	}

	public void setPn(String pn) {

		this.pn = pn;

	}

	public String getD() {

		return d;

	}

	public void setD(String d) {

		this.d = d;

	}

	

	public void displayDetails()

	{

		/*System.out.println("Name :"+this.getName());

		System.out.println("Age :"+this.getAge());

		System.out.println("Address :"+this.getAdd());

		System.out.println("Phone :"+this.getPn());

		System.out.println("Department :"+this.getD());*/

	}

}

