public class Student extends Person{



	private String degree;

	private int year;

	private int id;

	public String getDegree() {

		return degree;

	}

	public void setDegree(String degree) {

		this.degree = degree;

	}

	public int getYear() {

		return year;

	}

	public void setYear(int year) {

		this.year = year;

	}

	public int getId() {

		return id;

	}

	public void setId(int id) {

		this.id = id;

	}





	

	public Student(String name, int age, String add, String pn, String d, String degree, int year, int id) {

		super(name, age, add, pn, d);

		this.degree = degree;

		this.year = year;

		this.id = id;

	}

	public void displayDetails()

	{

		

		System.out.println("Name :"+this.getName());

		System.out.println("Age :"+this.getAge());

		System.out.println("Address :"+this.getAdd());

		System.out.println("Phone :"+this.getPn());

		System.out.println("Department :"+this.getD());

		

		

		System.out.println("Degree :"+this.getDegree());

		System.out.println("Year :"+this.getYear());

		System.out.println("Id :"+this.getId());

	}

}