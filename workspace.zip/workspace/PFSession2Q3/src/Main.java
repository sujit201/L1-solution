
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     int lwr=sc.nextInt();
     int upr=sc.nextInt();
     int x,y,n=0,a,m=0,z;
     if(upr>=lwr)
     {
     for(x=lwr;x<=upr;x++)
     {
    	 m=0;
     	for(y=1;y<x;y++)
     	{
    	 if(x%y==0)
    		 m+=y;
      		 
     	}
     	if(m<x)
     		System.out.print(x+" ");
      } 
     
      }
	}

}
