import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;

 

 

 

public class Main {

           public static void main(String[] args) throws NumberFormatException, IOException, ParseException

           {

                        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));      

                  System.out.println("Enter the number of movies");

                  int n = Integer.parseInt(br.readLine());

                  Movie m = new Movie();

                  Cast c = new Cast();

                  CastMovieAssignment cma = new CastMovieAssignment();

                  SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

                  List<Cast>castMovie= c.prefill();

                  List<CastMovieAssignment> castMovieAssignmentList = new ArrayList<CastMovieAssignment>();

                  int i,j;

                  for(i=0;i<n;i++)

                  {

                        String mov=br.readLine();

                        String[] s=mov.split(",");

                        m = new Movie(s[0], Double.parseDouble(s[1]), Double.parseDouble(s[2]), Double.parseDouble(s[2]),castMovieAssignmentList);

                        System.out.println("Enter the number of cast");

                        int n1 = Integer.parseInt(br.readLine());

                        for(j=0;j<n1;j++)

                        {

                              String cas=br.readLine();

                              String[] s1 = cas.split(",");

                              c = Cast.getCastObject(castMovie, s1[0]);

                              cma = new CastMovieAssignment(Double.parseDouble(s1[1]), s1[2], m, c);

                              c.addCastMovieAssignmentList(cma);

                                                         m.addCastMovieAssignmentList(cma);                            

                        }          

                  }

                  cma = c.getTopActor(castMovie);

                                   System.out.println("The top paid actor is " + cma.getCast().getName() + " for " + cma.getMovie().getName());

           } 

}