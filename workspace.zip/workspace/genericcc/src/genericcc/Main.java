import java.util.*;

public class Main 

{

  public static void main(String args[])

	{

		Scanner sc=new Scanner(System.in);

		List<String> l1=new ArrayList<>();

		List<String> l2=new ArrayList<>();

		System.out.println("Enter the top 5 raiders of PKL Season 3");

		for(int i=0;i<5;i++)

		{

			l1.add(sc.nextLine());

		}

		System.out.println("Enter the top 5 raiders of PKL Season 4");

		for(int i=0;i<5;i++)

		{

			l2.add(sc.nextLine());

		}

		l1.retainAll(l2);

    System.out.println("Best Raiders");

		for(String l:l1)

			System.out.println(l);

	}



}

