
 

import java.util.ArrayList;

import java.util.HashMap;

 

 

public class MemberCar {

 

private long id;

private Member member;

private Car car;

private String carRegistrationNumber,carColor;

public long getId() {

return id;

}

public void setId(long id) {

this.id = id;

}

public Member getMember() {

return member;

}

public void setMember(Member member) {

this.member = member;

}

public Car getCar() {

return car;

}

public void setCar(Car car) {

this.car = car;

}

public String getCarRegistrationNumber() {

return carRegistrationNumber;

}

public void setCarRegistrationNumber(String carRegistrationNumber) {

this.carRegistrationNumber = carRegistrationNumber;

}

public String getCarColor() {

return carColor;

}

public void setCarColor(String carColor) {

this.carColor = carColor;

}

public MemberCar(long id,  Car car,Member member,

String carRegistrationNumber, String carColor) {

super();

this.id = id;

this.member = member;

this.car = car;

this.carRegistrationNumber = carRegistrationNumber;

this.carColor = carColor;

}

public MemberCar() {

super();

// TODO Auto-generated constructor stub

}

public static MemberCar createInstance(String s,ArrayList<Member> memberList, ArrayList<Car> carList) {

String str[]=s.split(",");

Member member=null;

for(Member m:memberList){

if(m.getId()==Long.parseLong(str[1]))

member=m;

}

Car car=null;

for(Car c:carList){

if(c.getId()==Long.parseLong(str[2]))

car=c;

}

MemberCar mc=new MemberCar(Long.parseLong(str[0]), car, member, str[3], str[4]);

// TODO Auto-generated method stub

return mc;

}

public static HashMap<String, ArrayList<MemberCar>> groupByColor(ArrayList<MemberCar> memberCarList) {

HashMap<String, ArrayList<MemberCar>> map=new HashMap<>();

for(MemberCar mc:memberCarList){

String color=mc.getCarColor();

if(map.containsKey(color)){

ArrayList<MemberCar> list=map.get(color);

list.add(mc);

}

else{

ArrayList<MemberCar> list=new ArrayList<>();

list.add(mc);

map.put(color, list);

}

}

// TODO Auto-generated method stub

return map;

}

}

