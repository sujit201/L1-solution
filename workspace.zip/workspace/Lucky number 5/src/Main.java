import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b,n,i,c=0;
		a=sc.nextInt();
		b=sc.nextInt();
		for(n=a;n<=b;n++)
		{c=0;
			for(i=2;i<=n;i++)
			{
				if(n%i==0)
					c++;
			}
			if(c==2)
				System.out.print(n+" ");
		}

	}

}
