
public class PlayerBO 

{

	public void displayPlayerDetails(Player player)

{

 System.out.println("Player Details");

 

 System.out.println(player.toString());

}

}