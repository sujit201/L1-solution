import java.text.SimpleDateFormat;



import java.util.Calendar;



import java.util.Date;







public class UserMainCode {



   



	public static void displayDay(String date)throws Exception



	{



		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");



		SimpleDateFormat sdf1=new SimpleDateFormat("EEEEE");



		Date dt=sdf.parse(date);



		Calendar cal=Calendar.getInstance();



		cal.setTime(dt);



		cal.add(Calendar.YEAR, 2);



		dt=cal.getTime();



		System.out.println(sdf.format(dt));



		System.out.println(sdf1.format(dt));



		cal.add(Calendar.YEAR, -4);



		dt=cal.getTime();



		System.out.println(sdf.format(dt));



		System.out.println(sdf1.format(dt));



	}



}