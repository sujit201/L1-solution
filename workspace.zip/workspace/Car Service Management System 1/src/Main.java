import java.util.*;

public class Main {

public static void main(String arag[]){

	Scanner sc=new Scanner(System.in);

	

	

	Customer c[]=new Customer[2];

	

	for(int i=0;i<2;i++){

		System.out.println("Customer"+(i+1)+" :");

		System.out.println("customer id: ");

		long l=sc.nextLong();

		sc.nextLine();

		System.out.println("first name: ");

		String f=sc.nextLine();

		System.out.println("last name: ");

		String la=sc.nextLine();

		System.out.println("gender: ");

		String g=sc.nextLine();

		System.out.println("email: ");

		String e=sc.nextLine();

		System.out.println("phone number: ");

		String ph=sc.nextLine();

		System.out.println("address: ");

		String ad=sc.nextLine();

		 c[i]=new Customer(l,f,la,g,e,ph,ad);

		 

		

	}

	System.out.println("\nCustomer 1");

	System.out.println(c[0]+"\n");

	System.out.println("Customer 2");

	System.out.println(c[1]);

	if(c[0].equals(c[1])){

		System.out.println("Customer 1 is same as Customer 2");

		

	}

	else

		System.out.println("Customer 1 and Customer 2 are different");

	

	

	

}

}







