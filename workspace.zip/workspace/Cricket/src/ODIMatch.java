public class ODIMatch extends Match {









 

	float calculateRunrate()

{

 return (getTarget()-getCurrentScore())/(50-getCurrentOver());

}

 

	int calculateBalls() {





 return (int) (50-getCurrentOver())*6;



}

}