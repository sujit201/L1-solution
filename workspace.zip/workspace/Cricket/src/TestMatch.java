public class TestMatch extends Match {

  

	float calculateRunrate() {

 

 return (getTarget()-getCurrentScore())/(90-getCurrentOver());

}

 

	int calculateBalls() {

 

 return (int) (90-getCurrentOver())*6;

}





}



