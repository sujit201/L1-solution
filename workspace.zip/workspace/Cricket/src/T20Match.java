public class T20Match extends Match {

  

	float calculateRunrate() {

 

 return (getTarget()-getCurrentScore())/(20-getCurrentOver());

}

 

	int calculateBalls() {

 

 return (int) (20-getCurrentOver())*6;

}

}