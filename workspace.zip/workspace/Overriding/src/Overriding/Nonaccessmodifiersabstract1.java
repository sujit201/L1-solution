package Overriding;
abstract class demo2{
	abstract void disp();
}
class demo3 extends demo2
{
	void disp(){
		
	}
}
abstract class demo4 extends demo2{
	
}

public class Nonaccessmodifiersabstract1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
