import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	

	int i;
	System.out.println("Enter the number of innings");
	int n=sc.nextInt();
	String bt[]=new String[n];
	long r[]=new long[n];
	for(i=0;i<n;i++)
	{
		sc.nextLine();
		System.out.println("Enter the values for Innings "+(i+1));
		System.out.println("Enter the BattingTeam");
		bt[i]=sc.nextLine();
		System.out.println("Enter the runs scored");
		r[i]=sc.nextLong();
	}
	System.out.println("Innings Details");
	Innings c=new Innings();
	for(i=0;i<n;i++)
	{
		System.out.println("Innings "+(i+1));
		c.setBattingTeam(bt[i]);
		c.setRuns(r[i]);
		System.out.println(c.toString());
	}
}
}
