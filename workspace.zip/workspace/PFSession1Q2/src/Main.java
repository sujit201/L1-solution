
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		if(s%6==2 || s%6==5)
		{
			System.out.println("Yes");
		}
		else
		{
			System.out.println("No");
		}
		sc.close();
	}

}

