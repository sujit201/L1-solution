import java.util.*;

public class Main

{



	public static void main(String[] args) 

	{

		Scanner lol = new Scanner(System.in);

		System.out.println("Hotel Tariff Calculator");

		System.out.println("1. Deluxe Room\n2. Deluxe AC Room\n3. Suite AC Room\nSelect Room Type:");

		int a = lol.nextInt();

		lol.nextLine();

		System.out.println("Hotel Name:");

		String name = lol.nextLine();

		System.out.println("Room Square Feet Area:");

		Integer sf = lol.nextInt();

		lol.nextLine();

		System.out.println("Room has TV (yes/no):");

		String tv = lol.nextLine();

		boolean isTvAvailable=false;

		if(tv.equals("yes"))

			isTvAvailable = true;

		else

			isTvAvailable = false;

			

		System.out.println("Room has Wifi (yes/no):");

		String wifi = lol.nextLine();

		boolean isWifiAvailable=false;

		if(tv.equals("yes"))

			isWifiAvailable = true;

		else

			isWifiAvailable = false;

		DeluxeRoom d = new DeluxeRoom();

		DeluxeRoom dr = new DeluxeRoom(name,sf,isTvAvailable,isWifiAvailable,d.ratePerSqFeet);

		DeluxeACRoom dac = new DeluxeACRoom();

		SuiteACRoom sac =new SuiteACRoom();

		HotelRoom hr = new HotelRoom();

		

		if(a==1)

		System.out.println("Room Tariff per day is:"+(sf*dr.getRatePerSqFeet()));

		else if(a==2)

			System.out.println("Room Tariff per day is:"+(sf*dac.ratePerSqFeet));

		//else

			//System.out.println("Room Tariff per day is:"+(sf*d.hr.sac.ratePerSqFeet));



		

	}



}





