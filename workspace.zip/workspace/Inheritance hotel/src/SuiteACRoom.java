public class SuiteACRoom extends HotelRoom 

{

	private Integer ratePerSqFeet ;



	public Integer getRatePerSqFeet() 

	{

		if(hasWifi)

		return ratePerSqFeet+2;

		else

			return ratePerSqFeet;

	}



	public SuiteACRoom() {

		super();

	}



	public void setRatePerSqFeet(Integer ratePerSqFeet) {

		this.ratePerSqFeet = ratePerSqFeet;

	}

	

	public SuiteACRoom(Integer ratePerSqFeet)

	{

		super();

		this.ratePerSqFeet=15;

	}

}



