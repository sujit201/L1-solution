


public class DeluxeACRoom extends DeluxeRoom

{

	public DeluxeACRoom(Integer ratePerSqFeet)

	{

		this.ratePerSqFeet=12;

	}

	public DeluxeACRoom()

	{

		

	}

}