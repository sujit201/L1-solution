


public class DeluxeRoom extends HotelRoom 

{

	protected Integer ratePerSqFeet;

	

	public DeluxeRoom(String hotelName, Integer numberOfSqFeet, boolean hasTV, boolean hasWifi, Integer ratePerSqFeet) {

		super(hotelName, numberOfSqFeet, hasTV, hasWifi);

		this.ratePerSqFeet = 10;

	}



	public DeluxeRoom() {

		super();

	}

	

	public Integer getRatePerSqFeet() 

	{

		if(hasWifi==true){// System.out.println("HEllo");

		return ratePerSqFeet+2;}

		else{ //System.out.println("HI");

			return ratePerSqFeet;}

	}

	

	public void setRatePerSqFeet(Integer ratePerSqFeet) {

		this.ratePerSqFeet = ratePerSqFeet;

	}



	

}