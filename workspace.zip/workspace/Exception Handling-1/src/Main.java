import java.io.*;

import java.util.*;

public class Main {



	public static void main(String[] args)throws IOException {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		

		try

		{

			InputStreamReader rrr=new InputStreamReader(System.in);

			BufferedReader br=new BufferedReader(rrr);

			System.out.println("Enter the total runs scored");

			int r=Integer.parseInt(br.readLine());

			System.out.println("Enter the total overs faced");

			int o=Integer.parseInt(br.readLine());

			if(o==0)

			{

				throw new ArithmeticException();

			}

			float rr=(float)r/o;

			//System.out.println(r+" "+o);

			System.out.printf("Current Run Rate : %.2f",rr);

		}

		catch(Exception e)

		{

			System.out.println(e.getClass().getCanonicalName());

		}

	}



}