import java.util.Scanner;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String bt[]=new String[2];
	long r[]=new long[2];
	System.out.println("Enter the values for Innings 1");
	System.out.println("Enter the BattingTeam");
	bt[0]=sc.nextLine();
	System.out.println("Enter the runs scored");
	r[0]=sc.nextLong();
	sc.nextLine();
	System.out.println("Enter the values for Innings 2");
	System.out.println("Enter the BattingTeam");
	bt[1]=sc.nextLine();
	System.out.println("Enter the runs scored");
	r[1]=sc.nextLong();
	
	
	Innings i=new Innings();
	i.setBattingTeam(bt[0]);
	i.setRuns(r[0]);
	System.out.println("Innings 1 Details");
	System.out.println("BattingTeam : "+i.getBattingTeam());
	System.out.println("Runs scored : "+i.getRuns());
	
	i.setBattingTeam(bt[1]);
	i.setRuns(r[1]);
	System.out.println("Innings 2 Details");
	System.out.println("BattingTeam : "+i.getBattingTeam());
	System.out.println("Runs scored : "+i.getRuns());
}
}

