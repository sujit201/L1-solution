import java.util.Date;





public class Invoice {



private Double rating	;



private Date duration	;

private Date travelledDate	;

private Double distance	;

private Double amount	;

private Customer customer	;



public Double getRating() {



return rating;

}

public void setRating(Double rating) {



this.rating = rating;

}

public Date getDuration() {



return duration;

}

public void setDuration(Date duration) {



this.duration = duration;

}

public Date getTravelledDate() {



return travelledDate;

}

public void setTravelledDate(Date travelledDate) {



this.travelledDate = travelledDate;

}

public Double getDistance() {



return distance;

}

public void setDistance(Double distance) {



this.distance = distance;

}

public Double getAmount() {



return amount;

}

public void setAmount(Double amount) {



this.amount = amount;

}

public Customer getCustomer() {



return customer;

}

public void setCustomer(Customer customer) {



this.customer = customer;

}

public Invoice(Double rating, Date duration, Date travelledDate, Double distance, Double amount,



Customer customer) {



super();



this.rating = rating;



this.duration = duration;



this.travelledDate = travelledDate;



this.distance = distance;



this.amount = amount;



this.customer = customer;

}

public Invoice() {



super();

}



}



