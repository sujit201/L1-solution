import java.util.ArrayList;

import java.util.List;

public class Customer {

 private String name ;

 private String gender;

 private String contactNumber ;

 private String email ;

 private List<Invoice> invoiceList;

 

 public Customer() {

  super();

 }

 public Customer(String name, String gender, String contactNumber, String email, List<Invoice> invoiceList) {

  super();

  this.name = name;

  this.gender = gender;

  this.contactNumber = contactNumber;

  this.email = email;

  this.invoiceList = invoiceList;

 }

 public String getName() {

  return name;

 }

 public void setName(String name) {

  this.name = name;

 }

 public String getGender() {

  return gender;

 }

 public void setGender(String gender) {

  this.gender = gender;

 }

 public String getContactNumber() {

  return contactNumber;

 }

 public void setContactNumber(String contactNumber) {

  this.contactNumber = contactNumber;

 }

 public String getEmail() {

  return email;

 }

 public void setEmail(String email) {

  this.email = email;

 }

 public List<Invoice> getInvoiceList() {

  return invoiceList;

 }

 public void setInvoiceList(List<Invoice> invoiceList) {

  this.invoiceList = invoiceList;

 }

 public static List<Customer> prefill(){

  List<Customer> list=new ArrayList<>();

  list.add(new Customer("Harry","Male","7537535214","harry@gmail.com",new ArrayList<Invoice>()));

  list.add(new Customer("Joe","Male","9569569845","joe@gmail.com",new ArrayList<Invoice>()));

  list.add(new Customer("Oliver","Male","9524524586","oliver@gmail.com",new ArrayList<Invoice>()));

  list.add(new Customer("Martin","Male","7847847845","martin@gmail.com",new ArrayList<Invoice>()));

  list.add(new Customer("Lucas","Male","7523523521","lucas@gmail.com",new ArrayList<Invoice>()));

  list.add(new Customer("Sam","Male","9589589588","sam@gmail.com",new ArrayList<Invoice>()));

  return list;

 }

 public static Customer getValuableCustomer(List<Customer> customerList){

  Customer c=new Customer();

  Double max=0.0;

  

  for(Customer k:customerList) {

   Double am=0.0;

   for(Invoice j:k.getInvoiceList()) {

    am=am+j.getAmount();

   

   }

  

  if(am>max) {

   max=am;

   c=k;

  }

  }

  return c;

  

  

   }

}

