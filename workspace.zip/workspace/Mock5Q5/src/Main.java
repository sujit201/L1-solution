import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;

public class Main {

 public static void main(String[] args) throws NumberFormatException, IOException, ParseException{

  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

  SimpleDateFormat df=new SimpleDateFormat("HH:mm");

  SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

  List<Customer> cL=Customer.prefill();

  List<Invoice> iL=new ArrayList<Invoice>();

  System.out.println("Enter the number of invoices");

  int n=Integer.parseInt(br.readLine());

  Customer cu=new Customer();

  Customer c=new Customer();

  for(int i=0;i<n;i++) {

   String []x=br.readLine().split(",");

   Invoice in=new Invoice(Double.parseDouble(x[1]), df.parse(x[2]), sdf.parse(x[3]),Double.parseDouble(x[4]), Double.parseDouble(x[5]), cu);

   for(Customer k:cL) {

   if(x[0].equals(k.getName())) {

    cu=k;

   }

  }

  cu.getInvoiceList().add(in);

  c=Customer.getValuableCustomer(cL);

 }

  System.out.println("The most valuable customer is "+c.getName());

}

}



