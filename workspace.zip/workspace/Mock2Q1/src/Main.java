import java.io.BufferedReader;

import java.io.InputStreamReader;

import java.text.SimpleDateFormat;

import java.util.Scanner;



public class Main {

	public static void main(String args[])throws Exception{

		//Scanner sc=new Scanner(System.in);

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

		String s[];

		

		//Your code goes here

		System.out.println("Enter Vehicle 1 details:");

		//Your code goes here

		String v1=br.readLine();

		s=v1.split(",");

		Ticket tob1=new Ticket(s[4],formatter.parse(s[5]),Double.parseDouble(s[6]));

		Vehicle vob1=new Vehicle(s[0],s[1],s[2],Double.parseDouble(s[3]),tob1);

		System.out.println("Enter Vehicle 2 details:");

		//Your code goes here	

		String v2=br.readLine();

		s=v2.split(",");

		Ticket tob2=new Ticket(s[4],formatter.parse(s[5]),Double.parseDouble(s[6]));

		Vehicle vob2=new Vehicle(s[0],s[1],s[2],Double.parseDouble(s[3]),tob2);

		System.out.println();

		System.out.println("Vehicle 1");

		//System.out.println();

		System.out.println(vob1.toString());

		System.out.println();

		System.out.println("Vehicle 2");

		//System.out.println();

		System.out.println(vob2.toString());

		System.out.println();

		if(vob1.equals(vob2))

		System.out.println("Vehicle 1 is same as Vehicle 2\n");

		else

		System.out.println("Vehicle 1 and Vehicle 2 are different\n");

		

		

	} 

}

