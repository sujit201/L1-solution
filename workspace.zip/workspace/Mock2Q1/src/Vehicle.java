import java.text.DecimalFormat;



public class Vehicle {

private String registrationNo,name,type;

private Double weight;

private Ticket ticket;

DecimalFormat formatter = new DecimalFormat("#0.0");  

Vehicle(){}

public Vehicle(String registrationNo, String name, String type, Double weight, Ticket ticket) {

	super();

	this.registrationNo = registrationNo;

	this.name = name;

	this.type = type;

	this.weight = weight;

	this.ticket = ticket;

}

public String getRegistrationNo() {

	return registrationNo;

}

public void setRegistrationNo(String registrationNo) {

	this.registrationNo = registrationNo;

}

public String getName() {

	return name;

}

public void setName(String name) {

	this.name = name;

}

public String getType() {

	return type;

}

public void setType(String type) {

	this.type = type;

}

public Double getWeight() {

	return weight;

}

public void setWeight(Double weight) {

	this.weight = weight;

}

public Ticket getTicket() {

	return ticket;

}

public void setTicket(Ticket ticket) {

	this.ticket = ticket;

}

public boolean equals(Vehicle v)

{

	if(this.getRegistrationNo().equalsIgnoreCase(v.registrationNo)&& this.getName().equalsIgnoreCase(v.name))

		return true;

	else

		return false;

}

public String toString(){

	return ("\nRegistration No:"+registrationNo+"\nName:"+name+"\nType:"+type+"\nWeight:"+formatter.format(weight)+"\nTicket No:"+ticket.getTicketNo());

}

}