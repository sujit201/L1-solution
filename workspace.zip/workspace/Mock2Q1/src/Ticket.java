import java.util.Date;
public class Ticket {
//Your code goes here
private String ticketNo;
private Double cost;
private Date parkedTime;
Ticket(){}
public Ticket(String ticketNo,Date parkedTime,Double cost) {
super();
this.ticketNo = ticketNo;
this.cost = cost;
this.parkedTime = parkedTime;
}
public String getTicketNo() {
return ticketNo;
}
public void setTicketNo(String ticketNo) {
this.ticketNo = ticketNo;
}
public Double getCost() {
return cost;
}
public void setCost(Double cost) {
this.cost = cost;
}
public Date getParkedTime() {
return parkedTime;
}
public void setParkedTime(Date parkedTime) {
this.parkedTime = parkedTime;
}
}