import java.text.SimpleDateFormat;



import java.time.YearMonth;



import java.util.Calendar;







public class UserMainCode {



public static void displayDay(int y, int m) 



{



    SimpleDateFormat sdf=new SimpleDateFormat("EEEE");



	Calendar c=Calendar.getInstance();



	YearMonth ym = YearMonth.of(y, m);







	String firstDay = ym.atDay(1).getDayOfWeek().name();



	String lastDay = ym.atEndOfMonth().getDayOfWeek().name();







	System.out.println(firstDay);



	System.out.println(lastDay);



}



}