import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int i,n;
	ArrayList<String>s1=new ArrayList<String>();
    System.out.println("Enter the teams in ranking table");
    for(i=0;i<5;i++) {
    	s1.add(sc.nextLine());
    }
    
    System.out.println("Enter the rank to be searched");
    n=sc.nextInt();
    
    System.out.println(s1.get(n-1));
}
}

