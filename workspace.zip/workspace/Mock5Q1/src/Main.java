import java.util.Scanner;

class Main
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s[];
		System.out.println("Enter customer 1 details:");
	      String customer1= sc.nextLine();
	      s=customer1.split(",");
	      Customer c1=new Customer(s[0],s[1],s[2],s[3]);
	      System.out.println("Enter customer 2 details:");
	      String customer2= sc.nextLine();
	      s=customer2.split(",");
	      Customer c2=new Customer(s[0],s[1],s[2],s[3]);
	      System.out.println();
	      System.out.println("Customer 1");
	      System.out.println(c1.toString());
	      System.out.println();
	      System.out.println("Customer 2");
	      System.out.println(c2.toString());
	      System.out.println();
	      if(c1.equals(c2))
	    	  System.out.println("Customer 1 is same as Customer 2");
	      else
	    	  System.out.println("Customer 1 and Customer 2 are different");
	}

	      
	      
	      
	      
	      
	}

