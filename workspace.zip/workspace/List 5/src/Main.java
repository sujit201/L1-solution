import java.util.*;
public class Main {
public static void main(String args[]) {
	int i;
	Scanner sc=new Scanner(System.in);
	ArrayList<String>s1=new ArrayList<String>();
	System.out.println("Enter the top 5 scorers of IPL Season 8");
	for(i=0;i<5;i++) {
		s1.add(sc.nextLine());
	}
	
	ArrayList<String>s2=new ArrayList<String>();
	System.out.println("Enter the top 5 scorers of IPL Season 9");
    for(i=0;i<5;i++) {
		s2.add(sc.nextLine());

    }
    Iterator it=s1.iterator();
    String a;
    System.out.println("Consistent run scorers");
    for(i=0;i<5;i++) {
     a=(String)it.next();
    Iterator it2=s2.iterator();
    for(int j=0;j<5;j++) {
    	
    	if(a.equals(it2.next()))
    		System.out.println(a);
    }
}
}
}


