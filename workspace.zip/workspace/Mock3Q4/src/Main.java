import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

import java.util.ArrayList;

import java.util.List; 

 

public class Main {

               public static void main(String[] args) throws IOException{

                               BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

                                               //Your code goes here

                               Movie m=new Movie();

                               MovieBO mb=new MovieBO();

                               List<Movie> list=new ArrayList<Movie>();

                               

                               System.out.println("Enter the number of movies:");

                                               //Your code goes here

                               int n=Integer.parseInt(reader.readLine());

                               for(int i=0;i<n;i++)

                               {

                                               String s=reader.readLine();

                                               String[] a=s.split(",");

                                              m=new Movie(a[0],new Double(a[1]),new Double(a[2]),new Double(a[3]));

                                               list.add(m);

                               }

                               List<Movie> l=mb.getSuccessMovies(list);

                               

                               if(l.isEmpty())

                               {

                                               System.out.println("None of the movies are successful");

                               }

                               else

                               {

                                               System.out.println("Successful movies are");

                                               System.out.format("%-22s %-10s %-8s %s\n","Name","Box Office","Budget","Rating");

                                               for(int i=0;i<l.size();i++)

                                               {

                                                               System.out.print(l.get(i));

                                               }

                               }

                               

               }

}

 