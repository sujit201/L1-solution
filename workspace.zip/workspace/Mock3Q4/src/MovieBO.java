import java.util.ArrayList;

import java.util.List;

 

public class MovieBO {

               public List<Movie> getSuccessMovies(List<Movie> movieList){

                               //Your code goes here

                               List<Movie> l=new ArrayList<Movie>();

                               int flag=0;

                               for(int i=0;i<movieList.size();i++)

                               {

                                               Double d=movieList.get(i).getBoxoffice()-movieList.get(i).getBudget();

                                               if(d>=(movieList.get(i).getBudget()/2))

                                               {

                                                               l.add(movieList.get(i));

                                                               flag=1;

                                               }

                               }

 

                               return l;

               }

}