import java.text.SimpleDateFormat;

import java.util.Date;



public class Match implements Comparable<Match>{

	private Date matchDate;

	private String venue; 

	private String teamOne; 

	private String teamTwo;

	public Date getMatchDate() {

		return matchDate;

	}

	public void setMatchDate(Date matchDate) {

		this.matchDate = matchDate;

	}

	public String getVenue() {

		return venue;

	}

	public void setVenue(String venue) {

		this.venue = venue;

	}

	public String getTeamOne() {

		return teamOne;

	}

	public void setTeamOne(String teamOne) {

		this.teamOne = teamOne;

	}

	public String getTeamTwo() {

		return teamTwo;

	}

	public void setTeamTwo(String teamTwo) {

		this.teamTwo = teamTwo;

	}

	public Match(Date matchDate, String venue, String teamOne, String teamTwo) {

		

		this.matchDate = matchDate;

		this.venue = venue;

		this.teamOne = teamOne;

		this.teamTwo = teamTwo;

	}

	Match()

	{

		

	}

	@Override

	public int compareTo(Match o) {

		long t1=this.matchDate.getTime();

		long t2=o.matchDate.getTime();

		if(t1>t2)

		{

			return 1;

		}

		else if(t1==t2)

		{

			return 0;

		}

		else 

			return -1;

	}

	@Override

	public String toString() {

		SimpleDateFormat sf=new SimpleDateFormat("MM-dd-yyyy");

		String d=sf.format(matchDate);

		return "Team 1 "+teamOne+"\nTeam 2 "+teamTwo+"\nMatch held on "+d+"\nMatch held at "+venue; 

	}

	

	

	

}

