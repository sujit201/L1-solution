import java.util.Scanner;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Date;

import java.util.Iterator;

import java.text.*;

public class Main {

public static void main(String []args) throws ParseException

  { SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");

	  Scanner sc=new Scanner(System.in);

	  ArrayList<Match> ar=new ArrayList<>();

	  System.out.println("Enter the number of matches"); 

	  int a=sc.nextInt();

	  sc.nextLine();

	  Match m;

	  for(int i=0;i<a;i++)

	  {

		  System.out.println("Enter match date in (MM-dd-yyyy)"); 

		  String s=sc.nextLine();

		  Date d=sdf.parse(s);

		  System.out.println("Enter Team 1"); 

		  String s1=sc.nextLine();

		  System.out.println("Enter Team 2"); 

		  String s2=sc.nextLine();

		  System.out.println("Enter venue"); 

		  String s3=sc.nextLine();

		  m=new Match(d, s3, s1, s2);

		  ar.add(m);

	  }

	  Collections.sort(ar);

	  Iterator<Match> i=ar.iterator();

	  System.out.println("Match Details");

    int k=1;

	  while(i.hasNext())

    {

  	  System.out.println(i.next());

    }

  }

}