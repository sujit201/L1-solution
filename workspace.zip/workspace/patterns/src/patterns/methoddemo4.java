package patterns;
class Demo5{
	int a,b;
	Demo5(int a,int b){
this.a=a;
this.b=b;
	}
Demo5 disp(Demo5 obj){
	obj.a=obj.a+a;
	obj.b=obj.b+b;
	return obj;
}
void display(){
	System.out.println(a+" "+b);
}}
public class methoddemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Demo5 obj1=new Demo5(10,20);
Demo5 obj2=new Demo5(30,40);
Demo5 obj=obj1.disp(obj2);
obj.display();

System.out.println("---------------");
obj=obj2.disp(obj1);
obj.display();
	}

}
 