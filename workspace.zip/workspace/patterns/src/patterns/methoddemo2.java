package patterns;
class demo{
	void disp(){
		System.out.println("hello world");
	}
void disp1(demo obj){// obj=obj1
	System.out.println("object para");
}
}
public class methoddemo2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
new demo().disp();
demo obj1=new demo();
demo obj2=new demo();
obj2.disp1(obj1);// obj2--> invoking object
                 // obj1--> parameterized object



	}

}
