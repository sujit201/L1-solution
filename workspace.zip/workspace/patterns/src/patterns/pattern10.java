package patterns;

public class pattern10 {
public static void main(String[] args)
{
int i,j,sp=0;
for(i=1;i<=5;i++)
{
	for(j=1;j<=i;j++)
	if(j!=1)
	System.out.printf("%c",+(j+96));
	for(j=1;j<sp;j++)
		System.out.println("");
	sp=sp+2;
	for(j=i;j>=1;j--)
		System.out.printf("%c",+(j+96));
}
System.out.println();
}
}
