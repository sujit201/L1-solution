package patterns;
//  io classes//
import java.io.InputStreamReader;
import java.io.BufferedReader;
public class Sample3 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
InputStreamReader isr=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(isr);
	String value=br.readLine();
	System.out.println(value);
	System.out.println("Input:Integer");
	int a=Integer.parseInt(br.readLine());
	System.out.println(a*a);
	
}

}
