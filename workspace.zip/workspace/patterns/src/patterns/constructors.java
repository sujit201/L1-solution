package patterns;
class demo1{
	int a=10;
	void disp(){
		System.out.println("hello");
	}
}
public class constructors {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
demo1 obj=new demo1();
System.out.println(obj.a);
obj.disp();
	}

}
