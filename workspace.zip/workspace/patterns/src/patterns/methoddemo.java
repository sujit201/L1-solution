package patterns;

public class methoddemo {
int a=10;//non static variable//
static int b=20;
void display(){
	System.out.println("non static method");
}
static void display2(){
	System.out.println("static method");
}
public static void main(String[] args) {
methoddemo obj=new methoddemo();

		System.out.println(b);
				System.out.println(obj.a);
				obj.display();
				System.out.println(methoddemo.b);
				display2();
				methoddemo.display2();
	}

}
