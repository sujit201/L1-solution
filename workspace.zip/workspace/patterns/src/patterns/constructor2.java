package patterns;
class demo2{
	demo2(int a){
		System.out.println(a);
	}
demo2(){
	System.out.println("explicit constructor");
}
demo2(demo2 ob)
{
	System.out.println("copy constructors");
}
}
public class constructor2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
demo2 obj=new demo2();
demo2 obj2=new demo2(10);
demo2 obj3=new demo2(new demo2());
System.out.println("-------------------");
new demo2(10);
new demo2(new demo2());
new demo2();
	
	}

}
