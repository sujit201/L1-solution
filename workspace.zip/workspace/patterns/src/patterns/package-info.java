/**
 * 
 */
/**
 * @author 760331
 *
 */
package patterns;