package patterns;
class Demo4{
	int a,b;
	Demo4(int c,int d){
		a=c;
		b=d;
	}
void disp(Demo4 obj){
	System.out.println(a+" "+b);
	System.out.println(obj.a+" "+obj.b);
}
}
public class methoddemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Demo4 obj=new Demo4(10,20);
Demo4 obj2=new Demo4(30,40);
obj.disp(obj2);
System.out.println("------------------");
obj2.disp(obj);

	}

}
