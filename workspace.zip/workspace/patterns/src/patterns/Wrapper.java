package patterns;

public class Wrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=5;
Integer b=new Integer(10);
System.out.println(a+" "+b);
int k=7;
Integer d=k;
System.out.println(d);
Integer i=50;
int j=i;
System.out.println(j);
	String val="100";
	int var=Integer.parseInt(val);
	System.out.println(var);
	int var2=Integer.parseInt("100",2);
	System.out.println(var2);
	float f1=10.5f;
	float f2=new Float(10.7);
	System.out.println(f1+" "+f2);
	float var3=Float.parseFloat("100.88");
	System.out.println(var3);
	
	
	
	}

}
