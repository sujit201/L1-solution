package patterns;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char ch='-';
System.out.println(Character.isLetter(ch));
System.out.println(Character.isDigit('5'));
System.out.println("space:"+Character.isWhitespace(' '));
	}

}
