
package patterns;
import java.util.Scanner;
public class arraymatrix 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
int sum=0,i,j;
int m[][]=new int[3][3];
Scanner sc=new Scanner(System.in);
for( i=0;i<3;i++)
{
	for( j=0;j<3;j++)
	{
		System.out.println("input");
	m[i][j]=sc.nextInt();
}}
System.out.print("----------------  ");
for(i=0;i<3;i++){
	for(j=0;j<3;j++){
		System.out.print(m[i][j]+ " " );
		sum+=m[i][j];
	}
	System.out.println();
	}
System.out.println("sum:" +sum);
}
}


