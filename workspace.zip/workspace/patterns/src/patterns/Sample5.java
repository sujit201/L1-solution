package patterns;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Sample5 {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
int n;
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(isr);
System.out.println("enter number");
n=Integer.parseInt(br.readLine());
if(n%2==0){
	System.out.println("even");
}
else{
	System.out.println("odd");
}
	}

}
