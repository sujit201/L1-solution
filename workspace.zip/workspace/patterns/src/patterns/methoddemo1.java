package patterns;
class Demo{
	int a=10;
	void disp1(Demo obj)//obj=obj
	{
		System.out.println("a "+a);
	}
}

public class methoddemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Demo obj1=new Demo();
Demo obj2=new Demo();
obj2.a=20;
obj1.disp1(obj2);
obj2.disp1(obj2);
	}

}
