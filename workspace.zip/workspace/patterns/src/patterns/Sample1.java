package patterns;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char ch='a';
char ch1='A';
System.out.println(Character.toUpperCase(ch));

System.out.println(Character.toLowerCase(ch1));
	}

}
