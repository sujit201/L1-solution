package patterns;
import java.util.Scanner;
public class array2d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int m,n;
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter m and n");
				m=sc.nextInt();
				n=sc.nextInt();
				int[] []a1=new int [m][n];
				
				for(int i=0;i<=a1.length-1;i++)
				{
					for (int j=0;j<a1.length;j++)
					{
					    System.out.println("enter numbers");
					    	a1[i][j]=sc.nextInt();
					    	
					}
						
				}
				for(int i=0;i<=a1.length-1;i++)
				{
					for (int j=0;j<=a1.length-1;j++)
					{
					    System.out.print(a1[i][j]+" ");	    	
					}
					System.out.println();	
				}
				int max=a1[0][0];
				int min=a1[0][0];
				for(int i=0;i<=a1.length-1;i++)
				{
					for (int j=0;j<=a1.length-1;j++)
					{
						if(max<a1[i][j])
						{
							max=a1[i][j];
						}
							
						if(min>a1[i][j])
						{
							min=a1[i][j];
						}	
					}
				}	
					System.out.println("Max number = "+max);
					System.out.println("Min number = "+min);
			}
		

	}


