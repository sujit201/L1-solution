public class UserMainCode {

	public static void displayDate(int year)

	{

		boolean flag=false;

		if(year%400==0)

		{

			flag=true;

		}

		else if(year%100==0)

		{

			flag=false;

		}

		else if(year%4==0)

		{

			flag=true;

		}

		if(flag)

		{

			System.out.println(year+" is leap year");

		}

		else

		{

			System.out.println(year+" is not leap year");

		}

	}

}