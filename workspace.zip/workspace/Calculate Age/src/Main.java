import java.text.ParseException;



import java.util.Scanner;











public class Main {







    public static void main(String[] args) throws Exception {



		// TODO Auto-generated method stub



Scanner sc=new Scanner(System.in);







String s1=sc.nextLine();



String s2=sc.nextLine();







UserMainCode.displayAge(s1, s2);



	}

}