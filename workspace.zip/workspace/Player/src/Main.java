import java.util.*;



public class Main {

public static void main(String arag[]){

	

	Scanner sc=new Scanner(System.in);

	

	String pname,pcountry,pskill;

	

	System.out.println("Enter the player name");

	pname=sc.nextLine();

	System.out.println("Enter the country name");

	pcountry=sc.nextLine();

	System.out.println("Enter the skill");

	pskill=sc.nextLine();

	

	Player pl=new Player();

	

	pl.name=pname;

	pl.country=pcountry;

	pl.skill=pskill;

	

	System.out.println("Player Details :");

	

	System.out.println("Player Name : "+pl.name);

	System.out.println("Country Name : "+pl.country);

	System.out.println("Skill : "+pl.skill);

	

	

}

}

