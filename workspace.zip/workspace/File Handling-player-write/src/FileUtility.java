import java.io.*;

import java.util.*;

public class FileUtility

{

  public void writeData(List<Player> playerList)throws IOException

  {

    FileOutputStream fw=new FileOutputStream("player.csv");

     BufferedWriter pw=new BufferedWriter(new OutputStreamWriter(fw));

     for(Player p:playerList)

     {

       pw.write(p.toString());

       pw.newLine();

     }

     pw.close();

  }

}