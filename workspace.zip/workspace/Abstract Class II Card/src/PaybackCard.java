public class PaybackCard extends Card{

   

  private Integer pointsEarned;

  private Double totalAmount;

	public Integer getPointsEarned() {

		return pointsEarned;

	}

	public void setPointsEarned(Integer pointsEarned) {

		this.pointsEarned = pointsEarned;

	}

	public Double getTotalAmount() {

		return totalAmount;

	}

	public void setTotalAmount(Double totalAmount) {

		this.totalAmount = totalAmount;

	}

   

	PaybackCard()

	{

		

	}

	

	PaybackCard(String holderName,String cardNumber,String expiryDate,int pointsEarned, double totalAmount) {

  	super(holderName,cardNumber,expiryDate);

  	this.setPointsEarned(pointsEarned);

  	this.setTotalAmount(totalAmount);

  	

	}



   

   

   

   

}

