public class MembershipCard extends Card {

  private Integer rating;



	public Integer getRating() {

		return rating;

	}



	public void setRating(Integer rating) {

		this.rating = rating;

	}



  MembershipCard()

  {

  	

  }

   

  MembershipCard(String holderName,String cardNumber,String expiryDate,int rating)

  {

  	super(holderName,cardNumber,expiryDate);

  	this.setRating(rating);

  	

  	

  }

   

   

}