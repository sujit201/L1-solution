import java.util.Scanner;

import java.util.StringTokenizer;



public class Main 

{

  public static void main(String args[])

  {

      Scanner sc=new Scanner(System.in);

	  String st1;

	  String s=sc.nextLine();

	  StringTokenizer st=new StringTokenizer(s,"!#");

	  while(st.hasMoreTokens())

		{

			System.out.print(st.nextToken());

		}

	 

	 

  }

}

