import java.util.*;

import java.io.*;

public class Main {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner a=new Scanner(System.in);

		System.out.println("Enter the team name");

		String s=a.nextLine();

		try

		{

			System.out.println("Enter the number of players suggested");

			int n=a.nextInt();

			int l[]=new int[n];

			String ss[]=new String[n];

			for(int i=0; i<n; i++)

			{

				System.out.println("Enter player "+(i+1)+" details");

				l[i]=a.nextInt();

				a.nextLine();

				ss[i]=a.nextLine();

				for(int j=0; j<i; j++)

				{

					if(l[i]==l[j])

					{

						throw new DuplicateIdException("Player Id must be unique");

					}

				}

			}

			for(int i=0; i<n; i++)

			{

				System.out.println(l[i]+" "+ss[i]);

			}

		}

		catch(Exception e)

		{

			System.out.println(e);

		}

	}



}

