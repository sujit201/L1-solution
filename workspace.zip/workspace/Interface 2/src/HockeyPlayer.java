public class HockeyPlayer extends Player implements IPlayerStatistics {





	private String Position;

 

	private long noOfGoals;

 

	public long getNoOfGoals() {

 

 return noOfGoals;

}

	public void setNoOfGoals(long noOfGoals) {

 

 this.noOfGoals = noOfGoals;

}

	public String getPosition() {

 

 return Position;

}

	public void setPosition(String position) {

 

 Position = position;

}

	public HockeyPlayer(String name, String teamName, long noOfMatches,

 

 String position, long noOfGoals) {

 

 super(name, teamName, noOfMatches);

 

 Position = position;

 

 this.noOfGoals = noOfGoals;

}

	public void displayPlayerStatistics()

{

 

 System.out.println("Player name : "+getName());

 

 System.out.println("Team name : "+getTeamName());

 

 System.out.println("No of matches : "+getNoOfMatches());

 

 System.out.println("Position : "+getPosition());

 

 System.out.println("No of goals taken : "+getNoOfGoals());

}

}









