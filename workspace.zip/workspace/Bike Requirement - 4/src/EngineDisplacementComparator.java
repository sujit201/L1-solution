import java.util.Comparator;


public class EngineDisplacementComparator implements Comparator<Bike>
{

	public int compare(Bike b1, Bike b2) {
	
		return b1.getEngineDisplacement().compareTo(b2.getEngineDisplacement());
				
	}
	
	

}
