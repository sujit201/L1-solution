
public class Bike implements Comparable<Bike>{

	private String VIN;
	private String brand;
	private String model;
	private String engineDisplacement;
	private String BrakeSystem;
	private double cost;
	public String getVIN() {
		return VIN;
	}
	public void setVIN(String vIN) {
		VIN = vIN;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngineDisplacement() {
		return engineDisplacement;
	}
	public void setEngineDisplacement(String engineDisplacement) {
		this.engineDisplacement = engineDisplacement;
	}
	public String getBrakeSystem() {
		return BrakeSystem;
	}
	public void setBrakeSystem(String brakeSystem) {
		BrakeSystem = brakeSystem;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Bike(String vIN, String brand, String model, String engineDisplacement, String brakeSystem, double cost) {
		VIN = vIN;
		this.brand = brand;
		this.model = model;
		this.engineDisplacement = engineDisplacement;
		BrakeSystem = brakeSystem;
		this.cost = cost;
	}
	public boolean equals(Bike ob) {
		if(this.VIN.equals(ob.VIN) && this.brand.equalsIgnoreCase(ob.brand))
			return true;
		else
			return false;
	}
	
	
	public static Bike createBike(String detail)
	{
		String ss[] = detail.split(",");
		Bike b = new Bike(ss[0], ss[1], ss[2], ss[3], ss[4], Double.parseDouble(ss[5]));
		return b;
	}
	
	
	@Override
	public String toString() {
		return String.format("%-20s %-10s %-10s %-20s %-12s %s\n",VIN,brand,model,engineDisplacement,BrakeSystem,cost);
	}
	
	
	public int compareTo(Bike b) {
		
		return brand.compareTo(b.getBrand());
	}
	
	
}
