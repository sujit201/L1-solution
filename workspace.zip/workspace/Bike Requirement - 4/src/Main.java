import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Main 
{
	
	public static void main(String args[]) throws NumberFormatException, IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<Bike> l = new ArrayList<Bike>();
		
		System.out.println("Enter the number of the bikes:");
		int n= Integer.parseInt(br.readLine());
		
		for(int i=0;i<n;i++)
		{
			String s = br.readLine();
			l.add(Bike.createBike(s));
		}
		
		System.out.println("Enter a type to sort:");
		System.out.println("1.Sort by Brand");
		System.out.println("2.Sort by Engine Displacement");
		int ch= Integer.parseInt(br.readLine());
		System.out.format("%-20s %-10s %-10s %-20s %-12s %s\n","VIN","Brand","Model","Engine Displacement", "Brake System", "Cost");
		switch(ch)
		{
		case 1:
			Collections.sort(l);
			for(Bike b : l)
			{
				System.out.print(b.toString());
			}
			break;
			
		case 2:
			EngineDisplacementComparator ec = new EngineDisplacementComparator();
			Collections.sort(l, ec);
			for(Bike b : l)
			{
				System.out.print(b.toString());
			}
			break;
			
		}
		
		
	}

}
