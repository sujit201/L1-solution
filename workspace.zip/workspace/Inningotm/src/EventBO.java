
public class EventBO 
{
	public Event createEvent(String data, Innings[] inningsList)
	{
		String s[]=data.split(",");
		Event e = new Event();
	
				for(int i=0;i<inningsList.length;i++)
				{
					if(inningsList[i].getInningsNumber()==Long.parseLong(s[4]))
				
		return new Event(Long.parseLong(s[0]),s[1],Long.parseLong(s[2]),Long.parseLong(s[3]),inningsList[i]);
				}
		return new Event();
	}
	
	public String findInningsNumber(Event[] List, Long eventNumber)
	{
		
		for(int i=0;i<List.length;i++)
		{
			if(List[i].getEventNumber()==eventNumber)
				return String.valueOf(List[i].getInnings().getInningsNumber());
				
		}
		return "";
	}
}
