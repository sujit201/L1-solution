import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of innings");
		int n = sc.nextInt();
		sc.nextLine();
		Innings inn[] = new Innings[n];
		String innings[]=new String[n];
		InningsBO ibo = new InningsBO();
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter innings "+(i+1)+" details");
			innings[i]= sc.nextLine();
			inn[i]= ibo.createInnings(innings[i]);
		}
		
		System.out.println("Enter the number of events");
		int m = sc.nextInt();
		sc.nextLine();
		Event e[]=new Event[m];
		EventBO eventbo = new EventBO();
		String event[] = new String[m];
		for(int i=0;i<m;i++)
		{
			System.out.println("Enter event "+(i+1)+" details");
			event[i] = sc.nextLine();
			e[i] = eventbo.createEvent(event[i],inn);
		}
		
		System.out.println("Enter the event number for which you need to find the innings number");
		Long eventNumber = sc.nextLong();
		System.out.println("Innings: "+eventbo.findInningsNumber(e,eventNumber));
	}

}
