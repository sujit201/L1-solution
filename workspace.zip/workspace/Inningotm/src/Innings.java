
public class Innings
{
	Long inningsNumber;

	public Innings(){};	
	public Innings(Long inningsNumber) {
		super();
		this.inningsNumber = inningsNumber;
	}

	public Long getInningsNumber() {
		return inningsNumber;
	}

	public void setInningsNumber(Long inningsNumber) {
		this.inningsNumber = inningsNumber;
	}
	
}
