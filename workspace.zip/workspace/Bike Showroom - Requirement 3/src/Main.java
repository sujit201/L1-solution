import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
	public static void main(String args[]) throws NumberFormatException, IOException{
		BufferedReader q = new BufferedReader(new InputStreamReader(System.in));
		List<Showroom> showroomList=new ArrayList<Showroom>();
		System.out.println("Enter the number of showrooms");
		int n=Integer.parseInt(q.readLine());
		for(int i=0;i<n;i++)
		{
			String s[]=q.readLine().split(",");
			showroomList.add(new Showroom(s[0], s[1], s[2], s[3], s[4]));
		}
		Map<String, Integer> showroomCount=Showroom.cityWiseShowroomCount(showroomList);
		System.out.format("%-15s %s\n","City","Count");
		for(Map.Entry<String, Integer> entry: showroomCount.entrySet())
			System.out.format("%-15s %s\n",entry.getKey(),entry.getValue());
	}
}
