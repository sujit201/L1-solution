

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.Date;

 

 

public class Member implements Comparable<Member>{

 

private long id;

private String firstName,lastName,email,contactNumber,licenseNumber;

private Date licenseStartDate,licenseExpiryDate;

public long getId() {

return id;

}

public void setId(long id) {

this.id = id;

}

public String getFirstName() {

return firstName;

}

public void setFirstName(String firstName) {

this.firstName = firstName;

}

public String getLastName() {

return lastName;

}

public void setLastName(String lastName) {

this.lastName = lastName;

}

public String getEmail() {

return email;

}

public void setEmail(String email) {

this.email = email;

}

public String getContactNumber() {

return contactNumber;

}

public void setContactNumber(String contactNumber) {

this.contactNumber = contactNumber;

}

public String getLicenseNumber() {

return licenseNumber;

}

public void setLicenseNumber(String licenseNumber) {

this.licenseNumber = licenseNumber;

}

public Date getLicenseStartDate() {

return licenseStartDate;

}

public void setLicenseStartDate(Date licenseStartDate) {

this.licenseStartDate = licenseStartDate;

}

public Date getLicenseExpiryDate() {

return licenseExpiryDate;

}

public void setLicenseExpiryDate(Date licenseExpiryDate) {

this.licenseExpiryDate = licenseExpiryDate;

}

public Member() {

super();

// TODO Auto-generated constructor stub

}

public Member(long id, String firstName, String lastName, String email,

String contactNumber, String licenseNumber, Date licenseStartDate,

Date licenseExpiryDate) {

super();

this.id = id;

this.firstName = firstName;

this.lastName = lastName;

this.email = email;

this.contactNumber = contactNumber;

this.licenseNumber = licenseNumber;

this.licenseStartDate = licenseStartDate;

this.licenseExpiryDate = licenseExpiryDate;

}

public static Member createInstance(String s) throws NumberFormatException, ParseException, InvalidEmailException {

// TODO Auto-generated method stub

SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

String str[]=s.split(",");

Member m=null;

if(str[3].contains("@")&&(str[3].endsWith(".com")||str[3].endsWith(".org")))

  m=new Member(Long.parseLong(str[0]), str[1], str[2],str[3], str[4], str[5], sdf.parse(str[6]), sdf.parse(str[7]));

else

throw new InvalidEmailException("Invalid Email for "+str[1]);

return m;

}

@Override

public int compareTo(Member m) {

// TODO Auto-generated method stub

return firstName.compareTo(m.getFirstName());

}

}