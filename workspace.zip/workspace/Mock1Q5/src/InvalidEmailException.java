
public class InvalidEmailException extends Exception {



public InvalidEmailException(String s) {

super(s);

// TODO Auto-generated constructor stub

}



}





