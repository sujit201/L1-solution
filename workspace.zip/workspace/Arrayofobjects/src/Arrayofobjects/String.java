package Arrayofobjects;

public class String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1=new String("Hello");
		System.out.println(s1.length());
		byte b[]=(65,66,67,68,69);
		String s2=new String(b);
		System.out.println(s2);
		char ch[]=('a','b','c');
		System.out.println(ch);
		
		

	}

}
