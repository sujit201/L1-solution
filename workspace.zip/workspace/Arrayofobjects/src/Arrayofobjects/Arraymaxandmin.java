package Arrayofobjects;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
class Employee2{
	int id;
	String name;   
	double salary;
Employee2(int id,String name,double salary)
{
	this.id=id;
	this.name=name;
	this.salary=salary;
}
void display(){
	System.out.println(id+"\t"+name+"\t"+salary);
}}
public class Arraymaxandmin {
public static void main(String[] args)throws NumberFormatException, IOException{
		// TODO Auto-generated method stub
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(isr);
Employee2 arr[]=new Employee2[3];
Employee2 max;
int id;
String name;
double salary;
for(int i=0;i<arr.length;i++)
{
	System.out.println("enter id");
	id=Integer.parseInt(br.readLine());
	System.out.println("enter name");
	name=br.readLine();
	System.out.println("enter salary");
	salary=Double.parseDouble(br.readLine());
	arr[i]=new Employee2(id, name, salary);
}
	System.out.println("Records using regular for loop");
	for(int i=0;i<arr.length;i++)
		arr[i].display();
	System.out.println("records using enhancing for loop");
	for(Employee2 e:arr)
		e.display();
	max=arr[0];
	for(int i=1;i<arr.length;i++){
		if(max.salary<arr[i].salary)
		{
			max.salary=arr[i].salary;
		}
	System.out.println("max salary"+max.salary);
	}}}

