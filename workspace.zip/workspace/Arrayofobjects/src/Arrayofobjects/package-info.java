
package Arrayofobjects;



import java.io.InputStreamReader;
import java.io.BufferedReader;
class Employee{
	int id;
	String name;   
	double salary;
Employee(int id,String name,double salary)
{
	this.id=id;
	this.name=name;
	this.salary=salary;
}
void display(){
	System.out.println(id+"\t"+name+"\t"+salary);
}
public class Arraydemo {

	public static void main(String[] args)throws IOException{
		// TODO Auto-generated method stub
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(isr);
Employee arr[]=new Employee[3];
int id;
String name;
double salary;
for(int i=0;i<arr.length;i++)
{
	System.out.println("enter id");
	id=Integer.parseInt(br.readLine());
	System.out.println("enter name");
	name=br.readLine();
	System.out.println("enter salary");
	salary=Double.parseDouble(br.readLine());
	arr[i]=new Employee[id, name, salary];
}
System.out.println(arr[0].id+" "+arr[0].name+" "+arr[0].salary);
	}
	System.out.println("Records using regular for loop");
	for(int i=0;i<arr.length;i++)
		arr[i].display();
	
	
	System.out.println("records using enhancing for loop");
	for(Employee e:arr)
		e.display();
	}
		}


