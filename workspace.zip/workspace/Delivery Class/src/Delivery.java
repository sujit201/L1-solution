
public class Delivery {
long over,ball,runs;
String batsman,bowler,nonStriker;
void displayDeliveryDetails() {
	System.out.println("Delivery Details :");
	System.out.println("Over : "+over);
	System.out.println("Ball : "+ball);
	System.out.println("Runs : "+runs);
	System.out.println("Batsman : "+batsman);
	System.out.println("Bowler : "+bowler);
	System.out.println("NonStriker : "+nonStriker);
}

}


