import java.util.*;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	Delivery d=new Delivery();
	System.out.println("Enter the over");
	d.over=sc.nextLong();
	System.out.println("Enter the ball");
	d.b=sc.nextLong();
	System.out.println("Enter the runs");
	d.r=sc.nextLong();
	sc.nextLine();
	System.out.println("Enter the batsman name");
	d.bt=sc.nextLine();
	System.out.println("Enter the bowler name");
	d.bw=sc.nextLine();
	System.out.println("Enter the nonStriker name");
	d.ns=sc.nextLine();


	d.displayDeliveryDetails;

}
}
