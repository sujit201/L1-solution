public class Vehicle {

protected String make;

protected String vehicleNumber;

protected String fuelType;

protected int fuelCapacity;

protected int cc;

Vehicle()

{

	

}

public Vehicle(String a, String b, String c, int d, int e)

{

	this.make=a;

	this.vehicleNumber=b;

	this.fuelType=c;

	this.fuelCapacity=d;

	this.cc=e;

}

public void displayMake()

{

	

	System.out.println("***"+make+"***");

}

public void displayBasicInfo()

{

//	System.out.println("make:"+make);

	System.out.println("---Basic Information---");

	System.out.println("Vehicle Number:"+vehicleNumber);

	System.out.println("Fuel Capacity:"+fuelCapacity);

	System.out.println("Fuel Type:"+ fuelType);

	System.out.println("CC:"+cc);

}

public void displayDetailInfo()

{

	

}

}

