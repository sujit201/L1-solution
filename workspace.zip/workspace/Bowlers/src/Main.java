import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n,i;
	System.out.println("Enter the number of bowlers");
	n=sc.nextInt();
	sc.nextLine();
	TreeSet<String> a=new TreeSet<String>();
for(i=0;i<n;i++)
{
	a.add(sc.nextLine());
}
	Iterator it=a.iterator();
	System.out.println("Players list in ascending order");
	for(i=0;i<a.size();i++)
	{
		System.out.println(it.next());
	}

}
}
