import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the number of deliveries");

		int n=sc.nextInt();

		Delivery d[]=new Delivery[n];

		long over=0;

		long ball=0;

		String bat=null;

		String bowl=null;

		String str=null;

		

		int i;

		

		for(i=0;i<n;i++)

		{

			System.out.println("Enter the over");

			over=sc.nextLong();

			System.out.println("Enter the ball");

			ball=sc.nextLong();

			sc.nextLine();

			System.out.println("Enter the batsman");

			bat=sc.nextLine();

			System.out.println("Enter the bowler");

			bowl=sc.nextLine();

			System.out.println("Enter the nonStriker");

			str=sc.nextLine();

			d[i]=new Delivery(over,ball,bat,bowl,str);

		}

		DeliveryBO dbo=new DeliveryBO();

		

		dbo.displayAllDeliveryDetails(d);

		

		sc.close();



	}



}