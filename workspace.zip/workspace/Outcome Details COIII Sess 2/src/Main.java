import java.util.*;



public class Main {



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		

		System.out.println("Enter the number of matches");

		int n=sc.nextInt();

		sc.nextLine();

		int i;

		Outcome o[]=new Outcome[n];

		String date;

		String status;

		String winnerTeam;

		String playerOfMatch;

		

		for(i=0;i<n;i++)

		{

			System.out.println("Enter match "+(i+1)+" details");

			System.out.println("Enter the date");

			date=sc.nextLine();

			System.out.println("Enter the status");

			status=sc.nextLine();

			System.out.println("Enter the winner team");

			winnerTeam=sc.nextLine();

			System.out.println("Enter the player of match");

			playerOfMatch=sc.nextLine();

			o[i]=new Outcome(date, status, winnerTeam, playerOfMatch);

		}

		

		OutcomeBO ou=new OutcomeBO();

		ou.displayAllOutcomeDetails(o);

		

		System.out.println("Enter the date to be searhed");

		String dt=sc.nextLine();

		ou.displaySpecificOutcomeDetails(o, dt);

		

		sc.close();



	}



}



