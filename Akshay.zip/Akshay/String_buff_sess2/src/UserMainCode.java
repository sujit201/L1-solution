
public class UserMainCode {

	public static boolean validateTeam(String team){
		
		String teamName = team.toLowerCase();
		int length = teamName.length();
		int ve = 0, vo = 0;
		
		for(int i = 0; i < length; i++){
			if(teamName.charAt(i) == 'a'|| teamName.charAt(i) == 'e' || teamName.charAt(i) == 'i' || teamName.charAt(i) == 'o' || teamName.charAt(i) == 'u'){
			
				if((i+1) %2 == 0)
					ve++;
				else
					vo++;
			
			}
			
			
		}
		if(ve>vo)
			return true;
		else
			return false;
	
	}
	
	public static boolean validatePlayer(String player, String stri){
		
		String playerName = player.toLowerCase();
		String str = stri.toLowerCase();
		int length = player.length();		
		/*int length2 = stri.length();*/
		
/*		if(length!= length2 || length <= 0 || length2 <= 0)
			return false;*/
		
			for(int i = 0; i < length; i++){
//				System.out.println(((char)(str.charAt(i) + 1)));
				if( ( playerName.charAt(i)) != ((char)(str.charAt(i) - 1)) )
					return false;	
			}
			
		return true;	
	}
}