import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		//String_buff_sess2/Display match summaries 1
		Scanner sc = new Scanner(System.in);
		
		String summary = sc.nextLine();
		Jumble.displaySummary(summary);
		
		sc.close();
	*/
		
		
		/*
		//String_buff_sess2/Display match summaries 2
		Scanner sc = new Scanner(System.in);
		
		String summary = sc.nextLine();
		Jumble.displayOutcome(summary);
		
		sc.close();
	*/
		
		
		//String_buff_sess2/Validation 3

		Scanner sc = new Scanner(System.in);
		
		String Player = sc.nextLine();
		String str = sc.nextLine();
		
		if(UserMainCode.validatePlayer(Player, str))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		
	}

}
