
public class Shape {
	
	protected String shapeName;

	//Getters and Setters
	public String getShapeName() {
		return shapeName;
	}

	public void setShapeName(String shapeName) {
		this.shapeName = shapeName;
	}


	//Constructor (String)
	public Shape(String shapeName) {
		super();
		this.shapeName = shapeName;
	}
	//Empty Constructor
	public Shape(){}
	
	public Double calculateArea(){
		
		return 0.00;
	}
	
}
