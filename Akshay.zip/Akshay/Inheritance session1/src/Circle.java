
public class Circle extends Shape{
	
	private int radius;

	//Getters and Setters
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	//Constructor (int)
	public Circle(int radius) {
		this.shapeName = "Circle";
		this.radius = radius;
	}
	
	
	//Returning pi multiplied with radius squared as area
	public Double calculateArea(){
		String str = new String();
		str = String.format("%.2f", 3.1415*radius*radius);
		
		return Double.parseDouble(str);
	}

	
}
