
public class Rectangle extends Shape {

	private int length;
	private int breadth;
	
	//Getters and Setters
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}	
	
	//Constructor (int, int)
	public Rectangle(int length, int breadth) {
		this.shapeName = "Rectangle";
		this.length = length;
		this.breadth = breadth;
		
	}
	
	
	//Returning length multiplied with breadth as area
	public Double calculateArea(){
		String str = new String();
		Double d = ((double) length)* (double)breadth; 
		str = String.format("%.2f", d);
		
		return d;
		//return Double.parseDouble(str);
	}
}
