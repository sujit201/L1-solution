class InningsBO
{
	public Innings createInnings (long inningsNumber)
	{
		
		//fill your code;
		return new Innings(inningsNumber);
		
	}

}
