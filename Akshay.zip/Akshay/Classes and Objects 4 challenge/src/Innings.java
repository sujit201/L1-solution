class Innings {
	
	private long inningsNumber;

	public Innings(long inningsNumber) {
		
		this.inningsNumber = inningsNumber;
	}

	public long getInningsNumber() {
		return inningsNumber;
	}

	public void setInningsNumber(long inningsNumber) {
		this.inningsNumber = inningsNumber;
	}


}
