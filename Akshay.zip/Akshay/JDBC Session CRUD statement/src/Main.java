



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import src.Player;
import src.PlayerDAO;


public class Main {
    
    public static void main(String ags[])throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("List of all Player from Kolkata city"); 
        List<Player> playerList = null;
        PlayerDAO playerIns = new PlayerDAO();
     
         
        //fill  your code
        playerList = playerIns.listAllPlayer();
        
        int i = 0;
        for(Player p :playerList)
        	System.out.println((++i) + ") " + p);
        
    }
}
