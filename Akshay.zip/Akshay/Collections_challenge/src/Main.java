import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.event.TreeExpansionEvent;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//Collection generic challenge
		Scanner sc = new Scanner(System.in);
		
		int num = Integer.parseInt(sc.nextLine());
		
		ArrayList<Integer> runsList = new ArrayList<Integer>();
		
		for(int i = 0; i < num; i++)
			runsList.add(Integer.parseInt(sc.nextLine()));
		
		int sum = 0;
		
		for(int r :runsList)
			sum += r;
		
		double avg = (double)sum/runsList.size();
		System.out.println(sum);
		System.out.println(String.format("%.2f", avg));
		sc.close();
		*/
		
		
		/*
		//Collections/Sets Challenge
		Scanner sc = new Scanner(System.in);
		
		int players = Integer.parseInt(sc.nextLine());
		
		TreeSet<String> playerList = new TreeSet<String>();
		
		for(int i = 0; i < players; i++)
			playerList.add(sc.nextLine());
		
		for(String p :playerList)
			System.out.println(p);		
		
		sc.close();
		
*/
		
		
		
		//Collections/Maps Challenge
				Scanner sc = new Scanner(System.in);
				
				System.out.println("Enter the number of players");
				int players = Integer.parseInt(sc.nextLine());
				
				HashMap<String, Long> playerMap = new HashMap<String, Long>();
				
				for(int i = 0; i < players; i++){
					System.out.println("Enter the details of the player " + (i+1));
					String playerName = sc.nextLine();
					long runs = Long.parseLong(sc.nextLine());
					
					playerMap.put(playerName, runs);
				}
				
				Set<String> keys = playerMap.keySet();
				
				long max = 0;
				String bestPlayer = new String();
				
				for(String p :keys){
					if(playerMap.get(p) > max){
						max = playerMap.get(p);
						bestPlayer = p;
					}
				}
				
				
					System.out.println(bestPlayer);
				
				
				

				
				sc.close();
		
		
	}

}
