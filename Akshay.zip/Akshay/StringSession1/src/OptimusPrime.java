
public class OptimusPrime {
	
	//Storing the non-empty String guiding to the ancient relics
	private String relicMap;
	
	public static int[] relicLocation(String directions){
		
		//X and Y coordinates
		int x = 0, y = 0;
		
		int length = directions.length();
		
		for(int i = 0; i < length; i++){
			if(directions.charAt(i) == 'U')
				y++;
			else if(directions.charAt(i) == 'D')
				y--;
			else if(directions.charAt(i) == 'R')
				x++;
			else if(directions.charAt(i) == 'L')
				x--;
		}
		
		int [] coordinates = {x, y};
		return coordinates;
			
		}

}
