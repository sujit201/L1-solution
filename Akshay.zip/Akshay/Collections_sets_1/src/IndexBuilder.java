import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class IndexBuilder {
	
	TreeSet<Index> ts = new TreeSet<Index>();
	
	public static TreeSet<Index> buildIndex(HashSet<Player> playerSet){
		
		//boolean chPresence = false;
		TreeSet<Index> ind = new TreeSet<Index>();
		
		Iterator<Player> it = playerSet.iterator();
		
		while(it.hasNext()){
			
			Player p = it.next();
			Index temp = new Index((p.getName().charAt(0)), 1);
			
			//Iterator<Index> it2 = ind.iterator();
			
			Index tsIndex = findIndex(ind, temp.getCh());
			
			
			if(tsIndex == null)
				ind.add(temp);
			else{
				ind.remove(tsIndex);
				ind.add(new Index(tsIndex.getCh(), (tsIndex.getCount()+1)));
			}
			/*while(it2.hasNext()){
				Index tempIndex = it2.next();
				if(tempIndex.getCh() == temp.getCh()){
					chPresence = true;
					ind.remove(tempIndex);
					ind.add(new Index(tempIndex.getCh(), (tempIndex.getCount()+1)));
					
				}
				
			}
			
			if(chPresence == false)
				ind.add(temp);*/
				
			//chPresence = false;	
		}
		
		return ind;
		
	}
	
	public static Index findIndex(TreeSet<Index> ind, char ch){
		
		Iterator<Index> it2 = ind.iterator();
		
		while(it2.hasNext()){
			
			Index tempIndex = it2.next();
			if(tempIndex.getCh() == ch)
				return tempIndex;
					
		}
		
		return null;	
	}


	public static void displayIndex(TreeSet<Index> ind){
		
		Iterator<Index> it2 = ind.iterator();
		
		while(it2.hasNext()){
			
			Index tempIndex = it2.next();
			System.out.println(String.format("%-15s%-15d", tempIndex.getCh(), tempIndex.getCount()));
					
		}
		
	}


}
