
public class Player {
	private String name;
	private Team team;
	
	//Constructor (String, String)
	public Player(String name, Team team) {
		super();
		this.name = name;
		this.team = team;
	}
	//Empty Constructor
	public Player(){}
	
	//Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}
	
	
	
	
}
