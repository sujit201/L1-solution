import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		/*
		//Classes and objects IV/Sess1 / Match-outcome
		
		Scanner sc = new Scanner(System.in);
		
		int noMatches;
		System.out.println("Enter number of matches");
		noMatches = Integer.parseInt(sc.nextLine());
		
		Match [] matchList = new Match[noMatches];
		
		for(int i = 0; i < noMatches; i++){
			
			String date = new String();
			String teamOne = new String();
			String teamTwo = new String();
			String venue = new String();
			String status = new String();
			String winnerTeam = new String();
			
			//Get details
			System.out.println("Enter match " + (i+1) + " details:");
			System.out.println("Enter match date");
			date = sc.nextLine();
			System.out.println("Enter team one");
			teamOne = sc.nextLine();
			System.out.println("Enter team two");
			teamTwo = sc.nextLine();
			System.out.println("Enter venue");
			venue = sc.nextLine();
			System.out.println("Enter status");
			status = sc.nextLine();
			System.out.println("Enter winner Team");
			winnerTeam = sc.nextLine();
			
			Outcome matchOutcome = new Outcome(status, winnerTeam);
			matchList[i] = new Match(date, teamOne, teamTwo, venue, matchOutcome);
			
		}
		
		//Display object
		MatchBO mbo = new MatchBO();
		
		//Menu
		while(true){
			
			int ch;
			System.out.println("Menu");
			System.out.println("1.View match details");
			System.out.println("2.Filter match details with outcome status");
			System.out.println("3.Filter match details with outcome winner team");
			System.out.println("4.Exit");
			
			System.out.println("Enter your choice");
			ch = Integer.parseInt(sc.nextLine());
			
			if(ch == 1)
				mbo.printAllMatchDetails(matchList);
			else if(ch == 2){
				String outcomeStatus = new String();
				System.out.println("Enter outcome status");
				outcomeStatus = sc.nextLine();
				mbo.printAllMatchDetailsWithOutcomeStatus(matchList, outcomeStatus);
			}
			else if(ch == 3){
				String outcomeWinnerTeam = new String();
				System.out.println("Enter outcome winner team");
				outcomeWinnerTeam = sc.nextLine();
				mbo.printAllMatchDetailsWithOutcomeWinnerTeam(matchList, outcomeWinnerTeam);
			}
			else if(ch == 4){
				break;
			}
			else
				break;
				
		}*/
		
	/*
		//Classes and Object IV/Sess 1/ Team-Player
		
		Scanner sc = new Scanner(System.in);
	
		
		
		//Input teams
		int teamCount;
		
		System.out.println("Enter the team count");
		teamCount = Integer.parseInt(sc.nextLine());
		
		Team [] teamList = new Team[teamCount];
		
		//Team manipulation object
		TeamBO tbo = new TeamBO();
		
		for(int i = 0; i < teamCount; i++){
			
			String str = new String();
			System.out.println("Enter team " + (i+1) + " details");
			str = sc.nextLine();
			teamList[i] = new Team();
			//teamList[i] = new Team(str.split(",")[0],str.split(",")[1]);
			teamList[i] = tbo.createTeam(str);
		}
		
		
		
		//Input players
		int playerCount;
		
		System.out.println("Enter the player count");
		playerCount = Integer.parseInt(sc.nextLine());
		
		//Player manipulation object
		PlayerBO pbo = new PlayerBO();
		
		Player [] playerList = new Player[playerCount];
		
		for(int i = 0; i < playerCount; i++){
			
			String str = new String();
			System.out.println("Enter player " + (i+1) + " details");
			str = sc.nextLine();
			playerList[i] = new Player();
			playerList[i] = pbo.createPlayer(str, teamList);
			
		}
		
		//Find team of a player
		String player = new String();
		System.out.println("Enter the player name for which you need to find the team name");
		player = sc.nextLine();
		
		System.out.println(player + " belongs to " + pbo.findTeamName(playerList, player));
		
		//Check teams of two players
		String player1 = new String();
		String player2 = new String();
		System.out.println("Enter 2 player names");
		player1 = sc.nextLine();
		player2 = sc.nextLine();
		
		if(pbo.findWhetherPlayersAreInSameTeam(playerList, player1, player2))
			System.out.println("The 2 player are in the same team");
		else
			System.out.println("The 2 player are in the different teams");
	*/
		
		
		
		
		

	}
}
