import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

/*		
		//Collections/Sets/Session2 - List MAtch by Date
		
		Scanner sc = new Scanner(System.in);
		
		int matches;
		
		System.out.println("Enter the number of matches");
		matches = Integer.parseInt(sc.nextLine());
		
		TreeSet<Match> matchSet = new TreeSet();
		
		for(int i = 0; i < matches; i++){
			
			String teamOne;
			String teamTwo;
			String matchDate;
			SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			
			System.out.println("Enter match date in (MM-dd-yyyy)");
			matchDate = sc.nextLine();
			System.out.println("Enter Team 1");
			teamOne = sc.nextLine();
			System.out.println("Enter Team 2");
			teamTwo = sc.nextLine();
			
			matchSet.add(new Match(sdf.parse(matchDate), teamOne, teamTwo));
			
		}
		
		System.out.println("Match Details");
		for(Match m :matchSet)
			System.out.println(m);
		
		sc.close();
		*/
	
		
		//Collections/Sets/Session2 - player info by cap number
		
		Scanner sc = new Scanner(System.in);
		
		int players;
		
		TreeSet<Player> playerSet = new TreeSet();
		
		System.out.println("Enter number of players:");
		players = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < players; i++){
			
			String name;
			String skill;
			String capNumber;
			
			System.out.println("Enter player " + (i+1) + " detail");
			System.out.println("Enter Name");
			name = sc.nextLine();
			System.out.println("Enter Skill");
			skill = sc.nextLine();
			System.out.println("Enter Cap Number");
			capNumber = sc.nextLine();
			
			playerSet.add(new Player(name, skill, Long.parseLong(capNumber)));
		}
		
		Iterator<Player> it = playerSet.descendingIterator();
		
		System.out.println("Player list after sorting by cap number in descending order");
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		sc.close();
		
		
		
		
		
	}

}
