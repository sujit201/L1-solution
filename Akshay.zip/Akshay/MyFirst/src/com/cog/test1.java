package com.cog;

public class test1 {
	public static void main(String[] args){
		System.out.println("Hello");
		ColorCircle c = new ColorCircle();
		c.setX(1);
		c.setY(2);
		c.setR(10);
		System.out.println(c);
	}

}
