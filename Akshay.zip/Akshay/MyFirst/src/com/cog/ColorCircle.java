package com.cog;

public class ColorCircle extends Circle{

}
