import java.util.Comparator;

public class Player {
/*
	
	//Collections Maps/Session 1/ Player List based on Name and skill
	private String name;
	private String skill;
	
	//Constructor (String, String)
	public Player(String name, String skill) {
		super();
		this.name = name;
		this.skill = skill;
	}

	//Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	@Override
	public String toString() {
		return "Player : " + name + " Skill  : " + skill;
	}

*/
	
	
/*	
	//Collections Maps/Session 1/ HashMap - Player
	
	private String bowlerName;
	private Integer wikcetCount;
	
	//Constructor (String, Integer)
	public Player(String bowlerName, Integer wikcetCount) {
		super();
		this.bowlerName = bowlerName;
		this.wikcetCount = wikcetCount;
	}

	//Getters and Setters
	public String getBowlerName() {
		return bowlerName;
	}

	public void setBowlerName(String bowlerName) {
		this.bowlerName = bowlerName;
	}

	public Integer getWikcetCount() {
		return wikcetCount;
	}

	public void setWikcetCount(Integer wikcetCount) {
		this.wikcetCount = wikcetCount;
	}
	*/
	
	
	//Collections Maps/Session 1/ HashMap - Player
	
	private String name;
	private String team;
	private String skill;
	
	//Constructor (String, String, String)
	public Player(String name, String team, String skill) {
		super();
		this.name = name;
		this.team = team;
		this.skill = skill;
	}

	//Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	@Override
	public String toString() {
		return name + "--" + team + "--" + skill;
	}
	
	
	
	
	
}
