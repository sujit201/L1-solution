import java.util.Comparator;

public class PlayerComparator implements Comparator<Player>{
	

	public int compare(Player p1, Player p2) {
		// TODO Auto-generated method stub
		
		if(p1.getSkill().equals(p2.getSkill()))
			return p1.getName().compareTo(p2.getName());
		else
			return p1.getSkill().compareTo(p2.getSkill());

	}

}
