
public class City {

	private String name;

	//Constructor (String)
	public City(String name) {
		super();
		this.name = name;
	}
	//Empty Contructor
	public City(){}
	
	
	//Getter and Setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//Override toString
	@Override
	public String toString() {
		return "City [name=" + name + "]";
	}
	
	
	
}
