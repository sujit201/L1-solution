
public class Venue {

	private String name;
	private City city;
	
	//Constructor (String, String)
	public Venue(String name, City city) {
		super();
		this.name = name;
		this.city = city;
	}
	//Empty Constructor
	public Venue(){};
	
	//Getters and Setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City c) {
		this.city = c;
	}
	
	//Overriding toString()
	@Override
	public String toString() {
		return String.format("%-15s%s", name, city.getName());
	}
	
	
}
