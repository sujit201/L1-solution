
public class CustomException extends Exception {
	
	//Custom error message in constructor
	public CustomException(){
		System.out.println("CustomException: InvalidAgeRangeException");
	}

}
