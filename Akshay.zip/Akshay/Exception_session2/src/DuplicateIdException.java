class DuplicateIdException extends Exception{

    public DuplicateIdException() {
    }

    public DuplicateIdException(String message) {
        System.out.println(message);
    }
    
}
