
public abstract class Shape {
	protected String name;

	//Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	//Constructor (String)
	public Shape(String name) {
		super();
		this.name = name;
	}
	
	public abstract float calculateArea();
	

}
