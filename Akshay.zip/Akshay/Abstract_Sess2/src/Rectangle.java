
public class Rectangle extends Shape{
	
	private Integer length;
	private Integer breadth;
	
	public Rectangle(String name, Integer length, Integer breadth) {
		
		super(name);
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	public float calculateArea() {
		// TODO Auto-generated method stub
		return length*breadth;
	}
	
	

}
