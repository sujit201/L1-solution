
public class Circle extends Shape{

	private Integer radius;
	
	//Getters and Setters
	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

	public Circle(String name, int radius) {
		super(name);
		this.radius = radius;
		// TODO Auto-generated constructor stub
	}

	@Override
	public float calculateArea() {
		// TODO Auto-generated method stub
		return (float) (3.14*radius*radius);
	}

}
