
public class DeliveryBO {
	
	public void displayAllDeliveryDetails(Delivery[] deliveryList){
		
		int dels = deliveryList.length;
		
		System.out.println("Delivery Details");
		
		for(int i = 0; i < dels; i++){

			System.out.println("Delivery--" + (i+1));
			System.out.println(deliveryList[i]);
		}
	}
}
