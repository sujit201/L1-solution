import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*//Exception handling 1
		Scanner sc = new Scanner(System.in);
		
		long runs;
		int overs;
		float crr;
		

		
		try{
			System.out.println("Enter the total runs scored");
			runs = Long.parseLong(sc.nextLine());
			System.out.println("Enter the total overs faced");
			overs = Integer.parseInt(sc.nextLine());
			crr = (float)runs/overs;
			if(overs == 0)
				throw new ArithmeticException();
			else
				System.out.println("Current Run Rate : " + String.format("%.2f", crr));
		}
		catch (Exception e){
			if(e instanceof ArithmeticException || e instanceof NumberFormatException)
				System.out.println(e.toString().split(":")[0]);
			else
				System.out.println("Error!!");
		}
		
		*/
		
		/*
		//Exceptions2 / Negative Array index/ArrayIndexOutOfBounds
		
		Scanner sc = new Scanner(System.in);
		

		try{
			int overs;
			
			System.out.println("Enter the number of overs");
			overs = Integer.parseInt(sc.nextLine());
			
			Integer[] runsArray = new Integer[overs];
			
			System.out.println("Enter the number of runs for each over");
			
			for(int i = 0; i < overs; i++){
				runsArray[i] =  Integer.parseInt(sc.nextLine());
			}
			
			int index;
			System.out.println("Enter the over number");
			index = Integer.parseInt(sc.nextLine());
			
			
//			System.out.println("Runs scored in this over : " + runsArray[index - 1]);
			System.out.println(runsArray[index - 1]);
		}
		catch(Exception e){
			if(e instanceof ArrayIndexOutOfBoundsException || e instanceof NegativeArraySizeException)
				System.out.println(e.toString().split(":")[0]);
			else
				System.out.println("Unknown error");
		}
		*/
		
		
		//Exception-4/Instantiation Exception
		Scanner sc = new Scanner(System.in);
		
		String player;
		String country;
		String skillset;
		try{
	    throw new InstantiationException();		
		}
		catch(InstantiationException e){
		   System.out.println("Trying to invoke a no-argument constructor (that is not available) using newInstance method");
		   System.out.println("Exception Occured : " + e);	
		}

			System.out.println("Enter name of the player");
			player = sc.nextLine();
			System.out.println("Enter country of the player");
			country = sc.nextLine();
			System.out.println("Enter skillset of the player");
			skillset = sc.nextLine();		
		
			Player p = new Player(player, country, skillset);
			
			System.out.println(p.getName() + ", " + p.getCountry() + ", " + p.getSkill());
			
			
		
				
	}

}
