
public class FourWheeler extends Vehicle{

	private String audioSystem;
	private int numberOfDoors;
	
	//Getters and Setters
	public String getAudioSystem() {
		return audioSystem;
	}
	public void setAudioSystem(String audioSystem) {
		this.audioSystem = audioSystem;
	}
	public int getNumberOfDoors() {
		return numberOfDoors;
	}
	public void setNumberOfDoors(int numberOfDoors) {
		this.numberOfDoors = numberOfDoors;
	}
	public void dislayBasicInfo(){
		
		System.out.println("---Basic Information---");
		System.out.println("Vehicle Number:" + vehicleNumber);
		System.out.println("Fuel Capacity:" + fuelCapacity);
		System.out.println("Fuel Type:" + fuelType);
		System.out.println("CC:" + cc);
	
	}
	//Contructor (<super args>, String, int)
	public FourWheeler(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc,
			String audioSystem, int numberOfDoors) {
		super(make, vehicleNumber, fuelType, fuelCapacity, cc);
		this.audioSystem = audioSystem;
		this.numberOfDoors = numberOfDoors;
	}

	//Empty constructor
	public FourWheeler() {
		super();
	}
	
	

	public FourWheeler(String audioSystem,	int numberOfDoors) {
		this.audioSystem = audioSystem;
		this.numberOfDoors = numberOfDoors;
	}
	//Display detailed information
	public void displayDetailInfo(){

		System.out.println("---Detail Information---");		
		System.out.println("Audio System:" + audioSystem);
		System.out.println("Number of Doors:" + numberOfDoors);

	}
	
}
