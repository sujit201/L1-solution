import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
/*		//Fundamentals/Session2/Dhoni Lucky number 1 

		
		Scanner sc = new Scanner(System.in);
		
		int start = Integer.parseInt(sc.nextLine());
		int end = Integer.parseInt(sc.nextLine());

		ArrayList<Integer> primes =  new ArrayList<Integer>();
				
		for(int i = start; i <= end; i++){
			//System.out.println(i);
			boolean primefn = isPrime(i);
			
			if(primefn)
				primes.add(i);
			else
				continue;
		}
		
		for(int i :primes)
			System.out.print(i + " ");
		sc.close();
		*/
		
/*		
		//Fundamentals/Session2/Dhoni Lucky number 2
	Scanner sc = new Scanner(System.in);
		
		int start = Integer.parseInt(sc.nextLine());
		int end = Integer.parseInt(sc.nextLine());

		ArrayList<Integer> palins =  new ArrayList<Integer>();
				
		for(int i = start; i <= end; i++){

			int temp = reverseNum(i);
			if(temp == i)
				palins.add(i);
			
		}
		
		for(int i :palins)
			System.out.print(i + " ");
		
		sc.close();
		*/
		
		
/*		
		//Fundamentals/Session2/Dhoni Lucky number 3
		Scanner sc = new Scanner(System.in);
			
			int start = Integer.parseInt(sc.nextLine());
			int end = Integer.parseInt(sc.nextLine());

			ArrayList<Integer> defs =  new ArrayList<Integer>();
					
			for(int i = start; i <= end; i++){

				if(divisorSum(i) < (2 * i))
					defs.add(i);
				
			}
			
			for(int i :defs)
				System.out.print(i + " ");
			
			sc.close();
		*/
		
		
/*		
			//Fundamentals/Session2/Dhoni Lucky number 4
			Scanner sc = new Scanner(System.in);
				
				int start = Integer.parseInt(sc.nextLine());
				int end = Integer.parseInt(sc.nextLine());

				ArrayList<Integer> luck =  new ArrayList<Integer>();
						
				for(int i = start; i <= end; i++){

					if(tOdTEv(i))
						luck.add(i);
					}
				
				for(int i :luck)
					System.out.print(i + " ");
				
				sc.close();*/
				
		
				
		//Fundamentals/Session2/Dhoni Lucky number 5
		Scanner sc = new Scanner(System.in);
					
		int start = Integer.parseInt(sc.nextLine());
		int end = Integer.parseInt(sc.nextLine());

		ArrayList<Integer> primes =  new ArrayList<Integer>();
							
		for(int i = start; i <= end; i++){

			if(checkPrime(i))
				primes.add(i);
		}
		
		for(int i :primes)
			System.out.print(i + " ");
					
		sc.close();
		
	}
	
	public static boolean isPrime(int num){
		
		if(num<20)
			return false;
		ArrayList<Integer> primeDigits = new ArrayList<Integer>();
		primeDigits.add(2);
		primeDigits.add(3);
		primeDigits.add(5);
		primeDigits.add(7);

		int primeDigCount = 0;
		int temp = num;
			
		while(temp > 0){
				
			if(primeDigits.contains(temp%10)){
				primeDigCount++;
				temp = temp/10;
			}
			else{
				temp = temp/10;
				continue;
			}	
		}
		if(primeDigCount == 2)
			return true;
		else
			return false;
	}
	
	public static int reverseNum(int num){
		
		if(num < 10)
			return num;
		
		int revNum = 0;
		while(num > 0){
			
			int temp = num%10;
			num = num / 10;
			
			revNum+= temp;
			
			if(num == 0)
				break;
			
			revNum = revNum * 10;
			
		}
		
		return revNum;
	}
	
	public static int divisorSum(int num){
		
		int dsum = num;
		
		for(int i = 1; i < num; i++){
			 if(num%i == 0)
				 dsum += i;
		}
		return dsum;
	}
	
	public static boolean tOdTEv(int number){
		
		if((number <= 1000) || (number >= 9989))
			return false;
		
		else{
			int num = number;
			int evs = 0;
			int odds = 0;
			while(num>0){
				if(num%10 == 0)
					evs = evs;
				else if((num%10)%2 == 0)
					evs++;
				else
					odds++;
				num = num/10;

			}
			if(odds == evs && evs == 2)
				return true;
			else
				return false;
		}

				
	}
	public static boolean checkPrime(int num){
		
		if(num == 1)
			return false;
		if(num == 2)
			return true;
		if(num == 0)
			return true;
		for(int i = 2; i < (num/2)+1; i++){
			if(num%i == 0)
				return false;
		}
		
		return true;

	}

}
