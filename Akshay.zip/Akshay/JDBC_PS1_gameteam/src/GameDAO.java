


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;



public class GameDAO {

	

public List<Game> getAllGameDetails() throws ClassNotFoundException, SQLException {

       ArrayList<Game> Al=new ArrayList<Game>();
       Game game=null;
      try
      {
             
          ResourceBundle rb= ResourceBundle.getBundle("mysql");
          
          String url=rb.getString("db.url");
          String user=rb.getString("db.username");
          String pass=rb.getString("db.password");
          Class.forName("com.mysql.jdbc.Driver");
          Connection con = DriverManager.getConnection(url,user,pass);
  
         //fill your code
          String sql = "select game_date, team_id_1, team_id_2 from game";
          Statement st = con.createStatement();
          ResultSet rs = st.executeQuery(sql);
          
          TeamDAO tdao = new TeamDAO();
          
          while(rs.next()){
        	  
        	  java.sql.Date sdate = rs.getDate(1);
        	  java.util.Date date = new Date(sdate.getTime());
        	  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        	  String strDate = sdf.format(date);
        	  Team team1 = tdao.getTeamByID(rs.getLong(2));
        	  Team team2 = tdao.getTeamByID(rs.getLong(3));
        	  game = new Game(strDate, team1, team2);
        	  Al.add(game);
          }
          return Al;
      }
      catch(Exception e){
    	  return null;
      }
          

  }
  
  public void updateTeamDetails(Date gameDate,String team1,String team2) throws ClassNotFoundException, SQLException, ParseException {
    
	  ResourceBundle rb= ResourceBundle.getBundle("mysql");
      
      String url=rb.getString("db.url");
      String user=rb.getString("db.username");
      String pass=rb.getString("db.password");
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);

      //fill your code
      String sql = "update game set team_id_1 = ?, team_id_2 = ? where game_date = ?";
      PreparedStatement pst = con.prepareStatement(sql);
      TeamDAO tdao = new TeamDAO();
      Team t1 = tdao.getTeamByName(team1);
      Team t2 = tdao.getTeamByName(team2);
      
      pst.setLong(1, t1.getTeamId());
      
      pst.setLong(2, t2.getTeamId());
      java.sql.Date sdate = new java.sql.Date(gameDate.getTime());
      pst.setDate(3, sdate);
      
      pst.executeUpdate();
      
  }
  public void displayGame(List<Game> gameList){
      System.out.format("%-15s %-30s %-30s\n","Game Date","Team 1","Team 2"); 

      //fill your code
      for(Game g :gameList)
    	  System.out.format("%-15s %-30s %-30s\n",g.getGameDate(),g.getTeam1().getTeamName(),g.getTeam2().getTeamName());
      
      }
	
	
}
