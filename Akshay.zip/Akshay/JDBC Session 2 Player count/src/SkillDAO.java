

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.TreeMap;

public class SkillDAO {

  public TreeMap<Skill,Integer> skillCount(){
      TreeMap<Skill,Integer> skillCountMap = new TreeMap<Skill,Integer>();
      try{
          ResourceBundle rb= ResourceBundle.getBundle("mysql");
          String url=rb.getString("db.url");
          String user=rb.getString("db.username");
          String pass=rb.getString("db.password");
          Class.forName("com.mysql.jdbc.Driver");
          Connection con = DriverManager.getConnection(url,user,pass);
         
              
          //fill your code

          TreeMap<Skill, Integer> skillList = new TreeMap<Skill, Integer>();
          
          String querySkill = "select * from skill";
          Statement st = con.createStatement();
          ResultSet rs = st.executeQuery(querySkill);
          
          String queryPlayer = "select count(id) from player where skill_id=?";
          PreparedStatement pst = con.prepareStatement(queryPlayer);
          
          while(rs.next()){
        	  
        	  pst.setInt(1, rs.getInt(1));
        	  ResultSet count = pst.executeQuery();
        	  count.next();
        	  Skill s = new Skill((long)rs.getInt(1), rs.getString(2));
        	  skillCountMap.put(s, count.getInt(1));
          }
        	  
          return skillCountMap;
      }
      catch(Exception e){}
	return skillCountMap;

  }
}

