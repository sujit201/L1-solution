

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;


public class OutComeDAO {
  
  
    public OutCome getOutComeByID(Long id) throws ClassNotFoundException, SQLException {
      ResourceBundle rb= ResourceBundle.getBundle("mysql");
      
      String url=rb.getString("db.url");
      String user=rb.getString("db.username");
      String pass=rb.getString("db.password");
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);
   
  
       //fill your code
      String sql = "select winner_team_id from outcome where id="+id;
      Statement st = con.createStatement();
      ResultSet rs = st.executeQuery(sql);
      
      rs.next();
      
      TeamDAO tdao = new TeamDAO();
      Team winner = tdao.getTeamByID(id);
      
      return new OutCome(id, winner);      

  }
}
