  
import java.util.*;

class Main {
    public static void main(String args[]) {
		//fill your code;
    	
    	
    	Scanner sc = new Scanner(System.in);
    	
    	int players;
    	System.out.println("Enter the number of players");
    	players = Integer.parseInt(sc.nextLine());
    	
    	System.out.println("Do you know the details of the captain? Type Yes / No");
    	String str = sc.nextLine();
    	String[] playerDetails = new String[3]; 
    	
    	Player captain= null;
    	
    	if(str.equals("Yes")){
    		System.out.println("Enter name of the captain");
    		playerDetails[0] = sc.nextLine();
    		System.out.println("Enter country of the captain");
    		playerDetails[1] = sc.nextLine();
    		System.out.println("Enter skillset of the captain");
    		playerDetails[2] = sc.nextLine();
    		captain = new Player(playerDetails[0], playerDetails[1], playerDetails[2]);
    	}
    	else
    		captain = null;
    	
    	Player [] playerList = new Player[players];
    	
    	for(int i = 0; i < players; i++){
    		System.out.println("Enter name of player " + (i+1));
    		playerDetails[0] = sc.nextLine();
    		System.out.println("Enter country of player " + (i+1));
    		playerDetails[1] = sc.nextLine();
    		System.out.println("Enter skillset of player " + (i+1));
    		playerDetails[2] = sc.nextLine();
    		
    		playerList[i] = new Player(playerDetails[0], playerDetails[1], playerDetails[2]);
    		
    	}

    	PlayerBO pbo = new PlayerBO();
    	
    	//Captain details (exception prone)
    	try{
    		pbo.displayPlayerDetails(captain);
    	}
    	catch (Exception e){
    		if(e instanceof NullPointerException)
    			System.out.println("Exception Occured : " + e.toString().split(":")[0]);
    			System.out.println("Captain details not available");
    	}
    	
    	System.out.println("Player Details");
    	for(Player p:playerList)
    		pbo.displayPlayerDetails(p);
    	
    	sc.close();
    	
    }
}


