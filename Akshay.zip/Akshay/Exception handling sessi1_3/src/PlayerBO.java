  class PlayerBO
{
    public void displayPlayerDetails(Player player)
	{
		System.out.println(player.getName() + ", " + player.getCountry() + ", " + player.getSkill());
	}
}
