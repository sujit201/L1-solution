import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//Hashmaps Collections sess2/wicketDetails
		
		Scanner sc = new Scanner(System.in);
		
		//List of Wickets
		ArrayList<Wicket> wicketList= new ArrayList<Wicket>();
		
		String bowler;
		String wicketsTaken;
		
		//Adding wickets
		while(true){
			
			System.out.println("Enter the player name");
			bowler = sc.nextLine();
			System.out.println("Enter wickets - seperated by \"|\" symbol");
			wicketsTaken = sc.nextLine();
			
			Bowler b = new Bowler(bowler);
			
			String [] wickets = wicketsTaken.split("\\|");
			
			for(String str :wickets){
				Wicket temp = new Wicket(str, b);
				wicketList.add(temp);
			}


			String choice;
			System.out.println("Do you want to add another player (yes/no)");
			choice = sc.nextLine();
			
			if(choice.equals("yes"))
				continue;
			else
				break;
		}
		
		//Searching wickets
		while(true){
			
			System.out.println("Enter the player name to search");
			bowler = sc.nextLine();
			
			boolean found = false;
			
			Bowler b = new Bowler(bowler);
			
			for(Wicket w: wicketList){
				if(((w.getBowler()).getName()).equals(bowler)){
					

					if(found == false){
						System.out.println("Player Name : " + bowler);
						System.out.println("Wickets :");
					}
					found = true;
					System.out.println(w.getPlayerName());
					
				}
				
			}
			
			if(found == false)
				System.out.println("No player found with the name " + bowler);

			

			String choice;
			System.out.println("Do you want to search another player (yes/no)");
			choice = sc.nextLine();
			
			if(choice.equals("yes"))
				continue;
			else
				break;
		}

		sc.close();
		*/
		
		
		/*
		//Collections Maps sess2/Scores to bin
		
		Scanner sc = new Scanner(System.in);
		
		int overs;
		overs = Integer.parseInt(sc.nextLine());
		
		Histogram hs = new Histogram();
		
		for(int i = 0; i < overs; i++)
			hs.addScore(Integer.parseInt(sc.nextLine()));
		
		System.out.println("Histogram");
		hs.displayHistogram();
		sc.close();
		*/
		
		/*
		//Collections Maps / Session 2/ Tree map - Player Details
		
				Scanner sc = new Scanner(System.in);
				
				int players;
				
				System.out.println("Enter the number of players");
				players = Integer.parseInt(sc.nextLine());
				
				TreeMap<Integer, Player> playerMap = new TreeMap<Integer, Player>();
				
				for(int i = 0; i < players; i++){
					
					int capNumber;
					String name;
					String team;
					String skill;
					
					System.out.println("Enter the details of the player " + (i+1));
					capNumber = Integer.parseInt(sc.nextLine());
					name = sc.nextLine();
					team = sc.nextLine();
					skill = sc.nextLine();
					
					Player p = new Player(name, team, skill);
					playerMap.put(capNumber, p);
					
				}
				
				Set<Integer> s = playerMap.keySet();
				System.out.println("Player Details");
				for(int i :s){
					System.out.println(i+"--"+playerMap.get(i));
				}
				
				System.out.println("Enter the cap number of the player to be searched");
				int cn = Integer.parseInt(sc.nextLine());
				

				if(playerMap.containsKey(cn)){
					System.out.println("Player Details");
					System.out.print(playerMap.get(cn));
				}
				else
					System.out.println("Player not found");
				
				
				sc.close();
				*/
		
		
		//Collections Maps / Session 2/ Tree map - Letter frequency
		
		Scanner sc = new Scanner(System.in);
		
		LetterSequence ls = new LetterSequence();
		
		TreeMap<Character, Integer> frequencyMap = ls.computeFrequency();
		ls.displayLetterFrequency(frequencyMap);
		
		sc.close();
		
		
		
	}

}
