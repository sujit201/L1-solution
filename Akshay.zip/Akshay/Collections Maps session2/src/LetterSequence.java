import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class LetterSequence {	
	
	//Store input
	private String sentence;
	
	//Input sentence
	public LetterSequence() {
		super();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the input string");
		sentence = sc.nextLine();
		
		sc.close();
	}
	
	
	//Compute Frequency of characters using the 'sentence' variable
	public TreeMap<Character, Integer> computeFrequency(){
		
		TreeMap<Character, Integer> freq = new TreeMap<Character, Integer>();
		
		int length = sentence.length();
		
		for(int i = 0; i < length; i++){
			
			char c = sentence.charAt(i);
			
			if(c == ' ')
				continue;
			
			//Update count by 1 increment
			if(freq.containsKey(c)){
				int tmpCount = freq.get(c);
				freq.remove(c);
				freq.put(c, (tmpCount+1));
			}
			//Add the key with value 1
			else
				freq.put(c, 1);
			
		}
		
		return freq;
		
	}
	
	
	//display the treemap of character drequency
	public void displayLetterFrequency(TreeMap<Character, Integer> frequencyMap){
		
		Set<Character> s = frequencyMap.keySet();
		
		for(char k :s){
			
			int starCount = frequencyMap.get(k);
			
			System.out.print(k + " : ");
			for(int i = 0; i < starCount; i++)
				System.out.print("*");
			
			System.out.println("");	
		}
	}
	

}
