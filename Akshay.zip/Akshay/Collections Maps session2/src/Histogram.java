import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

public class Histogram {

	private TreeMap<Integer, Integer> overStats = new TreeMap<Integer, Integer>();

	
	
	public Histogram() {
		super();
		this.overStats = new TreeMap<Integer, Integer>();
		overStats.put(10, 0);
		overStats.put(20, 0);
		overStats.put(30, 0);
		overStats.put(40, 0);
	}

	//Add new Scores
	public void addScore(int score){
		
		int bin = (((score-1)/10) + 1) * 10;
		
		if(score > 40)
			return;
		
		int count = overStats.get(bin);
		
		overStats.put(bin, (count+1));
		
	}
	
	//Display Histogram
	public void displayHistogram(){
		
		Set<Integer> s = overStats.keySet();
		
		for(int key :s){
			
			int stars = overStats.get(key);
			System.out.print(key + " : ");
			
			for(int i = 0; i < stars; i++)
				System.out.print("*");
			//new Line
			System.out.println("");
		}
	}
}
