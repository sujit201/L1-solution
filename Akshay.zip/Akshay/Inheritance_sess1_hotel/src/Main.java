import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Testing Hotel rooms
		//Menu
		System.out.println("Hotel Tariff Calculator");
		System.out.println("1. Deluxe Room");
		System.out.println("2. Deluxe AC Room");
		System.out.println("3. Suite AC Room");
		
		System.out.println("Select Room Type:");
		int roomType;
		
		Scanner sc = new Scanner(System.in);
		
		String hotelName;
		Integer numberOfSqFeet;
		String ht = new String();
		boolean hasTV;
		String hw = new String();
		boolean hasWifi;
		
		roomType = Integer.parseInt(sc.nextLine());
		
		System.out.println("Hotel Name:");
		hotelName = (sc.nextLine());
		
		System.out.println("Room Square Feet Area:");
		numberOfSqFeet = (Integer.parseInt(sc.nextLine()));
		
		System.out.println("Room has TV (yes/no):");
		ht = sc.nextLine();
		if(ht.equals("yes"))
			hasTV = (true);
		else
			hasTV = (false);
		
		System.out.println("Room has Wifi (yes/no):");
		hw = sc.nextLine();
		if(hw.equals("yes"))
			hasWifi = (true);
		else
			hasWifi = (false);
		
		
		
		if(roomType == 1){
			DeluxeRoom hr = new DeluxeRoom(hotelName, numberOfSqFeet, hasTV, hasWifi);
			System.out.println("Room Tariff per day is:" + hr.calculateTariff());
		}
		else if(roomType == 2){
			DeluxeACRoom hr = new DeluxeACRoom(hotelName, numberOfSqFeet, hasTV, hasWifi);
			System.out.println("Room Tariff per day is:" + hr.calculateTariff());
		}
		else if(roomType == 3){
			SuiteACRoom hr = new SuiteACRoom(hotelName, numberOfSqFeet, hasTV, hasWifi);
			System.out.println("Room Tariff per day is:" + hr.calculateTariff());
		}

	}

}
