
public class DeluxeACRoom extends DeluxeRoom{

	public DeluxeACRoom(){
		
		super.setRatePerSqFeet(12);
	}

	public DeluxeACRoom(String hotelName, Integer numberOfSqFeet, boolean hasTV, boolean hasWifi) {
		// TODO Auto-generated constructor stub
		super(hotelName, numberOfSqFeet, hasTV, hasWifi);
	}

	@Override
	public Integer getRatePerSqFeet() {
		// TODO Auto-generated method stub
		super.setRatePerSqFeet(12);
		return super.getRatePerSqFeet();
	}
/*
	@Override
	public Integer calculateTariff() {
		// TODO Auto-generated method stub
		return numberOfSqFeet*this.getRatePerSqFeet();
	}
	*/
	
}
