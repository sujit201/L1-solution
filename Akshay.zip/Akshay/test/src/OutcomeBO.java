
public class OutcomeBO {
	
	void displayAllOutcomeDetails(Outcome[] outcomeList)
	{
		System.out.println("Outcome Details");
		System.out.println(String.format("%-20s %-20s %-20s %s","Status","Winning Team","Player Of The Match","Date"));
//		System.out.println();
		for(int i=0;i<outcomeList.length;i++)
		{
			//System.out.println("Delivery--"+(i+1));
		System.out.println(outcomeList[i]);
		}

		
	}
	void displaySpecificOutcomeDetails(Outcome []outcomeList, String date)
	{
		System.out.println("Outcome Details");
		System.out.println(String.format("%-20s %-20s %-20s %s","Status","Winning Team","Player Of The Match","Date"));
		
				for(int i=0;i<outcomeList.length;i++)
		{
					
			//	System.out.println(outcomeList[i].getPlayerOfMatch());
					
			if((outcomeList[i].getDate()).equals(date))
			{
				System.out.println(outcomeList[i]);
			}
		
	}
		

}
}