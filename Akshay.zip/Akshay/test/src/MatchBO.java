

public class MatchBO {

	
	//Display all match details
	public void printAllMatchDetails(Match[] MatchList){
		
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %-1s", "Date", "Team1", "Team2", "Venue", "Status", "Winner"));
		
		for(Match m: MatchList)
			System.out.println(m);
		
	}
	
	//Display match details using outcome status as keyword
	public void printAllMatchDetailsWithOutcomeStatus(Match[] MatchList, String outcomeStatus){
		
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %-1s", "Date", "Team1", "Team2", "Venue", "Status", "Winner"));
		boolean stat = false;
		
		for(Match m: MatchList){
			
			if((m.getOutcome()).getStatus().equals(outcomeStatus)){
				System.out.println(m);
				stat = true;
			}
				
		}
		if (stat == false)
				System.out.println("Status not found");
		
		
	}
	
	//Display match details using outcome winning team as keyword
	public void printAllMatchDetailsWithOutcomeWinnerTeam(Match[] MatchList, String outcomeWinnerTeam){
		
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %-1s", "Date", "Team1", "Team2", "Venue", "Status", "Winner"));
		boolean winteam = false;
		for(Match m: MatchList){
			
			if((m.getOutcome().getWinnerTeam().equals(outcomeWinnerTeam))){
				System.out.println(m);
				winteam = true;
			}
				

		}
		if (winteam == false)
			System.out.println("Winner Team not found");	
		
		
	}
}
