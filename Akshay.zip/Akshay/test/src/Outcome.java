public class Outcome {
private String date,status,winnerTeam,playerOfMatch;

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getWinnerTeam() {
	return winnerTeam;
}

public void setWinnerTeam(String winnerTeam) {
	this.winnerTeam = winnerTeam;
}

public String getPlayerOfMatch() {
	return playerOfMatch;
}

public void setPlayerOfMatch(String playerOfMatch) {
	this.playerOfMatch = playerOfMatch;
}
public Outcome() {
	super();
}



public Outcome( String status, String winnerTeam, String playerOfMatch,String date) {

	
	this.status = status;
	this.winnerTeam = winnerTeam;
	this.playerOfMatch = playerOfMatch;
	this.date = date;
}

@Override
public String toString() {
	return String.format("%-20s %-20s %-20s %s",status,winnerTeam,playerOfMatch,date);
}



}
